import React from "react";
import * as GrIcons from 'react-icons/gr';
import * as TiIcons from 'react-icons/ti';
import { Input } from "@progress/kendo-react-inputs";

  export default class Header extends React.Component {
    constructor(props) {
      super(props);
    
      // Creating a reference
      this.box = React.createRef();
      this.state={edit:false,editValue:null}
    }
    
    componentWillMount() {
    
      // Adding a click event listener
      if(this.state.edit===true)document.addEventListener('mousedown', this.handleOutsideClick);
    }
   componentWillUnmount(){
    document.removeEventListener("mousedown", this.handleOutsideClick);
   }
    handleOutsideClick = (event) => {
      if (!this.box.current.contains(event.target)) {
        this.setState({editValue:null,edit:false})
        document.removeEventListener("mousedown", this.handleOutsideClick);
      }
    }
    
    inputValue = ""
    editHeader=(e)=>{
      //  console.log(this.props) 
        let value = e.target.value;
        this.inputValue= value
        
    }
    saveHeader=()=>{
        // console.log(this.props,this.inputValue)
        let value = this.inputValue
        if(value!==null && value!==""){
            this.setState({edit:false,editValue:value})
            this.props.changeHandler(value,this.props.idx)    
        }else this.setState({edit:true})
    }
    
    render() {
      if(this.state.edit===true)this.componentWillMount()
        return (
          <div style={{ borderColor: "#dee2e6",
          color: "#4C4F8A",
         textAlign: 'center'}}>
            {this.state.edit===true?<div ref={this.box}>
                <Input style={{width: '50%'}} type='search' maxLength="256" onChange={this.editHeader} placeholder={this.props.title}></Input>
                <span style={{float: "right",marginRight:"30px"}}>
                <TiIcons.TiTickOutline style={{fontSize:"20px"}} onClick={this.saveHeader}/>
                </span>
            </div>:
            <div>
            <a className="k-link" href="# " onClick={this.props.onClick}>
            <span style={{font:"400",textAlign: 'center',marginLeft:"0px"}} title={this.props.title}>{this.state.editValue===null?this.props.title:this.state.editValue}</span>
                {this.props.children}
            </a>
            <span style={{float: "right",marginRight:"30px"}}><GrIcons.GrEdit onClick={()=>this.setState({edit:true})} /></span>
            
            </div>}
            </div>
        );
        
    }
  }
