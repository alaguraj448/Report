export const IssueReport_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    
    {
        field: "Mon",
        title: "Category",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "Ontime",
        title: "Ontime",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "{0:0.00}" 
    },
    {
        field: "Late",
        title: "Late",
        minWidnt: 185,
        filter: "text",
        show: true,
        format:"{0:0.00}" 
    },
    {
        field: "StillToPublish",
        title: "Still To Publish",
        minWidnt: 185,
        filter: "text",
        show: true,
        format:"{0:0.00}" 
    }
    
   
]