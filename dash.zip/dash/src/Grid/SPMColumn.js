export const SPMGrid_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "Name",
        title: "SPM",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Tier",
        title: "Tier",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },  {
        field: "Norms",
        title: "Norms",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },  {
        field: "Actuals",
        title: "Actuals",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    }
]