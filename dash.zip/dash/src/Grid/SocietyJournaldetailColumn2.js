export const DetailJournal_columns2 = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "Last_Step",
        title: "Last_Step",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "TargetTAT",
        title: "Target TAT",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },{
        field: "ActualTAT",
        title: "Actual TAT",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },{
        field: "Nos",
        title: "Nos",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
]