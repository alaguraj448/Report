
import * as React from 'react';
import { process, filterBy, orderBy } from '@progress/kendo-data-query';
import {
    Grid, GridColumn, GridToolbar
} from '@progress/kendo-react-grid';
import { GridService } from '../services/grid.services'
import { saveAs, encodeBase64 } from '@progress/kendo-file-saver';
import { ExcelExport } from '@progress/kendo-react-excel-export';
import { Input } from "@progress/kendo-react-inputs";
import { Button } from '@progress/kendo-react-buttons';
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { ComboBox } from '@progress/kendo-react-dropdowns'
import { CustomColumnMenu } from './customColumnMenu.js';
import '../App.css';
import * as BiIcons from 'react-icons/bi';
import Header from './editHeader'
import DrillDown from './CCDrilldownGrid'

let products = [], fixed = [], tempdata = false, reordering = false
let value = new Date()
let fromDate = new Date();
let toDate = new Date()
fromDate.setMonth(fromDate.getMonth() - 3);
fromDate.setDate(1)
//toDate.setDate(toDate.getDate() - 1)


export default class App extends React.Component {
    _export;
    // Function to export grid data
    export = () => {
        if (reordering) { /* Executed when reordeing is true */
            this.reorder()
            setTimeout(() => {
                this._export.save();
                this.setState({
                    data: products, columns: this.state.afterExportColumn, isLoading: false, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
                reordering = true
            }, 200);
        }
        else this._export.save(); /* Executed when reordeing is false */
    }
    gridPDFExport;

    anchor = null;
    anchor2 = null;
    // Variable to store template name from local storage
    QTRtemplateName = JSON.parse(localStorage.getItem('QTRtemplateName')) === null ? [] : JSON.parse(localStorage.getItem('QTRtemplateName'));
    // Variable to store template state from local storage
    QTRtemplateState = JSON.parse(localStorage.getItem('QTRtemplateState')) === null ? [] : JSON.parse(localStorage.getItem('QTRtemplateState'));
    constructor(props) {
        super(props); /* Gets Props 'name, input, columns, getData, aggregates, chartData ' */

        const dataState = this.createDataState({
            take: 25,
            skip: 0,
        });

        // this.getData = this.props.getData()

        // Initialize the state of the component
        this.state = {
            path: 'http://inet:81/OIVADashBoard/GroupSummary',
            data: [],
            setMinWidth: false,
            columns: [...this.props.DetailedColumn],
            gridCurrent: 0,
            isLoading: false,
            showPopupOnRefresh: false,
            showPopupOnSaveTemp: false,
            inputSearchValue: null,
            searchvalue: "",
            newTemplate: null,
            tempCount: this.QTRtemplateName.length,
            exporting: false,
            filterable: false,
            chartData: [],
            viewChart: false,
            popupChart: false,
            itemPage: 25,
            skip: 0,
            group: [],
            isDrill: false,
            filter: { logic: "", filters: [] },
            reortered: false,
            afterExportColumn: [...this.props.DetailedColumn],
            chartInput: {
                "FromDate": fromDate,
                "ToDate": toDate
            },
            input: this.props.input,
            navopen: false,
            aggregates: [...this.props.Detailedaggregates],
            ...dataState
        };
    }
    minGridWidth = 0;

    componentDidMount() {
        debugger

        if (this.props.navopen) {
            
            document.getElementById('grid-container').style.marginLeft = "150px";
            // document.getElementById('grid-body').style.marginLeft = "50px";
        }

        // Function to fetch data from api and load it to grid
        if (this.props.isComing === true) {
            this.setState({
                backgrid: this.props.Griddata, chartData: this.props.chart
            })
            if (this.props.gridsearchValue !== "") {
                // document.getElementById("Searchbox").value=this.props.searchvalue
                this.setState({ searchvalue: this.props.gridsearchValue })
            }
            // products = this.props.Griddata.map((dataItem, idx) => Object.assign({ ID: idx, selected: false }, dataItem))
            this.setState({
                data: this.props.Griddata, columns: this.state.columns, ...this.createDataState({
                    take: this.state.itemPage,
                    skip: 0,
                    group: this.state.group,
                    sort: this.state.sort,
                    filter: this.state.filter
                })
            })
            setTimeout(() => {
                this.props.FalseIsComing()
            }, 400);
        }
        else {

         this.setState({ isLoading: true })

            GridService.Ageing(this.props.input).then(response => {
                let d = response
                let dat = JSON.parse(d.response)
                let data = dat.Table

                products = data.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
      
                fixed = products
                this.setState({
                    data: products, backgrid: products, columns: this.state.columns, isLoading: false, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
            }).catch(err => {
                console.log("error", err)
                this.setState({ isLoading: false })

            });


        }


    }



    // Executes every time when a state is created
    createDataState(dataState) {
        const groups = dataState.group;
        if (groups) { groups.map(group => group.aggregates = this.state.aggregates); }
        const result = process(products.slice(0), dataState);

        if (groups) {
            let total = result.total, newDataState = dataState, excel, take = dataState.take;
            newDataState.take = total
            newDataState.group = []
            excel = process(products.slice(0), newDataState).data
            tempdata = false
            newDataState.group = groups
            products = excel
            this.setState({ isLoading: false })
            newDataState.take = take

        }
        return {
            result: result,
            dataState: dataState,
            Footerdata: result.data,
            Footertotal: result.total
        };
    }

    // Executes every time when a state is changed
    dataStateChange = (event) => {
        this.setState(this.createDataState(event.dataState));
    }

    // Executes on the column menu submit
    onColumnsSubmit = (columnsState) => {
        this.setState({
            columns: columnsState
        });
    }

    expandChange = (event) => { // Executes on expand and close of grouped data 
        event.dataItem[event.target.props.expandField] = event.value;
        this.setState({
            result: Object.assign({}, this.state.result),
            dataState: this.state.dataState
        });
    }
    pageChange = (event) => { // Executes on page change in grid
        this.setState({
            skip: event.page.skip,
            take: event.page.take
        });
    }

    searchData = e => { // Function for common search in grid 
        let value = e.target.value;
        this.setState({ searchvalue: e.target.value })
        let field = this.state.columns.map(column => { return { field: column.field, operator: "contains", value: value } })
        let filter = {
            logic: "or",
            filters: field
        };
        products = filterBy(this.state.data, filter);
        fixed = products
        this.dataStateChange(this.state)
    };

    filterChange = (event) => { // Function for filter change
        products = filterBy(this.state.data, event.filter)
        fixed = products
        this.setState({
            filter: event.filter,
            ...this.createDataState({
                take: this.state.itemPage,
                skip: 0
            }),

        });

        setTimeout(() => { this.dataStateChange(this.state) }, 100);

        // products=this.state.refreshData
    }

    selectionChange = (event) => { // Executes when select or unselect header select in grid
        const data = this.state.data.map(item => {
            if (item.ID === event.dataItem.ID) {
                item.selected = !event.dataItem.selected;
            }
            return item;
        });
        this.setState({ data });
    }

    headerSelectionChange = (event) => { // Executes when select or unselect a row in grid
        const checked = event.syntheticEvent.target.checked;
        const data = this.state.data.map(item => {
            item.selected = checked;
            return item;
        });
        this.setState({ data });
    }

    cellRender(tdElement, cellProps) {  // This function is used for any changes in the cells in grid
        if (cellProps.dataItem.aggregates !== undefined) {
            let i = 0, key = Object.keys(cellProps.dataItem.aggregates)
            if (cellProps.rowType === 'groupFooter') {
                for (i; i < key.length; i++) {
                    if (cellProps.field === key[i]) {
                        return (
                            <td data-toggle="tooltip" >
                                <b title={"Sum: " + parseFloat(cellProps.dataItem.aggregates[key[i]].sum).toFixed(2)}>Sum: {parseFloat(cellProps.dataItem.aggregates[key[i]].sum).toFixed(2)}</b><br />
                                <b title={"Average: " + parseFloat(cellProps.dataItem.aggregates[key[i]].average).toFixed(2)}> Average: {parseFloat(cellProps.dataItem.aggregates[key[i]].average).toFixed(2)}</b>
                            </td>
                        );
                    }
                }

            }
        }
        if (cellProps.field === "selected") {
            return (tdElement)
        }
        else if (tdElement) {

            if (cellProps.field === 'ID') {
                return (<td className="extraID" style={{ textAlign: 'center' }} title={tdElement.props.children}>{tdElement.props.children}</td>)
            }
           

        }
        return (tdElement)
    }

    // Function no executes on Refresh no option 
    no = () => { this.setState({ showPopupOnRefresh: !this.state.showPopupOnRefresh, inputSearchValue: null }) }

    // Function yes executes on Refresh yes option 
    yes = () => {
        debugger
        reordering = false
        this.setState({
            columns: [...this.state.columns],
            data: products,
            setMinWidth: false,
            gridCurrent: 0,
            filter: undefined,
            showPopupOnRefresh: false,
            initTemp: null,
            inputSearchValue: null,
            searchvalue: "",
            sort: [],
            itemPage: 25,
            group: [],
            filterable: false
        })
        this.componentDidMount();
        this.dataStateChange(this.state)

    }
    backdrill = () => {
        this.props.isDrill(false)
        this.setState({ isDrill: false })
    }
    // Function executes on Refresh
    onRefresh = () => {
        this.setState({ showPopupOnRefresh: !this.state.showPopupOnRefresh, inputSearchValue: "" });
    }



    // Function executes onClick on popup Save Template, Cancel Button
    dontSaveTemplate = () => this.setState({ newTemplate: "", showPopupOnSaveTemp: false })

    tempChange = (event) => { // Executes when a template is selected from dropdown
        if (event.target.value !== null) {
            let newState = this.QTRtemplateState.find(data => data.name === event.target.value)
            this.setState({ isLoading: true, Loadtemp: true, columns: newState.columns, filter: newState.filter, sort: newState.sort, initTemp: event.target.value, itemPage: newState.itemPerPage, group: newState.group })
            tempdata = true
            this.componentDidMount()
        }
        else this.setState({ initTemp: null })
    }

    sortChange = (event) => { // Function for sorting in grid
        this.setState({
            data: this.getProducts(event.sort),
            sort: event.sort
        });
        products = this.getProducts(event.sort)
        fixed = products
        this.dataStateChange(this.state)

    }

    getProducts = (sort) => {
        return orderBy(products, sort);
    }

    changeStuff(val, idx) { // Funtion to save edited column header changes from child component to state of parent component
        let editColumn = JSON.parse(JSON.stringify(this.state.columns));
        editColumn[idx].title = val
        this.setState({ columns: editColumn });
    }

    loadingPanel = ( /* Code for showing loading symbol */
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );

    Total = props => {
        // console.log(props)
        const field = props.field || '';
        let count = this.state.Footertotal
        const total = fixed.reduce((acc, current) => {
            return acc + parseFloat(current[field])
        }, 0);
        const avg = total / count
        let average = parseFloat(avg).toFixed(2)
        let value = parseFloat(total).toFixed(2)
        setTimeout(() => {
            products = fixed
        }, 200);
        if (field === "hold" || field === "unhold"|| field==="Nos") {
            return (<td colSpan={props.colSpan} style={props.style} title={"Total:" + total}>Total: {total}</td>)
        }
        else {
            return (<td></td>)
        }


    };

    reorder = () => { // This function is used to save the reordered column in that order to state columns 
        let gridOrder = this.grid.columns, column = [], finalColumn = [], col = JSON.parse(JSON.stringify(this.state.columns))
        gridOrder.map(data => {
            if (data.field !== "selected") {
                column[data.orderIndex - 1] = this.state.columns.find(d => d.field === data.field)
            }
            return null
        })
        let hideColumn = this.state.columns.filter(d => d.show === false)
        finalColumn.push(...hideColumn)
        finalColumn.push(...column)
        this.setState({ columns: finalColumn, afterExportColumn: col })
        reordering = false
        // return column

    }

    handleChange = e => {
        debugger
        const fileReader = new FileReader();
        fileReader.readAsText(e.target.files[0], "UTF-8");
        fileReader.onload = e1 => {
            let newState = JSON.parse(e1.target.result)
            let oldcolumn = this.state.columns.map((d => d.field))
            let importcolumn = newState.columns.map((d => d.field))
            let l = oldcolumn.sort().join(',')
            let m = importcolumn.sort().join(',')
            if (l === m) {
                if (newState.columns !== undefined) {

                    let pushValue = newState.name
                    let existing = this.QTRtemplateName.findIndex(element => element === pushValue)
                    if (existing === -1) {
                        this.QTRtemplateName.push(pushValue)
                        localStorage.setItem('QTRtemplateName', JSON.stringify(this.QTRtemplateName));
                        this.QTRtemplateState.push(newState)
                        localStorage.setItem('QTRtemplateState', JSON.stringify(this.QTRtemplateState));
                    }
                    this.setState({ isLoading: true, columns: newState.columns, filter: newState.filter, sort: newState.sort, initTemp: newState.name, itemPage: newState.itemPerPage, group: newState.group })
                    tempdata = true
                    this.componentDidMount()
                }
                else {
                    alert("Select a valid template json file")
                }
            }

            else alert("Select a valid template json file")
        };
    };

    render() {
        const grid = (
            //Telerik Grid Component
            <Grid
                // style={{ height: '400px'}}
                data={this.state.result}
                {...this.state.dataState}
                onDataStateChange={this.dataStateChange}
                sortable={{ mode: "multiple" }}
                sort={this.state.sort}
                onSortChange={this.sortChange}
                pageable={{ pageSizes: [5, 10, 20, 25] }}
                total={this.state.Footertotal}
                resizable={true}
                groupable={{ footer: 'visible' }}
                reorderable={true}
                filterable={true}
                filter={this.state.filter}
                onFilterChange={this.filterChange}
                expandField="expanded"
                onExpandChange={this.expandChange}
                selectedField={this.state.columns.length > 1 ? 'selected' : ''}
                onSelectionChange={this.selectionChange}
                onHeaderSelectionChange={this.headerSelectionChange}
                cellRender={this.cellRender}
                ref={(g) => { this.grid = g; }}
                onColumnReorder={() => reordering = true}


            >
                <GridToolbar>

                    {/* Button to Export Excel */}
                    
                    {
                        this.state.isDrill === true && (<Button
                            // primary={true}
                            title="Normal View"
                            onClick={this.NormalView}
                        >
                            Normal View
                        </Button>)
                    }


                    {/* Button to show popup for save template */}
                    {/* <button className="k-button"
                        onClick={this.onSaveTemplate}
                        title="Save Template"
                        ref={(button) => {
                            this.anchor2 = button;

                        }}>

                        Save Template</button> */}

                    {/* Popup for save template */}
                    {this.state.showPopupOnSaveTemp && (
                        <Dialog title={"Save Template"} onClose={this.dontSaveTemplate}>
                            <p
                                style={{
                                    margin: "25px",
                                    textAlign: "center",
                                }}
                            >
                                <label>Template Name : </label>
                                {/* Input tag for getting template name to be saved */}
                                <Input value={this.state.newTemplate} maxLength="256" onChange={(e) => this.setState({ newTemplate: e.value })} />
                            </p>
                            <DialogActionsBar>
                                {/* Button to close template save popup*/}
                                <button className="k-button" onClick={this.dontSaveTemplate}>
                                    Cancel
                                </button>
                                {/* Button to save new template */}
                                <button className="k-button" onClick={this.saveTemplate} disabled={!this.state.newTemplate}>
                                    Save
                                </button>
                            </DialogActionsBar>
                        </Dialog>
                    )}

                    {/* Dropdown to show list of available templates */}
                    {/* {localStorage.getItem('QTRtemplateState') === null ? <div /> : <b style={{ fontWeight: "unset" }} title="Select Template"><ComboBox
                        style={{ width: "220px" }}
                        data={this.QTRtemplateName}
                        value={this.state.initTemp}
                        onChange={this.tempChange}
                        placeholder="Template" /></b>
                    } */}

                    {/* Checkbox to enable / disable filter in grid */}
                   {/* // <div className="col-md-12"> */}
                        <input
                            className="k-checkbox"
                            // defaultChecked={false}
                            checked={this.state.filterable}
                            id="previousNext"
                            type="checkbox"
                            onChange={e => { this.setState({ filterable: !this.state.filterable }); }}
                        />
                        <label
                            htmlFor="previousNext"
                            className="k-checkbox-label"
                        >
                            Enable Filter
                        </label>
                    {/* </div> */}

                    {/* Input field for Search within grid */}
                    <Input style={{ marginLeft: 20 }} maxLength="256" title='Search' type='search' onChange={this.searchData} placeholder={'Search'} value={this.state.searchvalue} />

                    {/* Button to switch from grid component to chart component */}
                    <Button
                        // primary={true}
                        title="Export Excel"
                        onClick={this.export}
                    >
                        Export to Excel
                    </Button>
                    <Button
                        // primary={true}
                        title="View as Detail"

                        onClick={() => {
                            debugger
                            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                                this.setState({ navopen: true })
                            }
                            else {
                                this.setState({ navopen: false })
                            }
                            setTimeout(() => {
                                this.props.isDrill(this.props.FullDetail,this.props.fromdate,this.props.todate)
                            }, 200);


                        }}
                    >
                        View as Detail
                    </Button>
                    <Button
                        // primary={true}
                        title="View as Chart"

                        onClick={() => {
                            let columnName = this.state.columns.filter(col => col.date === "yes")
                            this.setState({ viewChart: true })
                            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                                this.setState({ navopen: true });
                            }


                            setTimeout(() => {
                                this.props.chartData(this.state.navopen, this.state.chartData, columnName, this.state.backgrid, this.state.searchvalue, this.state.input)
                            }, 100);




                        }}
                    >
                        View as Chart
                    </Button>


                    {/* <Button onClick={() => { this.upload.click() }} title='Choose a template json file from downloads,On importing it will automatically added to local storage'>Import Template File</Button> */}
                    <input ref={(ref) => this.upload = ref} type="file" accept=".json" id="getFile" onChange={this.handleChange} style={{ width: "90px", display: "none" }} />
                    {/* Refresh icon to show popup for refresh */}
                    <ul><li title="Refresh" style={{ marginLeft: "-30px" }} ref={(li) => this.anchor = li} onClick={this.onRefresh}><BiIcons.BiRefresh color='#042e68' size='2em' /></li></ul>

                    {/* Popup for refresh grid */}
                    {this.state.showPopupOnRefresh && (
                        <Dialog title={"Please confirm"} onClose={this.no}>
                            <p
                                style={{
                                    margin: "25px",
                                    textAlign: "center",
                                }}
                            >
                                By refreshing, Filter and Search data will be cleared out. Are you sure want to continue?
                            </p>
                            <DialogActionsBar>

                                {/* Button to close and cancel refresh  */}
                                <button className="k-button" onClick={this.no}>
                                    No
                                </button>

                                {/* Button to refresh grid */}
                                <button className="k-button" onClick={this.yes}>
                                    Yes
                                </button>
                            </DialogActionsBar>
                        </Dialog>
                    )}

                </GridToolbar>

                {/* Column for MultiSelect rows */}
                {/* {
                    this.props.columndate.map((column, idx) =>
                     

                                <GridColumn
                                    key={idx}
                                    field={column}
                                    format=""
                                    title={column}
                                    filter="text"
                                    filterable={this.state.filterable}
                                    width="150"
                                    footerCell={this.Total}
                                   
                                    columnMenu={ // Grid props for column menu
                                        props =>
                                            <CustomColumnMenu
                                                {...props}
                                                columns={this.state.columns}
                                                products={this.state.data}
                                                onColumnsSubmit={this.onColumnsSubmit}
                                                filterable={this.state.filterable}
                                            />
                                    }
                                /> 
                        
                    )
                } */}
                {this.state.columns.length > 0 && (<GridColumn
                    field="selected"
                    width="0px"
                    filterable={false}
                    hidden={true}
                    headerSelectionValue={
                        this.state.data.findIndex(dataItem => dataItem.selected === false) === -1
                    } />)}

                {/* Code to show specific columns */}

                {
                    this.state.columns.map((column, idx) =>
                        column.show && (

                            <GridColumn
                                key={idx}
                                field={column.field}
                                format={column.format}
                                title={column.title}
                                filter={column.filter}
                                filterable={this.state.filterable}
                                width={column.minWidnt}
                                footerCell={this.Total}
                                headerCell={ // Grid props to do changes in column header
                                    props =>

                                        <Header
                                            {...props}
                                            idx={idx}
                                            minwidth={column.minWidnt}
                                            changeHandler={this.changeStuff.bind(this)}
                                        />
                                }
                                columnMenu={ // Grid props for column menu
                                    props =>
                                        <CustomColumnMenu
                                            {...props}
                                            columns={this.state.columns}
                                            products={this.state.data}
                                            onColumnsSubmit={this.onColumnsSubmit}
                                            filterable={this.state.filterable}
                                        />
                                }
                            />
                        )
                    )
                }

            </Grid>
        )

        return (

            <div className='move-grid-body' id="grid-body">
                <h5>{this.props.title}</h5> {/* To show normal grid */}
                {(this.state.isLoading) && (this.loadingPanel)}

                <ExcelExport // Telerik ExcelExport compnent to export grid data
                    fileName={this.props.title}
                    data={
                        this.state.data.filter((item) => item.selected === true).length > 0 ?
                            this.state.data.filter((item) => item.selected === true) : products
                    }
                    ref={exporter => this._export = exporter}
                >
                    {grid}

                </ExcelExport>
                <br />
            </div>
        );
    }
}
