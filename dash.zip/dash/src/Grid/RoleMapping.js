
import * as React from 'react';
import { process, filterBy, orderBy } from '@progress/kendo-data-query';
import {
    Grid, GridColumn, GridToolbar
} from '@progress/kendo-react-grid';
import { GridService } from '../services/grid.services'
import { Button } from '@progress/kendo-react-buttons';
import { MultiSelect } from '@progress/kendo-react-dropdowns'
import { Input } from "@progress/kendo-react-inputs";
import { Rolemapping_column } from './rolemappingcolumn';
import { CustomColumnMenu } from './customColumnMenu.js';
import EditForm from './EditForm';
import AddForm from './AddForm'
import '../App.css';



let products = [], tempdata = false, reordering = false
const EditCommandCell = (props) => {
    return (
        <td>
            <div style={{ display: "flex" }}>
                <button
                    className="k-button k-primary"
                    onClick={() => props.enterEdit(props.dataItem)}
                >
                    Edit
      </button>
                <button
                    className="k-button"
                    style={{ color: "white", backgroundColor: "red" }}
                    onClick={() => props.delete(props.dataItem)}
                >
                    Delete
      </button>
            </div>
        </td>
    );
};
export default class App extends React.Component {
    constructor(props) {
        super(props); /* Gets Props 'name, input, columns, getData, aggregates, chartData ' */

        const dataState = this.createDataState({
            take: 5,
            skip: 0,
        });

        // this.getData = this.props.getData()

        // Initialize the state of the component
        this.state = {
            path: 'http://inet:81/OIVADashBoard/GroupSummary',
            data: [],
            AllRole: [],
            roledata: [],
            addForm: false,
            setMinWidth: false,
            columns: Rolemapping_column,
            gridCurrent: 0,
            isLoading: false,
            showPopupOnRefresh: false,
            showPopupOnSaveTemp: false,
            inputSearchValue: null,
            searchvalue: "",
            newTemplate: null,
            input: { "CustomerID": "1" },
            exporting: false,
            filterable: false,
            chartData: [],
            viewChart: false,
            popupChart: false,
            itemPage: 5,
            group: [],
            filter: { logic: "", filters: [] },
            reortered: false,



            navopen: false,

            ...dataState
        };
    }
    minGridWidth = 0;
    MyEditCommandCell = (props) => (
        <EditCommandCell {...props} enterEdit={this.enterEdit} delete={this.delete} />
    );
    
    enteradd = () => {
        debugger
        this.setState({ addForm: true, roledata: this.state.AllRole })
    }
    
    delete = (item) => {
        debugger
        // console.log(item)
        this.setState({ isLoading: true })
        let dat = this.state.data
        let input = {};
        input["UserID"] = item.userid;
        input["IsActive"] = 0
        input["RoleID"] = item.roleid
        GridService.EditRole(input).then(response => {
            let d = response
            if (d.response === "Updated Successfully") {

                GridService.Rolemapping(this.state.input).then(response => {
                    let d = response
                    let data = JSON.parse(d.response)
                    products = data.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                    this.setState({
                        data: products, columns: this.state.columns, isLoading: false, ...this.createDataState({
                            take: this.state.itemPage,
                            skip: 0,
                            group: this.state.group,
                            sort: this.state.sort,
                            filter: this.state.filter
                        })
                    })
                }).catch(err => {
                    console.log("error", err)
                    this.setState({ isLoading: false })

                });
            }
        }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false })

        });
    }
    enterEdit = (item) => {
        debugger
        let role = []
        let rol = {}
        this.state.AllRole.map((d) => {
            if (item.roleid !== d.userroleid) {
                role.push(d)

            }
        })
        rol['ID'] = item.ID
        rol['roleid'] = item.roleid
        rol['rolename'] = item.rolename
        rol['selected'] = item.selected
        rol['usercode'] = item.usercode
        rol['userid'] = item.userid
        rol['username'] = item.username
        item['rol'] = rol
        setTimeout(() => {
            this.setState({
                openForm: true,
                editItem: item,
                roledata: role
            });
        }, 100);
    };

    handleSubmit = (event) => {
        debugger
        // console.log("hadlesumit", event)
        let input = {};
        input["UserID"] = event.userid;
        input["IsActive"] = 1
        input["RoleID"] =event.rol.userroleid
        GridService.EditRole(input).then(response => {
            this.setState({ isLoading: true })
            let d = response
            if (d.response === "Updated Successfully") {
                this.setState({
                    data: this.state.data.map((item) => {
                        if (event.usercode === item.usercode) {
                            item.usercode = event.usercode;
                            item.ID = event.ID;
                            item.roleid = event.rol.userroleid
                            item.rolename = event.rol.rolename
                            item.selected = event.selected
                            item.userid = event.userid
                            item.username = event.username
                        }

                        return item;
                    }),
                    openForm: false, isLoading: false
                });
            }
        }).catch(err => {
            console.log("error", err)
            this.setState({ openForm: false, isLoading: false })

        });

    };
    handleCancelEdit = () => {
        this.setState({
            openForm: false,
        });
    };
    add = (event) => {
        debugger
        let input = {};
        input["EmpCode"] = event.usercode;
        input["EmpName"] = event.username;
        input["CustomerID"] = "1";
        input["RoleID"] = event.rolename.userroleid
        this.setState({ isLoading: true, addForm: false })
        GridService.addNewEmp(input).then(response => {
            let d = response
            if (d.response === "Saved Successfully") {
                GridService.Rolemapping(this.state.input).then(response => {
                    let d = response
                    let data = JSON.parse(d.response)




                    products = data.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                    this.setState({
                        data: products, columns: this.state.columns, isLoading: false, ...this.createDataState({
                            take: this.state.itemPage,
                            skip: 0,
                            group: this.state.group,
                            sort: this.state.sort,
                            filter: this.state.filter
                        })
                    })
                }).catch(err => {
                    console.log("error", err)
                    this.setState({ isLoading: false })

                });
            }



        }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false })

        });
    };
    insertItem = (item) => {
        products.unshift(item);
        return products;
    };

    componentDidMount() {
        debugger

        

        // Function to fetch data from api and load it to grid

        this.setState({ isLoading: true })

        GridService.Rolemapping(this.state.input).then(response => {
            let d = response
            let data = JSON.parse(d.response)
            products = data.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
            GridService.GetAllRole(this.state.input).then(response => {
                let d = response
                let role = JSON.parse(d.response)
                console.log(role, "pree")
                setTimeout(() => {
                    this.setState({ AllRole: role })
                }, 100);
            }).catch(err => {
                console.log("error", err)
                this.setState({ isLoading: false })

            });
            this.setState({
                data: products, columns: this.state.columns, isLoading: false, ...this.createDataState({
                    take: this.state.itemPage,
                    skip: 0,
                    group: this.state.group,
                    sort: this.state.sort,
                    filter: this.state.filter
                })
            })
        }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false })

        });





    }



    // Executes every time when a state is created
    createDataState(dataState) {
        const groups = dataState.group;
        if (groups) { groups.map(group => group.aggregates = this.state.aggregates); }
        const result =products.slice(dataState.skip,dataState.skip+dataState.take);
        if (tempdata === true || groups) {
            let total = result.total, newDataState = dataState, excel, take = dataState.take;
            newDataState.take = total
            newDataState.group = []
            excel = process(products.slice(0), newDataState).data
            tempdata = false
            newDataState.group = groups
            products = excel
            this.setState({ isLoading: false })
            newDataState.take = take
        }
        return {
            result: result,
            dataState: dataState,
        };
    }

    // Executes every time when a state is changed
    dataStateChange = (event) => {
        this.setState(this.createDataState(event.dataState));
    }

    // Executes on the column menu submit
    onColumnsSubmit = (columnsState) => {
        this.setState({
            columns: columnsState
        });
    }

    expandChange = (event) => { // Executes on expand and close of grouped data 
        event.dataItem[event.target.props.expandField] = event.value;
        this.setState({
            result: Object.assign({}, this.state.result),
            dataState: this.state.dataState
        });
    }
    pageChange = (event) => { // Executes on page change in grid
        this.setState({
            skip: event.page.skip,
            take: event.page.take
        });
    }

    searchData = e => { // Function for common search in grid 
        let value = e.target.value;
        this.setState({ searchvalue: e.target.value })
        let field = this.state.columns.map(column => { return { field: column.field, operator: "contains", value: value } })
        let filter = {
            logic: "or",
            filters: field
        };
        products = filterBy(this.state.data, filter)
        this.dataStateChange(this.state)
    };

    filterChange = (event) => { // Function for filter change
        products = filterBy(this.state.data, event.filter)
        this.setState({
            filter: event.filter
        });
        this.dataStateChange(this.state)
        // products=this.state.refreshData
    }

    selectionChange = (event) => { // Executes when select or unselect header select in grid
        const data = this.state.data.map(item => {
            if (item.ID === event.dataItem.ID) {
                item.selected = !event.dataItem.selected;
            }
            return item;
        });
        this.setState({ data });
    }

    headerSelectionChange = (event) => { // Executes when select or unselect a row in grid
        const checked = event.syntheticEvent.target.checked;
        const data = this.state.data.map(item => {
            item.selected = checked;
            return item;
        });
        this.setState({ data });
    }

    cellRender(tdElement, cellProps) {  // This function is used for any changes in the cells in grid

        if (cellProps.dataItem.aggregates !== undefined) {
            let i = 0, key = Object.keys(cellProps.dataItem.aggregates)
            if (cellProps.rowType === 'groupFooter') {
                for (i; i < key.length; i++) {
                    if (cellProps.field === key[i]) {
                        return (
                            <td data-toggle="tooltip" >
                                <b title={"Sum: " + parseFloat(cellProps.dataItem.aggregates[key[i]].sum).toFixed(2)}>Sum: {parseFloat(cellProps.dataItem.aggregates[key[i]].sum).toFixed(2)}</b><br />
                                <b title={"Average: " + parseFloat(cellProps.dataItem.aggregates[key[i]].average).toFixed(2)}> Average: {parseFloat(cellProps.dataItem.aggregates[key[i]].average).toFixed(2)}</b>
                            </td>
                        );
                    }
                }

            }
        }
        if (cellProps.field === "selected") {
            return (tdElement)
        }
        else if (tdElement) {

            if (cellProps.field === 'ID') {
                return (<td className="extraID" style={{ textAlign: 'center' }} title={tdElement.props.children}>{tdElement.props.children}</td>)
            }
            else {

                return (<td className="extra-number" style={{ textAlign: 'center' }} title={tdElement.props.children}>{tdElement.props.children}</td>)
            }

        }
        return (tdElement)
    }




    sortChange = (event) => { // Function for sorting in grid
        this.setState({
            data: this.getProducts(event.sort),
            sort: event.sort
        });
        products = this.getProducts(event.sort)
        this.dataStateChange(this.state)

    }

    getProducts = (sort) => {
        return orderBy(products, sort);
    }



    loadingPanel = ( /* Code for showing loading symbol */
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );


    render() {
        const grid = (
            //Telerik Grid Component
            <Grid
                // style={{ width: '90%', margin: 'auto' }}
                data={this.state.result}
                {...this.state.dataState}
                onDataStateChange={this.dataStateChange}
                sortable={{ mode: "multiple" }}
                sort={this.state.sort}
                onSortChange={this.sortChange}
                pageable={{ pageSizes: [5, 10, 20, 25] }}
                resizable={true}
                total={this.state.data.length}
                // groupable={{ footer: 'visible' }}
                reorderable={true}
                filterable={true}
                filter={this.state.filter}
                onFilterChange={this.filterChange}
                expandField="expanded"
                onExpandChange={this.expandChange}
                selectedField={this.state.columns.length > 1 ? 'selected' : ''}
                onSelectionChange={this.selectionChange}
                onHeaderSelectionChange={this.headerSelectionChange}
                cellRender={this.cellRender}
                ref={(g) => { this.grid = g; }}
                onColumnReorder={() => reordering = true}


            >
                <GridToolbar>


                        <input
                            className="k-checkbox"
                            // defaultChecked={false}
                            checked={this.state.filterable}
                            id="previousNext"
                            type="checkbox"
                            onChange={e => { this.setState({ filterable: !this.state.filterable }); }}
                        />
                        <label
                            htmlFor="previousNext"
                            className="k-checkbox-label"
                        >
                            Enable Filter
                                </label>

                    {/* Input field for Search within grid */}
                    <Input style={{ marginLeft: 20 }} maxLength="256" title='Search' type='search' onChange={this.searchData} placeholder={'Search'} value={this.state.searchvalue} />
                    <Button
                        primary={true}
                        title="" onClick={() => this.enteradd()}>Add New
                            </Button>
                    {/* Button to switch from grid component to chart component */}

                </GridToolbar>

                {/* Column for MultiSelect rows */}
                {this.state.columns.length > 0 && (<GridColumn
                    field="selected"
                    width="0px"
                    filterable={false}
                    hidden={true}
                    headerSelectionValue={
                        this.state.data.findIndex(dataItem => dataItem.selected === false) === -1
                    } />)}

                {/* Code to show specific columns */}

                {
                    this.state.columns.map((column, idx) =>
                        column.title !== "" ?
                            column.show && (
                                <GridColumn
                                    key={idx}
                                    field={column.field}
                                    format={column.format}
                                    title={column.title}
                                    filter={column.filter}
                                    filterable={this.state.filterable}
                                    width={column.minWidnt}
                                    columnMenu={ // Grid props for column menu
                                        props =>
                                            <CustomColumnMenu
                                                {...props}
                                                columns={this.state.columns}
                                                products={this.state.data}
                                                onColumnsSubmit={this.onColumnsSubmit}
                                                filterable={this.state.filterable}
                                            />
                                    }
                                />
                            ) : <GridColumn cell={this.MyEditCommandCell}
                                filterable={false} />
                    )
                }


            </Grid>
        )

        return (
            
            <div className='move-grid-container' id='grid-container'>
            <div className='move-grid-body' id="grid-body">
                <div className="Roleheader"><h5 style={{ textAlign: 'center' }}>Role mapping</h5>

                    {(this.state.isLoading) && (this.loadingPanel)}


                    {grid}
                    {this.state.openForm && (
                        <EditForm
                            cancelEdit={this.handleCancelEdit}
                            onSubmit={this.handleSubmit}
                            item={this.state.editItem}
                            role={this.state.roledata}
                        />
                    )}
                    {this.state.addForm && (
                        <AddForm
                            cancelEdit={this.handleCancelEdit}
                            onSubmit={this.add}

                            role={this.state.roledata}
                        />
                    )}

                </div>
            </div>
            </div>
   
        );
    }
}
