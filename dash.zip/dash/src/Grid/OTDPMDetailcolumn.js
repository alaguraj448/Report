export const OTDPMDetail_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "Stage",
        title: "Stage",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
    
]