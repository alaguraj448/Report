export const OTD_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "Title",
        title: "",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "Total",
        title: "Overall OTD MTD",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "{0:0.00}" ,
        date:"no"
    }
]