export const OTDMonth_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "Title",
        title: "",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
   
]