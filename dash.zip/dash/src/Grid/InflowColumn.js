export const Inflow_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "Title",
        title: "Title",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "RType",
        title: "RType",
        minWidnt: 325,
        filter: "text",
        show: true,
        format: ""
    },
  
    {
        field: "Total",
        title: "Overall OTD MTD",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    }
    
]