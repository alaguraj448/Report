import * as React from "react";
import { Dialog } from "@progress/kendo-react-dialogs";
import { Form, Field, FormElement } from "@progress/kendo-react-form";
import { Input, NumericTextBox } from "@progress/kendo-react-inputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";


const EditForm = props => {
  return <Dialog title='Exchange Rate' onClose={props.cancelEdit}>
        <Form onSubmit={props.onSubmit} initialValues={props.item} render={formRenderProps => <FormElement style={{
      maxWidth: 650
    }}>
              <fieldset className={"k-form-fieldset"}>
                <div className="mb-3">
                  <Field name={"Exchange"} component={DropDownList} data={props.data} textField={"Descriptions"} label={"Exchange Rate"} />
                </div>
                
              </fieldset>
              <div className="k-form-buttons">
                <button type={"submit"} className="k-button k-primary" disabled={!formRenderProps.allowSubmit}>
                  Add
                </button>
                <button type={"submit"} className="k-button" onClick={props.cancelEdit}>
                  Cancel
                </button>
              </div>
            </FormElement>} />
      </Dialog>;
};

export default EditForm;