import React from "react";
import '../App.css';

import { ComboBox } from '@progress/kendo-react-dropdowns'
import {
    Chart,
    ChartLegendItem,
    ChartArea,
    ChartTitle,
    ChartSeries,
    ChartSeriesItem,
    ChartSeriesLabels,
    ChartCategoryAxis,
    ChartCategoryAxisTitle,
    ChartCategoryAxisItem,
    ChartValueAxis,
    ChartValueAxisItem,
    ChartValueAxisTitle,
    ChartLegend,
    exportVisual
} from '@progress/kendo-react-charts';
import { GridService } from '../services/grid.services'

import 'hammerjs';
import { exportPDF } from '@progress/kendo-drawing';
import { Button } from '@progress/kendo-react-buttons';
import { exportImage } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { DropDownList } from '@progress/kendo-react-dropdowns';
import DrillDown from '../Grid/SpeedDrillGrid'
import { Path, Text, Group, geometry, Element, Rect as RectShape } from '@progress/kendo-drawing';

const { Point, Rect, Size } = geometry;

const customVisual = (props) => {
            // Create rectangular shape on top of which the label will be drawn
            const rectOptions = { stroke: { width: 2, color: '#fff' }, fill: { color: '#fff' } };
            const rectGeometry = new Rect(new Point(0, 3), new Size(60, 10));
            const rect = new RectShape(rectGeometry, rectOptions);

            // Create the lines used to represent the custom legend item
            const pathColor = props.options.markers.border.color;
            const path1 = new Path({
                stroke: {
                    color: pathColor,
                    width: 17,
                    
                }
            });

           

            // The paths are constructed by using a chain of commands
            path1.moveTo(0, 40).lineTo(40, 40).close();
            // path2.moveTo(15, 7).lineTo(25, 7).close();

            // Create the text associated with the legend item
            const labelText = props.series.name;
            const labelFont = props.options.labels.font;
            const fontColor = props.options.labels.color;
            const textOptions = { font: "400 18px system-ui, -apple-system, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, Liberation Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji",fontSize:"26px", fill: { color: fontColor } };
            const text = new Text(labelText, new Point(50, 28), textOptions);

            // Place all the shapes in a group
            const group = new Group();

            group.append(rect, path1, text);
            // set opacity if the legend item is disabled
            if (!props.active) {
                group.opacity(0.5);
            }

            return group;
}

const valueAxis = [{
    name: "Speed",


}, {
    name: "Article",


}]
const axisCrossingValue = [12, 0]
export default class ViewChart extends React.Component {

    constructor(props) {
        super(props);
        // this.getData = this.props.getData()
        this.state =
        {
            // data: [...data],
            chartType: "column",
            viewGrid: false,
            jsonData: [],
            title: "",
            chartnavopen:false,
            categories: [],
            navopen: this.props.navopen,
            chartDatavalue: [],
            json: [],
            sort: [],
            input: [this.props.detailinput],
            callchart: true,
            categoryField: "",
            fieldname: "",
            categorykey: "",
            categorykey2: "",
            charts: [], /*["area","bar","boxPlot","bubble","bullet","donut","funnel","line","pie","polar","radar","rangeArea","rangeBar","scatter","waterfall"] this are the available chart type need to transfer data accordingly */
            sortingOrder: "Sort Descending by Alphabet",
            Sort: true,
            drillChartToGrid: [],
            IsDrillChart: false,
            isLoading: false,
            fieldName: [],
            refreshChart: false
            //sample data for donut chart
        }

    }
    componentDidMount = () => {
        //while component mounting itself data are set to state
        debugger
        // let legends=Object.keys(this.props.chartData[0])
        // console.log(legends)
        //   console.log("plese",this.props.chartData)
        if (this.props.navopen) {
            document.getElementById('chart-container').style.marginLeft = "150px";

            document.getElementById('chart-bordy').style.left = "120px";
            // document.getElementById('chart-bordy').style.marginLeft = "83px"
        }


        this.setState({ charts: ["column", "area", "line", "bar"] })
     
            this.setState({ isLoading: true })
     
        GridService.SpeedDetailedReport(this.props.input).then(response => {
            let d = response
            let data = JSON.parse(d.response)
            this.setState({ jsonData: data, isLoading: false, refreshChart: true })
            //Here we had just separated data and value for drawing charts, so the fields which need to be compare are separated as name and data
            setTimeout(() => {
                let Mean = this.state.jsonData.map(item => item.Mean)
                let Median = this.state.jsonData.map(item => item.Median)


                let lastUpdate = this.state.jsonData[0].LastUpdatedOn
                // this.props.lastUpdatedate(lastUpdate)

                this.setState({

                    json: [
                        {
                            name: "Mean",
                            data: Mean,
                            type: "bar",

                            seriesVisible: true
                        }
                        , {
                            name: "Median",
                            data: Median,
                            type: "bar",

                            seriesVisible: true
                        }
                    ]
                })
                this.categories();
                // console.log(this.state.json)
            }, 100);
            setTimeout(() => {
                this.setState({ refreshChart: false })
            }, 200);
            this.setState({ yaxisname: "", xaxisname: "" })


        }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false })

        });


    }
    drilldownChart = (e) => {
        debugger
        let status = ""
        if (e.series.name === "Sample size,Online First Integra" || e.series.name === "Sample size,Not Online First Integra") {
            if (e.series.name === "Sample size,Online First Integra") {
                status = "Online"
            }
            if (e.series.name === "Sample size,Not Online First Integra") {
                status = "NotOnline"
            }
            let input = this.props.input;
            input["MonthName"] = e.category
            input["Status"] = status
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true })
            }
            else {
                this.setState({ navopen: false })
            }
            setTimeout(() => {

                this.setState({ input: input, callchart: false })
            }, 200);
        }
    }


    onPDFExportClick = () => {
        //export the chart as PDF
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportPDF(chartVisual, {
                paperSize: "A2",
                landscape: true
            }).then(dataURI => saveAs(dataURI, this.props.fileName));
        }
    }

    onImageExportClick = () => {
        //export the chart as image
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportImage(chartVisual).then(dataURI => saveAs(dataURI, this.props.fileName));
        }
    }

    categories = () => {
        //this method used to set, on what basics the chart to be view (to set category)
        debugger

        var categories = []



        this.state.jsonData.map((item, i) => {

            return (categories.push(item["Workflow"]))

        })


        this.setState({ categories: categories })


    }
    labelContent = (e) => {
        //for label for chart
        if (e.value !== 0) {
            return (e.value);
        }
        else {
            return ("")
        }

    }




    viewGrid = () => {
        debugger
        if (document.getElementById('chart-bordy').style.left === "120px") {
            this.setState({ chartnavopen: true })
        }

        setTimeout(() => {
            this.props.workflow(this.state.chartnavopen, this.props.fromdate, this.props.todate)
        }, 200);


    }

    //loader for chart
    loadingPanel = (
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );

    backdrill = () => {
        debugger
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {
            this.setState({ callchart: true })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('chart-bordy').style.left = "120px";
                // document.getElementById('chart-bordy').style.marginLeft = "83px"
                document.getElementById('chart-container').style.marginLeft = "150px";

            }
            else {
                document.getElementById('chart-container').style.marginLeft = "15px";

                document.getElementById('chart-bordy').style.left = "60px";
                // document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }, 200);
    }
    handleChartRefresh = (chartOptions, themeOptions, chartInstance) => {
        if (this.state.refreshChart) {
            chartInstance.setOptions(chartOptions, themeOptions);
        }
    };
    changeChart = (value) => {
        //used to set the chart type
        this.setState({ chartType: value, refreshChart: true })
        setTimeout(() => {
            this.setState({ refreshChart: false })
        }, 200);
    }
    func = (e) => {
        this.setState({ refreshChart: true })
        let newjson = this.state.json
        newjson.map((i) => {

            if (i.name === e.text) {
                if (i.seriesVisible === true) {
                    // console.log(i.name,e.text)
                    i.seriesVisible = false
                }

                else {
                    i.seriesVisible = true
                }
            }
        })
        this.setState({ json: newjson })

        setTimeout(() => {
            this.setState({ refreshChart: false })
        }, 200);
    }
    render() {
        return (

            // this.state.callchart === true ?
            <div className='chart-bordy' id="chart-bordy" style={{marginLeft:"50px"}}>
                {(this.state.isLoading) && (this.loadingPanel)}
                <div className="ChartBorder">
                        <div className="chartheader">  
                         <h5>{this.props.title}</h5> 

                         <div className="Chartinnerheader"><DropDownList data={this.state.charts} defaultValue="column" value={this.state.chartType} onChange={(event) => { this.changeChart(event.target.value) }} />
                            <Button primary={true} title="Export as image" onClick={this.onImageExportClick}>Export as Image</Button>
                            <Button primary={true} title="Export as PDF" onClick={this.onPDFExportClick}>Export as PDF</Button>

                            {/* <Button primary={true} title="View as Workflowise" onClick={() => this.viewGrid()}>View as Workflowise</Button> */}

                        </div>
                        </div>


                        <Chart style={{ height:350,border:"1px solid #DEDEDE",margin:"10px" }} pannable={true} zoomable={{
                            mousewheel: {
                                lock: "y",
                            },
                            selection: {
                                lock: "y",
                            },
                        }} ref={(cmp) => this._chart = cmp} onRefresh={this.handleChartRefresh} onLegendItemClick={(e) => { this.func(e) }}  >
                            <ChartArea margin={20} width={'1110'} />
                            {/* <ChartTitle text={this.props.title} /> */}
                            <ChartLegend position="bottom" orientation={'horizontal'}>
          <ChartLegendItem visual={customVisual}/>
        </ChartLegend>  
                            <ChartCategoryAxis>

                                <ChartCategoryAxisItem labels={{
                                    rotation: 'auto'
                                }}  categories={this.state.categories} >
                                    <ChartCategoryAxisTitle text={this.state.yaxisname} font='bold 14px Arial, sans-serif' />
                                </ChartCategoryAxisItem>

                            </ChartCategoryAxis>
                            {/* <ChartValueAxis>
                                {valueAxis.map((item, idx) => <ChartValueAxisItem key={idx} name={item.name} />)}
                            </ChartValueAxis> */}

                            <ChartSeries>
                                {
                                    this.state.json.map((item, i) => {

                                        return (<ChartSeriesItem key={i} type={this.state.chartType} data=
                                            {item.data} name={item.name} visible={item.seriesVisible}  tooltip={{ visible: true }}   >
                                            <ChartSeriesLabels content={this.labelContent} />
                                        </ChartSeriesItem>)


                                    })
                                }


                            </ChartSeries>
                        </Chart>



                    </div>

                </div>
                // :
                //  <div className='move-grid-container' id='grid-container'><Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backdrill}>Go Back</Button>
                //              <DrillDown navopen={this.state.navopen} input={this.props.input} DetailedColumn={this.props.SpeedDetailColum} Detailedaggregates={this.props.speedDetailaggregate} /></div>


                );
    }
}

