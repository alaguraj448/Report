import * as React from 'react';

import { Calendar } from '@progress/kendo-react-dateinputs';
import { setYear } from '@progress/kendo-date-math/dist/npm/set-year';

export class CustomCalendar extends React.Component {
  render() {
    return (
      <Calendar
        bottomView="year"
        topView="year"
        min={this.props.min}
        max={this.props.max}
        value={this.props.value}
        onChange={this.props.onChange}
      />
    );
  }
}
