export const CCReport_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "Track",
        title: "Tracks",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "hours",
        title: "Hours",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "days",
        title: "Days",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
]