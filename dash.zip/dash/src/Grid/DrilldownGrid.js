import React from "react";
import GridComponent from './GridComponent'
// import {GridService} from '../services/grid.services'
import ChartContainer from '../Chart/GridChart';
import {new_column} from './newColumns'

export default class Footer extends React.Component {
    state={
        columns:new_column,
        path: 'http://inet:81/OIVADashBoard/OIVADashboardOverall',
        input:this.props.input,
        callGrid:true,
        callAgain:false,
        name:this.props.data,
        callchart:false,
        chartData:[],
        Griddata:[],
        gridsearchValue:"",    
        isComing:false,
        aggregates: [
          { field: 'MTDActual', aggregate: 'sum' },
          { field: 'QTDActual', aggregate: 'sum' },
          { field: 'YTDActual', aggregate: 'sum' },
          { field: 'MTDActual', aggregate: 'average' },
          { field: 'QTDActual', aggregate: 'average' },
          { field: 'YTDActual', aggregate: 'average' },
      ]
  }

  ToGridData = (navopen) => {
    this.setState({ isComing: true })

    this.setState({ navopen: navopen })
    this.setState({ callchart: !this.state.callchart })
}
FalseIsComing = () => {
    this.setState({ isComing: false })
}
chartData = (navopen, data, Griddata, search) => {
  debugger
  this.setState({ Griddata: Griddata })
  this.setState({ chartData: data })
  this.setState({ navopen: navopen })
  this.setState({ callchart: !this.state.callchart })
  this.setState({ gridsearchValue: search })
}
  render() {
    // console.log(this.props.input)
    const grid=(<GridComponent 
      columns1={this.props.column1}
      columns2={this.props.column2}
      columns3={this.props.column3}
      columns4={this.props.column4}
      columns5={this.props.column5} name={this.state.name} input={this.state.input} FalseIsComing={this.FalseIsComing} aggregates={this.state.aggregates} columns={this.state.columns} chartData={this.chartData}IsKAM={this.props.IsKAM} 	
      IsKAMHead={this.props.IsKAMHead} IsDrill={true} isComing={this.state.isComing} 	navopen={this.state.navopen} Griddata={this.state.Griddata}gridsearchValue={this.state.gridsearchValue} />)

    return (
        !this.state.callchart ? <div  style={{ marginTop:'-10px'}} >
        <h4 style={{textAlign:'center', marginTop:'0px', marginBottom:'0px'}}>{this.props.data} Report</h4>
        {grid}
        </div> : <ChartContainer columns1={this.props.column1}
                columns2={this.props.column2}
                columns3={this.props.column3}
                columns4={this.props.column4}
                columns5={this.props.column5}chartData={this.state.chartData} input={this.state.input} chartDatafunc={this.ToGridData} navopen={this.state.navopen} CustomerFilterData={this.props.CustomerFilterData} Customer={this.props.Customer} />

    );
  }
}