export const FullDetail_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "JournalName",
        title: "Journal",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "BookCode",
        title: "BookCode",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "JournalTitle",
        title: "Journal Title",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
     {
        field: "StageGroup",
        title: "Stage Group",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "Stage",
        title: "Stage",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PMUserID",
        title: "Project Manager",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "categoryName",
        title: "Work Flow",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "ReceivedDate",
        title: "Received Date (CATS)",
        minWidnt: 215,
        filter: "date",
        show: true,
        format: "{0:d}"
            
          
    },
    {
        field: "PMReceivedDate",
        title: "Received Date (iTracks)",
        minWidnt: 215,
        filter: "date",
        show: true,
        format: "{0:d}"
    },
    {
        field: "DueDate",
        title: "Due Date (CATS)",
        minWidnt: 185,
        filter: "date",
        show: true,
        format: "{0:d}"
    },
    {
        field: "OTDMet",
        title: "OTD Met",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Status",
        title: "Status",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "ProdDespatchDate",
        title: "Production Despatched Date",
        minWidnt: 250,
        filter: "date",
        show: true,
        format: "{0:d}"
    }, {
        field: "DespatchDate",
        title: "Dispatch Date",
        minWidnt: 185,
        filter: "date",
        show: true,
        format: "{0:d}"
    }, {
        field: "Hours",
        title: "Hour(s)",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "mspages",
        title: "MS Pages",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "QueryDate",
        title: "Query Date",
        minWidnt: 185,
        filter: "date",
        show: true,
        format: "{0:d}"
    },
    {
        field: "ReplyDate",
        title: "Reply Date",
        minWidnt: 185,
        filter: "date",
        show: true,
        format: "{0:d}"
    }, {
        field: "estimatedpages",
        title: "Estimated Pages",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "TypesetPages",
        title: "Typeset Pages (in Pages)",
        minWidnt: 220,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "TypesetPagesKBs",
        title: "Typeset Pages(in KBs)",
        minWidnt: 220,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "RFIRaiseDate",
        title: "RFI Raised Date",
        minWidnt: 185,
        filter: "date",
        show: true,
        format: "{0:d}"
    },
    {
        field: "InvoiceDate",
        title: "Invoice Date",
        minWidnt: 185,
        filter: "date",
        show: true,
        format: "{0:d}"
    },
    {
        field: "ISBilled",
        title: "Billed",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "VolumeNo",
        title: "Volume No.",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "IssueNo",
        title: "Issue No.",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Division",
        title: "Division",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Country",
        title: "Country",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "PE",
        title: "Product Editor Name",
        minWidnt: 230,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "InternalRemarks",
        title: "Internal Remarks",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "ExternalRemarks",
        title: "External Remarks",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
]