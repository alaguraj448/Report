export const Rolemapping_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 100,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "usercode",
        title: "Employee Code",
        minWidnt: 260,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "username",
        title: "Employee Name",
        minWidnt: 260,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "rolename",
        title: "Role",
        minWidnt: 260,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Edit",
        title: "",
        minWidnt: 100,
        filter: "text",
        show: true,
        format: ""
    }

]