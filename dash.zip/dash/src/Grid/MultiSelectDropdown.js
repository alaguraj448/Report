import React from "react";
import { ComboBox } from '@progress/kendo-react-dropdowns';
import { MultiSelect } from '@progress/kendo-react-dropdowns'
import { GridService } from '../services/grid.services'
import GridComponent from './GridComponent';
import ChartContainer from '../Chart/GridChart';
import { new_column } from './newColumns';
import { filterBy } from '@progress/kendo-data-query';
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { IntlProvider, load, LocalizationProvider } from "@progress/kendo-react-intl";
import likelySubtags from "cldr-core/supplemental/likelySubtags.json";
import currencyData from "cldr-core/supplemental/currencyData.json";
import weekData from "cldr-core/supplemental/weekData.json";
import numbers from "cldr-numbers-full/main/es/numbers.json";
import caGregorian from "cldr-dates-full/main/es/ca-gregorian.json";
import dateFields from "cldr-dates-full/main/es/dateFields.json";
import timeZoneNames from "cldr-dates-full/main/es/timeZoneNames.json";
import { RadioButton } from "@progress/kendo-react-inputs";
import moment from 'moment'

load(likelySubtags, currencyData, weekData, numbers, caGregorian, dateFields, timeZoneNames);

const value = new Date();
let FromDatevalue = new Date();
let ToDatevalue = new Date();
ToDatevalue.setDate(ToDatevalue.getDate()-1)
// ToDatevalue.setMonth(2);
FromDatevalue.setMonth(3)
// ToDatevalue.setDate(31);
FromDatevalue.setDate(1)
// if (value.getMonth() + 1 >= 4) {
//     let Currentyear = value.getFullYear();
//     ToDatevalue.setFullYear(Currentyear + 1)
//     FromDatevalue.setFullYear(Currentyear)
// }
// else {
//     let Currentyear = value.getFullYear();
//     ToDatevalue.setFullYear(Currentyear)
//     FromDatevalue.setFullYear(Currentyear - 1)
// }
// value.setDate(value.getDate()-1);
let Currentyear, NextYear, firstPreviousyear, secondPreviousyear, thirdPreviousyear, fourthPreviousyear, fromyear, toyear;
if (value.getMonth() + 1 >= 4) {

    Currentyear = value.getFullYear();
    fromyear = Currentyear;
    toyear = Currentyear + 1
    NextYear = "FY" + Currentyear + "-" + (Currentyear + 1);
    firstPreviousyear = "FY" + (Currentyear - 1) + "-" + (Currentyear);
    secondPreviousyear = "FY" + (Currentyear - 2) + "-" + (Currentyear - 1);
    thirdPreviousyear = "FY" + (Currentyear - 3) + "-" + (Currentyear - 2);
}
else {
    Currentyear = value.getFullYear();
    toyear = Currentyear;
    fromyear = Currentyear - 1;
    firstPreviousyear = "FY" + (Currentyear - 1) + "-" + (Currentyear);
    secondPreviousyear = "FY" + (Currentyear - 2) + "-" + (Currentyear - 1);
    thirdPreviousyear = "FY" + (Currentyear - 3) + "-" + (Currentyear - 2);
    fourthPreviousyear = "FY" + (Currentyear - 4) + "-" + (Currentyear - 3);
}
// let KAM=localStorage.getItem("KAMID")===""?"":`(${localStorage.getItem("KAMID")})`;
// let KAMHead=localStorage.getItem("KAMHeadID")===""?"":`(${localStorage.getItem("KAMHeadID")})`
// let isno=localStorage.getItem("ISNO")

class MultiSelectDropdown extends React.Component {
    locale = {
        language: "en-US",
        locale: "en"
    }
    state = {
        columns: new_column,
        columns1:  [
            { 
                field: "ID", 
                title: "SI.No.", 
                minWidnt: 135,
                filter:"text",
                show:false ,
                format:""
            },
            { 
                field: "Process", 
                title: "", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
           {   
                field: "MonthlyPlan", 
                title: "Monthly Plan", 
                minWidnt: 140,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDPlan", 
                title: "MTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDActual", 
                title: "MTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDVar", 
                title: "MTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDAchPer", 
                title: "MTD Achv %", 
                minWidnt: 137,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "QtrlyPlan", 
                title: "Qtrly Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDPlan", 
                title: "QTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDActual", 
                title: "QTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDVar", 
                title: "QTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDAchPer", 
                title: "QTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "YearlyPlan", 
                title: "Yearly Plan", 
                minWidnt:135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDPlan", 
                title: "YTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDActual", 
                title: "YTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDVar", 
                title: "YTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDAchPer", 
                title: "YTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            }
        ],
        columns2:  [
            { 
                field: "ID", 
                title: "SI.No.", 
                minWidnt: 135,
                filter:"text",
                show:false ,
                format:""
            },
            { 
                field: "Process", 
                title: "", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
           {   
                field: "MonthlyPlan", 
                title: "Monthly Plan", 
                minWidnt: 140,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDPlan", 
                title: "MTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDActual", 
                title: "MTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDVar", 
                title: "MTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDAchPer", 
                title: "MTD Achv %", 
                minWidnt: 137,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "QtrlyPlan", 
                title: "Qtrly Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDPlan", 
                title: "QTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDActual", 
                title: "QTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDVar", 
                title: "QTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDAchPer", 
                title: "QTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "YearlyPlan", 
                title: "Yearly Plan", 
                minWidnt:135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDPlan", 
                title: "YTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDActual", 
                title: "YTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDVar", 
                title: "YTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDAchPer", 
                title: "YTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            }
        ],
        columns3:  [
            { 
                field: "ID", 
                title: "SI.No.", 
                minWidnt: 135,
                filter:"text",
                show:false ,
                format:""
            },
            { 
                field: "Process", 
                title: "", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
           {   
                field: "MonthlyPlan", 
                title: "Monthly Plan", 
                minWidnt: 140,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDPlan", 
                title: "MTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDActual", 
                title: "MTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDVar", 
                title: "MTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDAchPer", 
                title: "MTD Achv %", 
                minWidnt: 137,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "QtrlyPlan", 
                title: "Qtrly Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDPlan", 
                title: "QTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDActual", 
                title: "QTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDVar", 
                title: "QTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDAchPer", 
                title: "QTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "YearlyPlan", 
                title: "Yearly Plan", 
                minWidnt:135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDPlan", 
                title: "YTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDActual", 
                title: "YTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDVar", 
                title: "YTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDAchPer", 
                title: "YTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            }
        ],
        columns4:  [
            { 
                field: "ID", 
                title: "SI.No.", 
                minWidnt: 135,
                filter:"text",
                show:false ,
                format:""
            },
            { 
                field: "Process", 
                title: "", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
           {   
                field: "MonthlyPlan", 
                title: "Monthly Plan", 
                minWidnt: 140,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDPlan", 
                title: "MTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDActual", 
                title: "MTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDVar", 
                title: "MTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDAchPer", 
                title: "MTD Achv %", 
                minWidnt: 137,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "QtrlyPlan", 
                title: "Qtrly Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDPlan", 
                title: "QTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDActual", 
                title: "QTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDVar", 
                title: "QTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDAchPer", 
                title: "QTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "YearlyPlan", 
                title: "Yearly Plan", 
                minWidnt:135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDPlan", 
                title: "YTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDActual", 
                title: "YTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDVar", 
                title: "YTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDAchPer", 
                title: "YTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            }
        ],
        columns5:  [
            { 
                field: "ID", 
                title: "SI.No.", 
                minWidnt: 135,
                filter:"text",
                show:false ,
                format:""
            },
            { 
                field: "Process", 
                title: "", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
           {   
                field: "MonthlyPlan", 
                title: "Monthly Plan", 
                minWidnt: 140,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDPlan", 
                title: "MTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDActual", 
                title: "MTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDVar", 
                title: "MTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "MTDAchPer", 
                title: "MTD Achv %", 
                minWidnt: 137,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "QtrlyPlan", 
                title: "Qtrly Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDPlan", 
                title: "QTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDActual", 
                title: "QTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDVar", 
                title: "QTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "QTDAchPer", 
                title: "QTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            {   
                field: "YearlyPlan", 
                title: "Yearly Plan", 
                minWidnt:135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDPlan", 
                title: "YTD Plan", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDActual", 
                title: "YTD Actual", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDVar", 
                title: "YTD Variant", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            },
            { 
                field: "YTDAchPer", 
                title: "YTD Achv %", 
                minWidnt: 135,
                filter:"text",
                show:true ,
                format:""
            }
        ],
        CurrencyType: ['INR', 'USD'],

        CurrencyTypeFilterData: ['INR', 'USD'],

        path: 'http://inet:81/OIVADashBoard/OIVADashboardOverall',
        input: {
            "FromDate": `${fromyear}/04/01 00:00:00`, //'2021/04/01 00:00:00'
            // "ToDate": value.toISOString().split('T')[0], //'2022/03/31 00:00:00'
            "ToDate": `${ToDatevalue.toISOString().split('T')[0]} 00:00:00`,
            "GroupID": "4",
            "DivisionId": "",
            "KAMHeadID": this.props.Kamhead === "" ? this.props.Kamhead : `(${this.props.Kamhead})`,
            "DUHeadID": this.props.Kam === "" ? this.props.Kam : `(${this.props.Kam})`,
            "CountryID": "",
            "CustomerID": "",
            "ReportType": this.props.IsKAM === true || this.props.IsKAMHead === true ? "By Function" : "By KAM",
            "RadioValue":"Target"
        },
        callGrid: true,
        callAgain: false,
        name: 'Division',
        SelectType:["Budget","Target"],
        date: value.toISOString().split('T')[0],
        value: [],
        selectedValue: "Target",
        Division: [],
        KAMHead: [],
        KAMID: "",
        KAMHeadID: "",
        DUHead: [],
        Country: [],
        Customer: [],
        ReportType: [],
        fromYear: "",
        toYear: "",
        GroupID: [],
        KAMDescriptions: "",
        KAMHeadDescriptions: "",
        callchart: false,
        DisableKAMHead: false,
        DisableKAM: false,
        DisableExchangeRate: false,
        DisableCurrency: false,
        chartData: [],
        // chartData1: [],
        // chartData2: [],
        // chartData3: [],
        // chartData4: [],
        // chartData5:[],
        Griddata: [],
        isComing: false,
        isDrill: false,
        isFromGo: false,
        isDrillchart: false,
        Drillchartdata: [],
        gridsearchValue: "",
        isFromTemp: false,
        DUDefault: [],
        DUHeadDefault: [],
        KAMHeadDefault: [],
        CustomerDefault: [],
        CountryDefault: [],
        value: [],
        aggregates: [
            { field: 'MTDActual', aggregate: 'sum' },
            { field: 'QTDActual', aggregate: 'sum' },
            { field: 'YTDActual', aggregate: 'sum' },
            { field: 'MTDActual', aggregate: 'average' },
            { field: 'QTDActual', aggregate: 'average' },
            { field: 'YTDActual', aggregate: 'average' },
        ]
    }
    componentWillMount = () => {
        debugger
        let inputval = this.props.isTemplateLoad === true ? JSON.parse(this.props.LoadTemplate.templatejson) : ""
        let input = this.props.isTemplateLoad === true ? inputval.input : {
            "FromDate": `${fromyear}/04/01 00:00:00`, //'2021/04/01 00:00:00'
            // "ToDate": value.toISOString().split('T')[0], //'2022/03/31 00:00:00'
            "ToDate": `${toyear}/03/31 00:00:00`,
            "GroupID": "4",
            "DivisionId": "",
            "KAMHeadID": this.props.Kamhead === "" ? this.props.Kamhead : `(${this.props.Kamhead})`,
            "DUHeadID": this.props.Kam === "" ? this.props.Kam : `(${this.props.Kam})`,
            "CountryID": "",
            "CustomerID": "",
            "ReportType": this.props.IsKAM === true || this.props.IsKAMHead === true ? "By Function" : "By KAM",
            "RadioValue":"Target"
        }
        this.setState({ input: input })
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "45px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    componentDidMount() {
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
        debugger
        if (this.props.isTemplateLoad) {
            let temp = JSON.parse(this.props.LoadTemplate.templatejson)

            GridService.getGridData(
                {
                    "MasterType": 'Division',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'Division'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ DUDefault: temp.DUDescription })
                this.setState({ Division: multiSelectData })
                this.setState({ DivisionFilterData: data })


                this.setState({ DUselected: this.state.DUDefault.length })


            }).catch(err => {
                console.log("error", err)
            });
            GridService.getGridData(

                {
                    "MasterType": 'KAMHead',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'KAMHead'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ KAMHeadDefault: temp.KAMHeadDescription })
                this.setState({ KAMHead: multiSelectData });
                this.setState({ KAMHeadFilterData: data })



                this.setState({ KAMHeadselected: this.state.KAMHeadDefault.length })



            }).catch(err => {
                console.log("error", err)
            });


            GridService.getGridData(
                {
                    "MasterType": 'DUHead',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'DUHead'
            ).then(response => {
                debugger
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []


                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ DUHeadDefault: temp.DUHeadDescription })
                this.setState({ DUHead: multiSelectData })

                this.setState({ DUHeadselected: this.state.DUHeadDefault.length })
                this.setState({ DUHeadFilterData: data })

            }).catch(err => {
                console.log("error", err)
            });


            GridService.getGridData(
                {
                    "MasterType": 'Country',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'Country'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ CountryDefault: temp.CountryDescription })
                this.setState({ Country: multiSelectData })

                this.setState({ Countryselected: this.state.CountryDefault.length })
                this.setState({ CountryFilterData: data })
            }).catch(err => {
                console.log("error", err)
            });


            GridService.getGridData(
                {
                    "MasterType": 'Customer',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'Customer'
            ).then(response => {
                // console.log("Customer",response)
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ CustomerDefault: temp.CustomerDescription })
                this.setState({ Customer: multiSelectData })

                this.setState({ Customerselected: this.state.CustomerDefault.length })
                this.setState({ CustomerFilterData: data })
            }).catch(err => {
                console.log("error", err)
            });

            GridService.getGridData(
                {
                    "MasterType": 'ExchangeRate',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'GroupID'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ GroupID: multiSelectData });
                this.setState({ GroupIDFilterData: data })
            }).catch(err => {
                console.log("error", err)
            });

            GridService.getGridData(
                {
                    "MasterType": 'ReportType',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'ReportType'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ value: temp.ReportTypeDescription })
                this.setState({ ReportType: multiSelectData })
                this.setState({ selected: this.state.value.length })
                this.setState({ ReportFilterData: multiSelectData })

            }).catch(err => {
                console.log("error", err)
            });


        }

        else {
            this.setState({ todatecheckyear: toyear, fromdatecheckyear: fromyear, todatecheckdate: 31, todatecheckmonth: 3, fromdatecheckdate: 1, fromdatecheckmonth: 4 })

            if (this.props.IsKAM === true) {
                this.setState({ DisableKAM: true })
                this.setState({ KAMDescriptions: this.props.Name })
                this.setState({ DisableExchangeRate: true })
            }
            else if (this.props.IsKAMHead === true) {
                this.setState({ DisableKAMHead: true })
                this.setState({ KAMHeadDescriptions: this.props.Name })
                this.setState({ DisableExchangeRate: true })
            }



            GridService.getGridData(
                {
                    "MasterType": 'Division',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'Division'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ DUDefault: [] })
                this.setState({ DUselected: this.state.DUDefault.length })
                this.setState({ Division: multiSelectData })
                this.setState({ DivisionFilterData: data })
            }).catch(err => {
                console.log("error", err)
            });

            GridService.getGridData(

                {
                    "MasterType": 'KAMHead',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'KAMHead'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ KAMHead: multiSelectData });
                this.setState({ KAMHeadDefault: [] });
                this.setState({ KAMHeadselected: this.state.KAMHeadDefault.length })
                this.setState({ KAMHeadFilterData: data })

            }).catch(err => {
                console.log("error", err)
            });


            GridService.getGridData(
                {
                    "MasterType": 'DUHead',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'DUHead'
            ).then(response => {
                debugger
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []


                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)

                this.setState({ DUHead: multiSelectData })
                this.setState({ DUHeadDefault: [] })
                this.setState({ DUHeadselected: this.state.DUHeadDefault.length })
                this.setState({ DUHeadFilterData: data })

            }).catch(err => {
                console.log("error", err)
            });


            GridService.getGridData(
                {
                    "MasterType": 'Country',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'Country'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ Country: multiSelectData })
                this.setState({ CountryDefault: [] });
                this.setState({ Countryselected: this.state.CountryDefault.length })
                this.setState({ CountryFilterData: data })
            }).catch(err => {
                console.log("error", err)
            });


            GridService.getGridData(
                {
                    "MasterType": 'Customer',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'Customer'
            ).then(response => {
                // console.log("Customer",response)
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ Customer: multiSelectData })
                this.setState({ CustomerDefault: [] })
                this.setState({ Customerselected: this.state.CustomerDefault.length })
                this.setState({ CustomerFilterData: data })
            }).catch(err => {
                console.log("error", err)
            });

            GridService.getGridData(
                {
                    "MasterType": 'ExchangeRate',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'GroupID'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['ID'] = data.map(d => d.ID)
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ GroupID: multiSelectData });
                this.setState({ GroupIDFilterData: data })
            }).catch(err => {
                console.log("error", err)
            });

            GridService.getGridData(
                {
                    "MasterType": 'ReportType',
                    "ToDate": `${toyear}/03/31 00:00:00`,
                    "FromDate": `${fromyear}/04/01 00:00:00`,
                    "EmpCode": this.props.EmpCode
                },
                'ReportType'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response), multiSelectData = []
                multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
                this.setState({ ReportType: multiSelectData })
                if (this.props.IsKAMHead === true || this.props.IsKAM === true) {
                    this.setState({
                        value: ['By Function'],
                    })
                }
                else {
                    this.setState({
                        value: ['By KAM'],
                    })
                }

                this.setState({ selected: this.state.value.length })
                this.setState({ ReportFilterData: multiSelectData })

            }).catch(err => {
                console.log("error", err)
            });

        }



    }
    handleChange = (e) => {
        let input=this.state.input;
        input["RadioValue"]=e.value
        this.setState({ selectedValue: e.value,input: input });
      };

    changeToStuff(date) {
        debugger
        let input = this.state.input
        input["ToDate"] = moment(date).format('YYYY-MM-DD')
        this.setState({
            input: input,
            todatecheckyear: date.getFullYear(),
            todatecheckmonth: date.getMonth(),
            todatecheckdate: date.getDate()

        })
        // setTimeout(() => {
        //     console.log(this.state.fromdatecheckyear, this.state.fromdatecheckmonth, this.state.fromdatecheckdate)
        // }, 200);
    }
    changeFromStuff(date) {
        debugger
        let input = this.state.input
        input["FromDate"] = moment(date).format('YYYY-MM-DD')
        this.setState({
            input: input,
            fromdatecheckyear: date.getFullYear(),
            fromdatecheckmonth: date.getMonth(),
            fromdatecheckdate: date.getDate(),

        })
        // setTimeout(() => {
        //     console.log(this.state.fromdatecheckyear, this.state.fromdatecheckmonth, this.state.fromdatecheckdate)
        // }, 200);
    }
    chartData = (navopen, data, Griddata, search) => {
        debugger
        this.setState({ Griddata: Griddata })
        this.setState({ chartData: data })
        // this.setState({ chartData1: data1 })
        // this.setState({ chartData2: data2 })
        // this.setState({ chartData3: data3 })
        // this.setState({ chartData4: data4 })
        // this.setState({ chartData5: data5 })
        this.setState({ navopen: navopen })
        this.setState({ callchart: !this.state.callchart })
        this.setState({ gridsearchValue: search })
        // this.setState({isDrillchart:isDrill})
    }
    ToGridData = (navopen) => {
        // this.setState({value:['Division']})
        this.setState({ isComing: true })

        this.setState({ navopen: navopen })
        this.setState({ callchart: !this.state.callchart })
    }
    //     toGridfromdrillchart=(navopen,isDrillchart,Drillchartdata)=>{
    // this.setState({navopen:navopen})
    // this.setState({isDrillchart:isDrillchart})
    // this.setState({Drillchartdata:Drillchartdata})
    // this.setState({ callchart: !this.state.callchart })
    //     }
    FalseIsComing = () => {
        this.setState({ isComing: false })
    }
    filterChange = (event) => {
        if (event.target.props.placeholder === "Select CurrencyType") {
            this.setState({
                CurrencyType: this.filterData(event.filter, event.target.props.placeholder)
            });
        }
        if (event.target.props.placeholder === "Select ReportType") {
            let data = []
            data['Descriptions'] = this.filterData(event.filter, event.target.props.placeholder)
            // console.log(data)	
            this.setState({
                ReportType: data
            });
        }

        else {
            debugger
            let multiSelectData = []
            let data = this.filterData(event.filter, event.target.props.placeholder)
            multiSelectData['ID'] = data.map(d => d.ID)
            multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
            if (event.target.props.placeholder === "Select ExchangeRate") {

                this.setState({
                    GroupID: multiSelectData
                });
            }

            if (event.target.props.placeholder === "Select Customer") {
                this.setState({
                    Customer: multiSelectData
                });
            }
            if (event.target.props.placeholder === "Select Country") {
                this.setState({
                    Country: multiSelectData
                });
            }
            if (event.target.props.placeholder === "Select KAM") {
                this.setState({
                    DUHead: multiSelectData
                });
            }
            if (event.target.props.placeholder === "Select KAMHead") {
                this.setState({
                    KAMHead: multiSelectData
                });
            }
            if (event.target.props.placeholder === "Select DU") {

                this.setState({
                    Division: multiSelectData
                });
            }
        }

    }
    filterData(filter, name) {
        if (name === "Select KAM") {
            let data = this.state.DUHeadFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);

        }
        if (name === "Select ReportType") {
            debugger
            const data = this.state.ReportFilterData['Descriptions'].slice();
            return filterBy(data, filter);
        }
        if (name === "Select ExchangeRate") {
            let data = this.state.GroupIDFilterData.filter(x => x.Descriptions.toString().includes(filter.value.toString()));
            return (data);

        }
        if (name === "Select Customer") {
            let data = this.state.CustomerFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);

        }
        if (name === "Select Country") {
            let data = this.state.CountryFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);

        }
        if (name === "Select KAMHead") {
            // let filter=filter.value.toLowerCase	
            let data = this.state.KAMHeadFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);

        }
        if (name === "Select DU") {

            let data = this.state.DivisionFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);


        }
        if (name === "Select CurrencyType") {
            const data = this.state.CurrencyTypeFilterData.slice();
            return filterBy(data, filter);

        }


    }
    itemRender = (li, itemProps) => {
        const itemChildren = (
            <span>
                <input type="checkbox" name={itemProps.dataItem} checked={itemProps.selected} onChange={(e) => itemProps.onClick(itemProps.index, e)} />
            &nbsp;{li.props.children}
            </span>
        );
        return React.cloneElement(li, li.props, itemChildren);
    }
    
  
    isDrill = (state) => {
        this.setState({ isDrill: state })
    }

    isDrillChartfunction = (state) => {
        this.setState({ isDrillChartfunction: state })
    }
    render() {

        // let grid = (<div></div>)
        let grid = (<GridComponent KAMHeadDescription={this.state.KAMHeadDescription}
            DUHeadDescription={this.state.DUHeadDescription}
            CustomerDescription={this.state.CustomerDescription}
            CountryDescription={this.state.CountryDescription}
            DUDescription={this.state.DUDescription}
            ReportTypeDescription={this.state.ReportTypeDescription}
            isDrill={this.isDrill}
            isTemplateLoad={this.props.isTemplateLoad}
            LoadTemplate={this.props.LoadTemplate}
            Drillchartdata={this.state.Drillchartdata}
            isDrillchart={this.state.isDrillchart}
            isDrillChartfunction={this.isDrillChartfunction}
            navopen={this.state.navopen}
            LoadDefaultTemplate={this.props.LoadDefaultTemplate}
            IsKAM={this.props.IsKAM}
            IsKAMHead={this.props.IsKAMHead}
            EmpCode={this.props.ISNo}
            gridsearchValue={this.state.gridsearchValue}
            sidemenuname={this.props.sidemenuname}
            isTemplate={this.props.isTemplate}
            FalseIsComing={this.FalseIsComing}
            Griddata={this.state.Griddata}
            isComing={this.state.isComing}
            CustomerFilterData={this.state.CustomerFilterData}
            Customer={this.state.Customer}
            name={this.state.name}
            input={this.state.input}
            columns={this.state.columns}
            columns1={this.state.columns1}
            columns2={this.state.columns2}
            columns3={this.state.columns3}
            columns4={this.state.columns4}
            columns5={this.state.columns5}
            aggregates={this.state.aggregates}
            chartData={this.chartData}
            moveGrid={this.props.moveGrid}
            isFromGo={this.state.isFromGo} />)


        return (

            this.state.callchart === false ?


                <div className='move-grid-container' id='grid-container'>

                    <div className={this.state.isDrill === true || this.state.isDrillchart === true ? "noMultiselect" : "Multiselect"}>
                        <b style={{ fontWeight: "unset" }} title="Select ReportType"><ComboBox
                            style={{ width: "251px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.ReportType['Descriptions']}
                            defaultValue={this.state.value}
                            autoClose={false}
                            filterable={true}
                            onFilterChange={this.filterChange}
                            onChange={(event) => {
                               
                                let name = event.target.value, input = this.state.input;
                                name!== null ? input["ReportType"] = `${name}` : input["ReportType"] = "Division"

                                this.setState({
                                    value: value,
                                    selected: value.length,
                                    input: input,
                                    name: name,
                                    ReportTypeDescription: name!== null ? event.target.value:"Division"
                                })
                            }
                            }
                            placeholder="Select ReportType"
                         
                        /></b>

                        <b style={{ fontWeight: "unset" }} title="Select DU"><MultiSelect

                            style={{ width: "220px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.Division['Descriptions']}
                            itemRender={this.itemRender}
                            autoClose={false}
                            filterable={true}
                            defaultValue={this.state.DUDefault}
                            onFilterChange={this.filterChange}


                            onChange={(e) => {
                                debugger
                                let value = e.target.value.filter(item => {
                                    return item
                                });
                                let name = e.target.value, input = this.state.input, DUDescription = [], index, DivisionId = [], Id;
                                e.target.value.map((i, item) => {
                                    // console.log("du", item, e.target.value)
                                    index = this.state.Division['Descriptions'].indexOf(i)
                                    Id = this.state.Division['ID'][index]
                                    DivisionId.push(Id)
                                    DUDescription = e.target.value
                                    return null
                                }
                                )
                                name.length !== 0 ? input["DivisionId"] = `(${DivisionId})` : input["DivisionId"] = ""
                                this.setState({
                                    input: input,
                                    DUDefault: value,
                                    DUselected: value.length,
                                    name: name,
                                    DUDescription: DUDescription                                // callAgain: !this.state.callAgain
                                })
                            }
                            }
                            placeholder="Select DU"
                            tags={
                                this.state.DUselected > 0
                                    ? [{ text: `${this.state.DUselected} DU selected`, data: [...this.state.DUDefault] }]
                                    : []
                            }
                        /></b>
                        <b style={{ fontWeight: "unset" }} title="Select Customer"><MultiSelect
                            style={{ width: "241px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.Customer['Descriptions']}
                            itemRender={this.itemRender}
                            defaultValue={this.state.CustomerDefault}
                            autoClose={false}
                            filterable={true}
                            onFilterChange={this.filterChange}
                            onChange={(e) => {
                                let value = e.target.value.filter(item => {
                                    return item
                                });
                                let name = e.target.value, input = this.state.input, index, CustomerDescription, CustomerID = [], Id;
                                e.target.value.map((i, item) => {
                                    index = this.state.Customer['Descriptions'].indexOf(i)
                                    Id = this.state.Customer['ID'][index]
                                    CustomerID.push(Id)
                                    CustomerDescription = e.target.value
                                })

                                name.length !== 0 ? input["CustomerID"] = `(${CustomerID})` : input["CustomerID"] = ""
                                this.setState({
                                    input: input,
                                    name: name,
                                    CustomerDefault: value,
                                    Customerselected: value.length,
                                    CustomerDescription: CustomerDescription
                                })
                            }
                            }
                            placeholder="Select Customer"
                            tags={
                                this.state.Customerselected > 0
                                    ? [{ text: `${this.state.Customerselected} Customer selected`, data: [...this.state.CustomerDefault] }]
                                    : []
                            }
                        /></b>
                        <b style={{ fontWeight: "unset" }} title="Select Country"><MultiSelect
                            style={{ width: "240px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.Country['Descriptions']}
                            itemRender={this.itemRender}
                            autoClose={false}
                            defaultValue={this.state.CountryDefault}
                            filterable={true}
                            onFilterChange={this.filterChange}
                            onChange={(e) => {

                                let value = e.target.value.filter(item => {
                                    return item
                                });
                                let name = e.target.value, input = this.state.input, index, CountryID = [], Id;
                                // console.log(name)
                                e.target.value.map((i, item) => {
                                    index = this.state.Country['Descriptions'].indexOf(i)
                                    Id = this.state.Country['ID'][index]
                                    CountryID.push(Id)
                                    return null
                                })
                                name.length !== 0 ? input["CountryID"] = `(${CountryID})` : input["CountryID"] = ""
                                this.setState({
                                    input: input,
                                    name: name,
                                    CountryDefault: value,
                                    Countryselected: value.length,
                                    CountryDescription: e.target.value
                                })
                            }
                            }
                            placeholder="Select Country"
                            tags={
                                this.state.Countryselected > 0
                                    ? [{ text: `${this.state.Countryselected} Country selected`, data: [...this.state.CountryDefault] }]
                                    : []
                            }
                        /></b>

                        <b style={{ fontWeight: "unset" }} title="Select KAMHead"> <MultiSelect
                            style={{ width: "250px", marginLeft: '4px', marginTop: '3px' }}
                            itemRender={this.itemRender}
                            defaultValue={this.state.KAMHeadDefault}
                            autoClose={false}
                            filterable={true}
                            disabled={this.state.DisableKAMHead}
                            onFilterChange={this.filterChange}
                            data={this.state.KAMHead['Descriptions']}
                            onChange={(e) => {
                                let value = e.target.value.filter(item => {
                                    return item
                                });
                                let name = e.target.value, input = this.state.input, index, KAMHeadID = [], Id;
                                e.target.value.map((i, item) => {
                                    index = this.state.KAMHead['Descriptions'].indexOf(i)
                                    Id = this.state.KAMHead['ID'][index]
                                    KAMHeadID.push(Id)
                                    return null
                                })

                                name.length !== 0 ? input["KAMHeadID"] = `(${KAMHeadID})` : input["KAMHeadID"] = ""
                                this.setState({
                                    input: input,
                                    name: name,
                                    KAMHeadDefault: value,
                                    KAMHeadselected: value.length,
                                    KAMHeadDescription: e.target.value
                                })
                            }
                            }
                            placeholder={this.state.KAMHeadDescriptions !== "" ? "" : "Select KAMHead"}
                            tags={
                                this.state.KAMHeadDescriptions !== "" ? [{ text: this.state.KAMHeadDescriptions }] : this.state.KAMHeadselected > 0
                                    ? [{ text: `${this.state.KAMHeadselected} KAMHead selected`, data: [...this.state.KAMHeadDefault] }]
                                    : []
                            }
                        /></b>

                        <b style={{ fontWeight: "unset" }} title="Select KAM"><MultiSelect
                            style={{ width: "220px", marginLeft: '4px', marginTop: '3px' }}
                            itemRender={this.itemRender}
                            autoClose={false}
                            defaultValue={this.state.DUHeadDefault}
                            data={this.state.DUHead['Descriptions']}
                            filterable={true}
                            disabled={this.state.DisableKAM}
                            onFilterChange={this.filterChange}
                            onChange={(e) => {
                                let value = e.target.value.filter(item => {
                                    return item
                                });
                                let name = e.target.value, input = this.state.input, index, DUHeadID = [], Id;
                                e.target.value.map((i, item) => {
                                    index = this.state.DUHead['Descriptions'].indexOf(i)
                                    Id = this.state.DUHead['ID'][index]
                                    DUHeadID.push(Id)
                                    return null
                                })

                                name.length !== 0 ? input["DUHeadID"] = `(${DUHeadID})` : input["DUHeadID"] = ""
                                this.setState({
                                    input: input,
                                    name: name,
                                    DUHeadDefault: value,
                                    DUHeadselected: value.length,
                                    DUHeadDescription: e.target.value

                                })
                            }
                            }
                            placeholder={this.state.KAMDescriptions !== "" ? "" : "Select KAM"}
                            tags={
                                this.state.KAMDescriptions !== "" ? [{ text: this.state.KAMDescriptions }] : this.state.DUHeadselected > 0
                                    ? [{ text: `${this.state.DUHeadselected} KAM selected`, data: [...this.state.DUHeadDefault] }]
                                    : []
                            }
                        /></b>
                        <b style={{ fontWeight: "unset" }} title="Select ExchangeRate"><ComboBox
                            style={{ width: "120px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.GroupID['Descriptions']}
                            defaultValue='72'
                            filterable={true}
                            disabled={this.state.DisableExchangeRate}
                            onFilterChange={this.filterChange}
                            onChange={(e) => {
                                let name = e.target.value, input = this.state.input, index, GroupID;
                                index = this.state.GroupID['Descriptions'].indexOf(name)
                                GroupID = this.state.GroupID['ID'][index]
                                name !== null ? input["GroupID"] = `${GroupID}` : input["GroupID"] = ""
                                this.setState({
                                    input: input,
                                    name: name,
                                })
                            }
                            }
                            placeholder="Select ExchangeRate"
                        /></b>
                        <b style={{ fontWeight: "unset" }} title="Select CurrencyType"><ComboBox
                            style={{ width: "120px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.CurrencyType}
                            filterable={true}
                            onFilterChange={this.filterChange}
                            disabled={this.state.DisableCurrency}
                            defaultValue='INR'
                            onChange={(e) => {
                                let name = e.target.value, input = this.state.input, USDGroupID, INRGroupID;

                                USDGroupID = 0;
                                INRGroupID = 4
                                name === "USD" ? input["GroupID"] = `${USDGroupID}` : input["GroupID"] = `${INRGroupID}`
                                this.setState({
                                    input: input,
                                    name: name,
                                })
                            }
                            }
                            placeholder="Select CurrencyType"
                        /></b>
                        {/* <b style={{ fontWeight: "unset" }} title="Select Financial year"><ComboBox
                            style={{ width: "220px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.Finacialyearlist}
                            defaultValue={this.state.defaultfinacialyear}
                            // filterable={true}
                            // onFilterChange={this.filterChange}
                            onChange={(e) => {
                                debugger
                                let name = e.target.value, input = this.state.input;
                                let splitFY = name.split("FY");
                                let year = splitFY[1].split("-")
                                this.setState({
                                    fromYear: parseInt(year[0]),
                                    toYear: year[1]
                                })

                                setTimeout(() => {
                                    name !== null ? input["FromDate"] = `${this.state.fromYear}/04/01 00:00:00` : input["FromDate"] = ""
                                    name !== null ? input["ToDate"] = `${this.state.toYear}/03/31 00:00:00` : input["ToDate"] = ""
                                    this.setState({
                                        input: input,
                                        //         name: name,
                                    })
                                }, 100);

                            }
                            }
                            placeholder="Select Financial year"
                        /></b> */}
                        <b title="From Date" style={{ fontWeight: "unset", marginLeft: '4px', marginTop: '3px' }}>
                            <LocalizationProvider language={this.locale.language}>
                                <IntlProvider locale={this.locale.locale}>


                                    <DatePicker
                                        title="From Date"
                                        defaultValue={FromDatevalue}
                                        onChange={
                                            (e) => {
                                                let value = e.target.value
                                                this.changeFromStuff(value)
                                            }
                                        }
                                        format="dd/MM/yyyy"

                                    />



                                </IntlProvider>
                            </LocalizationProvider>

                        </b>
                        <b style={{ fontWeight: "unset", marginLeft: '4px', marginTop: '3px' }} title="To Date">
                            <LocalizationProvider language={this.locale.language}>
                                <IntlProvider locale={this.locale.locale}>

                                    <DatePicker
                                        title="To Date"
                                        defaultValue={ToDatevalue}
                                        onChange={
                                            (e) => {
                                                let value = e.target.value
                                                this.changeToStuff(value)
                                            }
                                        }
                                        format="dd/MM/yyyy"

                                    />



                                </IntlProvider>
                            </LocalizationProvider>

                        </b>
                        
                        <span className="RadioSelect">
        <RadioButton
          name="group1"
          value="Target"
          checked={this.state.selectedValue === "Target"}
          label="Target"
          onChange={this.handleChange}
        />
        <RadioButton
          name="group1"
          value="Budget"
          checked={this.state.selectedValue === "Budget"}
          label="Budget"
          onChange={this.handleChange}
        />
     
            </span>
                        <button className="Go_button" title="Go" onClick={() => {

                            setTimeout(() => {
                               
                                if (this.state.todatecheckyear < this.state.fromdatecheckyear) {
                                    alert("To Date should greater than From Date")
                                }
                                else if (this.state.todatecheckyear === this.state.fromdatecheckyear) {
                                    if (this.state.fromdatecheckmonth > this.state.todatecheckmonth) {
                                        alert("To Date should greater than From Date")
                                    }
                                    else if (this.state.fromdatecheckmonth === this.state.todatecheckmonth) {
                                        if (this.state.fromdatecheckdate > this.state.todatecheckdate) {
                                            alert("To Date should greater than From Date")
                                        }
                                        else {
                                            this.setState({ columns: new_column, callGrid: !this.state.callGrid, callAgain: !this.state.callAgain, isFromGo: true })
                                        }
                                    }
                                    else {
                                        this.setState({ columns: new_column, callGrid: !this.state.callGrid, callAgain: !this.state.callAgain, isFromGo: true })
                                    }
                                }
                                else {
                                    this.setState({ columns: new_column, callGrid: !this.state.callGrid, callAgain: !this.state.callAgain, isFromGo: true })
                                }
                            }, 200);


                        }}>GO</button>
                    </div>
                    {this.state.callGrid && (grid)}
                    {this.state.callAgain && (grid)}
                </div>
                :
                <div className='move-chart-container' id='chart-container'>
                <ChartContainer chartData={this.state.chartData} columns1={this.state.columns1}
                columns2={this.state.columns2}
                columns3={this.state.columns3}
                columns4={this.state.columns4}
                columns5={this.state.columns5} Customer={this.state.Customer} CustomerFilterData={this.state.CustomerFilterData} input={this.state.input} chartDatafunc={this.ToGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>
        );


    }
}

export default MultiSelectDropdown;