import * as React from "react";
import { Dialog } from "@progress/kendo-react-dialogs";
import { Form, Field, FormElement } from "@progress/kendo-react-form";
import { Input, NumericTextBox } from "@progress/kendo-react-inputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";


const EditForm = props => {
  // console.log(props.item)
  return <Dialog title='Edit' onClose={props.cancelEdit}>
        <Form onSubmit={props.onSubmit} initialValues={props.item} render={formRenderProps => <FormElement >
              <fieldset className={"k-form-fieldset"}>
              
                <div className="mb-3">
                  <Field name={"usercode"} component={Input} label={"Employee Code"} disabled={true} />
                </div>
                <div className="mb-3">
                  <Field name={"username"} component={Input} label={"Employee Name"} disabled={true}   />
                </div>
             <div className="mb-2">
                  <Field name={"rol"} component={DropDownList} data={props.role} label={"Role"}  textField={"rolename"}   />
                </div>
                
              </fieldset>
              <div className="k-form-buttons">
                <button type={"submit"} className="k-button k-primary" disabled={!formRenderProps.allowSubmit}>
                  Update
                </button>
                <button type={"submit"} className="k-button" onClick={props.cancelEdit}>
                  Cancel
                </button>
              </div>
            </FormElement>} />
      </Dialog>;
};

export default EditForm;