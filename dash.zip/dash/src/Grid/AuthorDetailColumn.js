
export const AuthorDetail_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "Ageing",
        title: "Ageing",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "BeforeDue",
        title: "Before Due",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "AfterDue",
        title: "After Due",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "Total",
        title: "Total",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
]