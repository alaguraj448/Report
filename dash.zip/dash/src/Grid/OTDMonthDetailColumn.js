export const OTDmonthDetail_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    {
        field: "StageGroup",
        title: "Stage Group",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
    
    
   
]