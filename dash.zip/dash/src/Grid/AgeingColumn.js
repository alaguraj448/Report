export const Ageing_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "Ageing",
        title: "Ageing",
        minWidnt: 260,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    
    {
        field: "hold",
        title: "No. of Article on Hold",
        minWidnt: 260,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "unhold",
        title: "No. of Article on Unhold",
        minWidnt: 260,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "Nos",
        title: "Total",
        minWidnt: 260,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
]