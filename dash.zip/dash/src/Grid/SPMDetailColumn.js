export const Detail_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "SPM",
        title: "SPM Name",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
    ,
    
    {
        field: "Tier",
        title: "Tier",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
    ,
    
    {
        field:  "Norms",
        title: "Norms",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
]