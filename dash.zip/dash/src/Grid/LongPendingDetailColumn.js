export const DetailJournal_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "PM",
        title: "PM",
        minWidnt: 250,
        filter: "text",
        show: true,
        format: "",
        Type:""
    },
    {
        field: "0-5",
        title: "0-5",
        minWidnt: 150,
        filter: "text",
        show: true,
        format: "",
        Type:""
    },
    {
        field: "6-10",
        title: "6-10",
        minWidnt: 150,
        filter: "text",
        show: true,
        format: "",   
        Type:""
    },
  
    {
        field: ">10",
        title: ">10",
        minWidnt: 150,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }
  ,
  
    
 
    
   {
        field: "Total",
        title: "Total",
        minWidnt: 150,
        filter: "text",
        show: true,
        format: "",
        Type:""
    },
]