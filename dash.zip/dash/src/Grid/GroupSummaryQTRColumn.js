export const GroupSummaryQTR_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "QTR",
        title: "QTR",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Budget",
        title: "",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Actuals",
        title: "Actuals",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Variance",
        title: "Variance",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Variance_per",
        title: "Variance Percentage",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
]