import React from "react";
import ChartContainer from '../Chart/LongPendingChart';
import Grid from './LongPendingGrid';
import { longPending_column } from './LongpendingColumn';
import { DetailJournal_columns } from './LongPendingDetailColumn';
import { DetailJournal_columns2 } from './SocietyJournaldetailColumn2';

import { longPendingfull_column } from './LongPendingFullColumn'
import { longPendingfull_column2 } from './LongPendingFullColumn'
import { longPendingfull_column3 } from './LongPendingFullColumn'

import moment from 'moment';
import DrillDown from './LongPendingDetailGrid'
import DrillDown2 from './SocietyJournalDetail2'

import { Button } from '@progress/kendo-react-buttons';
import Chart from '../Chart/AuthorDetailChart'
import Drill from './LongPendingFullDetail'
import { ComboBox } from '@progress/kendo-react-dropdowns';
import { GridService } from '../services/grid.services';
import { filterBy } from '@progress/kendo-data-query';





let fromdate = new Date();
let todate = new Date();
let toDateCol = new Date();
//todate.setDate(todate.getDate() - 1)
if (fromdate.getDate() === 1) {
    fromdate.setDate(2);
    fromdate.setMonth(fromdate.getMonth() - 1)
    //todate=fromdate
}
else {

    fromdate.setDate(1);
    // todate=fromdate

}

class LongPending extends React.Component {


    state = {
        GridColumns: longPending_column,
        Datecolumns: [],
        DetailedColumn: DetailJournal_columns,
        DetailedColumn2: DetailJournal_columns2,
        FullDetailedColumn: longPendingfull_column,
        FullDetailedColumn2: longPendingfull_column2,
        FullDetailedColumn3: longPendingfull_column3,

        Detailedaggregates: [],
        Reportaggregates: [],
        FullDetail: false,
        SelectionData: ["Workflow wise", "Country Wise", 'Stage Wise'],
        SelectionFilterData: ["Workflow wise", "Country Wise", "Stage Wise"],
        Query: [],
        QueryFilterData: [],
        PM: [],
        PMFilterData: [],
        Stages: [],
        StagesFilterData: [],
        Workflow: [],
        WorkflowFilterData: [],
        Journal: [],
        JournalFilterData: [],
        fullFilter: "FullDetail",

        chartInput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '6',
            "Workflow": "",
            "Stage": "",
            "PM": "",
            "Journal": ""
        },
        FullDetailInput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '2',
            "Workflow": "",
            "Stage": "",
            "PM": "",
            "Journal": ""

        },

        Gridinput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '6',
            "Workflow": "",
            "Stage": "",
            "PM": "",
            "Journal": ""
        },
        Detailinput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '1',
            "Workflow": "",
            "Stage": "",
            "PM": "",
            "Journal": ""
        },

        callGrid: true,
        callAgain: false,
        callchart: true,
        calldrillGrid: true,
        calldrillAgain: false,
        call: true,
        callchartAgain: false,
        callfulldrillGrid: true,
        callfulldrillAgain: false,
        fromdate: fromdate,
        todate: todate,
        Griddata: [],
        chartData: [],
        isDrill: false,
        gridsearchValue: "",
        name: "Workflow wise",
        PMname: "",
        Stagesname: "",
        journalname: "",
        workflowname: "",
        Queryname: ""

    }

    componentWillMount = () => {


        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    componentDidMount() {
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }

        GridService.getGridData(

            {
                "MasterType": 'PM',
                // "Token":this.props.Token,
                "ToDate": this.state.todate,
                "FromDate": this.state.fromdate,
                "EmpCode": this.props.EmpCode
            },
            'PM'
        ).then(response => {
            let d = response
            let data = JSON.parse(d.response), multiSelectData = []
            multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
            this.setState({ PM: multiSelectData })
            this.setState({ PMFilterData: data })
        }).catch(err => {
            console.log("error", err)
        });
        GridService.getGridData(

            {
                "MasterType": 'Workflow',
                // "Token":this.props.Token,
                "ToDate": this.state.todate,
                "FromDate": this.state.fromdate,
                "EmpCode": this.props.EmpCode
            },
            'Workflow'
        ).then(response => {
            let d = response
            let data = JSON.parse(d.response), multiSelectData = []
            multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
            this.setState({ Workflow: multiSelectData })
            this.setState({ WorkflowFilterData: data })
        }).catch(err => {
            console.log("error", err)
        });
        GridService.getGridData(

            {
                "MasterType": 'Stages',
                // "Token":this.props.Token,
                "ToDate": this.state.todate,
                "FromDate": this.state.fromdate,
                "EmpCode": this.props.EmpCode
            },
            'Stages'
        ).then(response => {
            let d = response
            let data = JSON.parse(d.response), multiSelectData = []
            multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
            this.setState({ Stages: multiSelectData })
            this.setState({ StagesFilterData: data })
        }).catch(err => {
            console.log("error", err)
        });
        GridService.getGridData(

            {
                "MasterType": 'Journal',
                // "Token":this.props.Token,
                "ToDate": this.state.todate,
                "FromDate": this.state.fromdate,
                "EmpCode": this.props.EmpCode
            },
            'Journal'
        ).then(response => {
            let d = response
            let data = JSON.parse(d.response), multiSelectData = []
            multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
            this.setState({ Journal: multiSelectData })
            this.setState({ JournalFilterData: data })
        }).catch(err => {
            console.log("error", err)
        });


    }

    filterChange = (event) => {

        let multiSelectData = []
        let data = this.filterData(event.filter, event.target.props.placeholder)
        multiSelectData['ID'] = data.map(d => d.ID)
        multiSelectData['Descriptions'] = data.map(d => d.Descriptions)
        if (event.target.props.placeholder === "Select Type") {

            this.setState({
                SelectionData: this.filterData(event.filter, event.target.props.placeholder)
            });
        }
        if (event.target.props.placeholder === "Select PM") {
            this.setState({
                PM: multiSelectData
            });
        }
        if (event.target.props.placeholder === "Select Workflow") {
            this.setState({
                Workflow: multiSelectData
            });
        }
        if (event.target.props.placeholder === "Select Stages") {
            this.setState({
                Stages: multiSelectData
            });
        }
        if (event.target.props.placeholder === "Select Journal") {
            this.setState({
                Journal: multiSelectData
            });
        }
    }

    filterData(filter, name) {
        if (name === "Select Type") {
            const data = this.state.SelectionFilterData.slice();
            return filterBy(data, filter);

        }
        if (name === "Select PM") {
            let data = this.state.PMFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);

        }
        if (name === "Select Workflow") {
            let data = this.state.WorkflowFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);

        }
        if (name === "Select Stages") {

            let data = this.state.StagesFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);

        }
        if (name === "Select Journal") {

            let data = this.state.JournalFilterData.filter(x => x.Descriptions.toLowerCase().includes(filter.value.toLowerCase()));
            return (data);


        }
    }

    backfromfulldrill = () => {
        let input = this.state.Detailinput;
        input["FromDate"] = moment(this.state.fromdate).format('YYYY-MM-DD')
        input["ToDate"] = moment(this.state.todate).format('YYYY-MM-DD')


        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {

            this.setState({ FullDetail: false })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else {
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);


    }

    backdrill = () => {
        let input = this.state.Gridinput;
        input["FromDate"] = moment(this.state.fromdate).format('YYYY-MM-DD')
        input["ToDate"] = moment(this.state.todate).format('YYYY-MM-DD')


        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {

            this.setState({ isDrill: false })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else {
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);


    }

    ToGridData = (navopen, fromdat, todat) => {
        debugger
        let input = this.state.input;
        // input["FromDate"] = moment(fromdat).format('YYYY-MM-DD')
        // input["ToDate"] = moment(todat).format('YYYY-MM-DD')

        this.setState({ navopen: navopen, input: input })
        // this.setState({ fromdate: fromdat });
        // this.setState({ todate: todat })
        this.setState({ callchart: !this.state.callchart })
        // this.setState({ Datecolumns: col })
        // setTimeout(() => {
        //     this.state.remove.map((d) => {
        //         col.pop()
        //     })
        // }, 500);
    }
    TodrillGridData = (navopen, fromdat, todat) => {
        debugger
        let input = this.state.DrillchartInput;
        input["FromDate"] = moment(fromdat).format('YYYY-MM-DD')
        input["ToDate"] = moment(todat).format('YYYY-MM-DD')
        this.setState({ navopen: navopen, DrillchartInput: input })
        this.setState({ fromdate: fromdat });
        this.setState({ todate: todat })
        this.setState({ callchart: !this.state.callchart })

    }

    chartData = (navopen, data, column, Griddata, search, input) => {
        debugger

        // let columnName = OTD_columns
        // column.map((d) => {
        //     columnName.push(d)
        // })

        this.setState({ navopen: navopen })
        // this.setState({ GridColumn: columnName })
        this.setState({ callchart: !this.state.callchart })


        // this.setState({isDrillchart:isDrill})
    }
    isFullDrill = (isfrom, from, to) => {
        debugger
        if (this.state.name === '' || this.state.name === null) {
            this.setState({ name: "Workflow wise" })
        }

        this.setState({ fullFilter: isfrom })
        this.setState({ fromdate: from });
        this.setState({ todate: to });
        this.setState({ FullDetail: !this.state.FullDetail })


    }
    isDrill = (isfrom, from, to) => {
        debugger
        if (isfrom === true) {
            let input = this.state.Detailinput;
            input["FromDate"] = moment(from).format('YYYY-MM-DD')
            input["ToDate"] = moment(to).format('YYYY-MM-DD')
            this.setState({ MonthDetailinput: input })
            this.setState({ monthfromdate: from });
            this.setState({ monthtodate: to });
            this.setState({ isDrill: !this.state.isDrill })
        }
        else {
            let input = this.state.Detailinput;
            input["FromDate"] = moment(from).format('YYYY-MM-DD')
            input["ToDate"] = moment(to).format('YYYY-MM-DD')

            this.setState({ Detailinput: input })
            this.setState({ fromdate: from });
            this.setState({ todate: to });
            this.setState({ isDrill: !this.state.isDrill })

        }
    }
    FalseIsComing = () => {
        this.setState({ isComing: false })
    }
    lastUpdatedate = (date) => {
        this.setState({ lastupdate: date })
    }

    render() {

        let grid = (<div><div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Last updated on {this.state.lastupdate}</div>
<Grid title={"Long Pending Article"} lastUpdatedate={this.lastUpdatedate} navopen={this.state.navopen} isDrill={this.isDrill} FullDetail={false}
                gridsearchValue={this.state.gridsearchValue} FalseIsComing={this.FalseIsComing} Griddata={this.state.Griddata}
                isComing={this.state.isComing} name={this.state.name} input={this.state.Gridinput} columns={this.state.FullDetailedColumn}
                aggregates={this.state.Reportaggregates} chart={this.state.chartData} chartData={this.chartData} fromdate={this.state.fromdate} todate={this.state.todate} />
        </div>


        )
        let chart = (

            <div><div className="SpeedNotes"style={{marginLeft:5}}><span style={{color:"red"}}>Note :</span> Last updated on {this.state.lastupdate}</div>
                <ChartContainer fromdate={this.state.fromdate} lastUpdatedate={this.lastUpdatedate} title={"Long Pending Article"} todate={this.state.todate} chartData={this.state.chartData} input={this.state.chartInput} chartDatafunc={this.ToGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>



        )
        let drill = (

            <div className="Drillgrid">{/* To show drilldown grid */}
                <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Last updated on {this.state.lastupdate}</div>

                <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backdrill}>Go Back</Button> {/* To go back to normal grid */}
                <DrillDown navopen={this.state.navopen} title={"Long Pending Article- Detail"} isDrill={this.isFullDrill} chartData={this.chartData} input={this.state.Detailinput} columns={this.state.GridColumns} aggregates={this.state.Detailedaggregates} fromdate={this.state.fromdate} todate={this.state.todate} />

            </div>

        )

        let chartdrill = (

            <Chart fromdate={this.state.fromdate} todate={this.state.todate} title={"Long Pending Article - Detail"} chartData={this.state.chartData} input={this.state.DrillchartInput} chartDatafunc={this.TodrillGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} />


        )


        let fullDrill = (<div className="Drillgrid">{/* To show drilldown grid */}
            <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Last updated on {this.state.lastupdate}</div>

            <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backfromfulldrill}>Go Back</Button>
            <Drill navopen={this.state.navopen} title={"Long Pending Article - Detail"} input={this.state.FullDetailInput} columns={this.state.DetailedColumn} aggregates={this.state.Detailedaggregates} />

        </div>)

        return (

            this.state.callchart === false && this.state.isDrill === false && this.state.FullDetail === false ?


                <div className='move-grid-container' id='grid-container'>
                    {/* <div className="Multiselect" > */}


                    {/* <b style={{ fontWeight: "unset" }} title="Select PM"><ComboBox

                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.PM['Descriptions']}
                            value={this.state.PMname}
                            filterable={true}
                            onFilterChange={this.filterChange}


                            onChange={(e) => {

                                let name = e.target.value,
                                    input = this.state.Gridinput
                                name !== null ? input["PM"] = name : input["PM"] = ""

                                this.setState({
                                    Gridinput: input,
                                    PMname: name

                                })
                            }
                            }
                            placeholder="Select PM"

                        /></b>
                        <b style={{ fontWeight: "unset" }} title="Select Workflow"><ComboBox

                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.Workflow['Descriptions']}
                            value={this.state.workflowname}
                            filterable={true}
                            onFilterChange={this.filterChange}


                            onChange={(e) => {

                                let name = e.target.value,
                                    input = this.state.Gridinput
                                //chartinput = this.state.DrillchartInput
                                name !== null ? input["Workflow"] = name : input["Workflow"] = ""
                                //name !== null ? chartinput["Workflow"] = name : chartinput["Workflow"] = ""

                                this.setState({
                                    Gridinput: input,
                                    // DrillchartInput: chartinput,
                                    workflowname: name

                                })
                            }
                            }
                            placeholder="Select Workflow"

                        /></b><b style={{ fontWeight: "unset" }} title="Select Stages"><ComboBox

                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.Stages['Descriptions']}
                            value={this.state.Stagesname}
                            filterable={true}
                            onFilterChange={this.filterChange}


                            onChange={(e) => {

                                let name = e.target.value,
                                    input = this.state.Gridinput
                                // chartinput = this.state.DrillchartInput
                                name !== null ? input["Stage"] = name : input["Stage"] = ""
                                // name !== null ? chartinput["Stage"] = name : chartinput["Stage"] = ""

                                this.setState({
                                    Gridinput: input,
                                    // DrillchartInput: chartinput,
                                    Stagesname: name

                                })
                            }
                            }
                            placeholder="Select Stages"

                        /></b>
                        <b style={{ fontWeight: "unset" }} title="Select Journal"><ComboBox

                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.Journal['Descriptions']}
                            value={this.state.journalname}
                            filterable={true}
                            onFilterChange={this.filterChange}


                            onChange={(e) => {

                                let name = e.target.value,
                                    input = this.state.Gridinput
                                // chartinput = this.state.DrillchartInput



                                name !== null ? input["Journal"] = name : input["Journal"] = ""
                                // name !== null ? chartinput["Journal"] = name : chartinput["Journal"] = ""

                                this.setState({
                                    Gridinput: input,
                                    // DrillchartInput: chartinput,
                                    journalname: name

                                })
                            }
                            }
                            placeholder="Select Journal"

                        /></b>

                        <button className="Go_button" title="Go" onClick={() => {

                            this.setState({ callGrid: !this.state.callGrid, callAgain: !this.state.callAgain })

                        }
                        }

                        >GO</button> </div> */}
                    {this.state.callGrid && (grid)}
                    {this.state.callAgain && (grid)}

                </div>

                :
                this.state.callchart === false && this.state.isDrill === true && this.state.FullDetail === false ?
                    <div className='move-grid-container' id='grid-container'>
                        {/* <div className="Multiselect">


                            <b style={{ fontWeight: "unset" }} title="Select PM"><ComboBox

                                style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                data={this.state.PM['Descriptions']}
                                value={this.state.PMname}
                                filterable={true}
                                onFilterChange={this.filterChange}


                                onChange={(e) => {

                                    let name = e.target.value,
                                        input = this.state.Detailinput
                                    // chartinput = this.state.DrillchartInput
                                    name !== null ? input["PM"] = name : input["PM"] = ""
                                    // name !== null ? chartinput["PM"] = name : chartinput["PM"] = ""

                                    this.setState({
                                        Detailinput: input,
                                        // DrillchartInput: chartinput,
                                        PMname: name

                                    })
                                }
                                }
                                placeholder="Select PM"

                            /></b>
                            <b style={{ fontWeight: "unset" }} title="Select Workflow"><ComboBox

                                style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                data={this.state.Workflow['Descriptions']}
                                value={this.state.workflowname}
                                filterable={true}
                                onFilterChange={this.filterChange}


                                onChange={(e) => {

                                    let name = e.target.value,
                                        input = this.state.Detailinput
                                    // chartinput = this.state.DrillchartInput
                                    name !== null ? input["Workflow"] = name : input["Workflow"] = ""
                                    // name !== null ? chartinput["Workflow"] = name : chartinput["Workflow"] = ""

                                    this.setState({
                                        Detailinput: input,
                                        // DrillchartInput: chartinput,
                                        workflowname: name

                                    })
                                }
                                }
                                placeholder="Select Workflow"

                            /></b><b style={{ fontWeight: "unset" }} title="Select Stages"><ComboBox

                                style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                data={this.state.Stages['Descriptions']}
                                value={this.state.Stagesname}
                                filterable={true}
                                onFilterChange={this.filterChange}


                                onChange={(e) => {

                                    let name = e.target.value,
                                        input = this.state.Detailinput
                                    // chartinput = this.state.DrillchartInput
                                    name !== null ? input["Stage"] = name : input["Stage"] = ""
                                    // name !== null ? chartinput["Stage"] = name : chartinput["Stage"] = ""

                                    this.setState({
                                        Detailinput: input,
                                        // DrillchartInput: chartinput,
                                        Stagesname: name

                                    })
                                }
                                }
                                placeholder="Select Stages"

                            /></b>
                            <b style={{ fontWeight: "unset" }} title="Select Journal"><ComboBox

                                style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                data={this.state.Journal['Descriptions']}
                                value={this.state.journalname}
                                filterable={true}
                                onFilterChange={this.filterChange}


                                onChange={(e) => {

                                    let name = e.target.value,
                                        input = this.state.Detailinput
                                    // chartinput = this.state.DrillchartInput



                                    name !== null ? input["Journal"] = name : input["Journal"] = ""
                                    // name !== null ? chartinput["Journal"] = name : chartinput["Journal"] = ""

                                    this.setState({
                                        Detailinput: input,
                                        // DrillchartInput: chartinput,
                                        journalname: name

                                    })
                                }
                                }
                                placeholder="Select Journal"

                            /></b>
                            <button className="Go_button" title="Go" onClick={() => {

                                this.setState({ calldrillGrid: !this.state.calldrillGrid, calldrillAgain: !this.state.calldrillAgain })


                            }}>GO</button>
                        </div> */}

                        {this.state.calldrillGrid && (drill)}
                        {this.state.calldrillAgain && (drill)}
                    </div>
                    :

                    this.state.callchart === true && this.state.isDrill === false && this.state.FullDetail === false ?

                        <div className='move-chart-container' id='chart-container'>
                            <div className="Multiselect">

                                {this.state.call && (chart)}
                                {this.state.callchartAgain && (chart)}
                            </div>
                        </div> :
                        this.state.callchart === true && this.state.isDrill === true && this.state.FullDetail === false ?

                            <div className='move-chart-container' id='chart-container'>
                                <div className="Multiselect">

                                    {this.state.call && (chartdrill)}
                                    {this.state.callchartAgain && (chartdrill)}
                                </div>
                            </div>


                            :
                            this.state.callchart === false && this.state.isDrill === true && this.state.FullDetail === true ?

                                <div className='move-grid-container' id='grid-container'>
                                    {/* <div className="Multiselect" > */}
                                    {/* <b style={{ fontWeight: "unset" }} title="Select Type"><ComboBox

                                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                            data={this.state.SelectionData}
                                            value={this.state.name}
                                            filterable={true}
                                            onFilterChange={this.filterChange}


                                            onChange={(e) => {

                                                let name = e.target.value,
                                                    input = this.state.FullDetailInput;


                                                name !== null ? name === "Workflow wise" ? input["ReportType"] = "3" : name === "Country Wise" ? input["ReportType"] = "4" : input["ReportType"] = "5" : input["ReportType"] = "3"

                                                this.setState({
                                                    FullDetailInput: input,
                                                    name: name

                                                })
                                            }
                                            }
                                            placeholder="Select Type"

                                        /></b> */}
                                    {/* 
                                        <b style={{ fontWeight: "unset" }} title="Select PM"><ComboBox

                                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                            data={this.state.PM['Descriptions']}
                                            value={this.state.PMname}
                                            filterable={true}
                                            onFilterChange={this.filterChange}


                                            onChange={(e) => {

                                                let name = e.target.value,
                                                    input = this.state.Detailinput
                                                // chartinput = this.state.DrillchartInput
                                                name !== null ? input["PM"] = name : input["PM"] = ""
                                                // name !== null ? chartinput["PM"] = name : chartinput["PM"] = ""

                                                this.setState({
                                                    Detailinput: input,
                                                    // DrillchartInput: chartinput,
                                                    PMname: name

                                                })
                                            }
                                            }
                                            placeholder="Select PM"

                                        /></b>
                                        <b style={{ fontWeight: "unset" }} title="Select Workflow"><ComboBox

                                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                            data={this.state.Workflow['Descriptions']}
                                            value={this.state.workflowname}
                                            filterable={true}
                                            onFilterChange={this.filterChange}


                                            onChange={(e) => {

                                                let name = e.target.value,
                                                    input = this.state.Detailinput
                                                // chartinput = this.state.DrillchartInput
                                                name !== null ? input["Workflow"] = name : input["Workflow"] = ""
                                                // name !== null ? chartinput["Workflow"] = name : chartinput["Workflow"] = ""

                                                this.setState({
                                                    Detailinput: input,
                                                    // DrillchartInput: chartinput,
                                                    workflowname: name

                                                })
                                            }
                                            }
                                            placeholder="Select Workflow"

                                        /></b><b style={{ fontWeight: "unset" }} title="Select Stages"><ComboBox

                                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                            data={this.state.Stages['Descriptions']}
                                            value={this.state.Stagesname}
                                            filterable={true}
                                            onFilterChange={this.filterChange}


                                            onChange={(e) => {

                                                let name = e.target.value,
                                                    input = this.state.Detailinput
                                                // chartinput = this.state.DrillchartInput
                                                name !== null ? input["Stage"] = name : input["Stage"] = ""
                                                // name !== null ? chartinput["Stage"] = name : chartinput["Stage"] = ""

                                                this.setState({
                                                    Detailinput: input,
                                                    // DrillchartInput: chartinput,
                                                    Stagesname: name

                                                })
                                            }
                                            }
                                            placeholder="Select Stages"

                                        /></b>
                                        <b style={{ fontWeight: "unset" }} title="Select Journal"><ComboBox

                                            style={{ width: "190px", marginLeft: '4px', marginTop: '3px' }}
                                            data={this.state.Journal['Descriptions']}
                                            value={this.state.journalname}
                                            filterable={true}
                                            onFilterChange={this.filterChange}


                                            onChange={(e) => {

                                                let name = e.target.value,
                                                    input = this.state.Detailinput
                                                // chartinput = this.state.DrillchartInput



                                                name !== null ? input["Journal"] = name : input["Journal"] = ""
                                                // name !== null ? chartinput["Journal"] = name : chartinput["Journal"] = ""

                                                this.setState({
                                                    Detailinput: input,
                                                    // DrillchartInput: chartinput,
                                                    journalname: name

                                                })
                                            }
                                            }
                                            placeholder="Select Journal"

                                        /></b>
                                        <button className="Go_button" title="Go" onClick={() => {

                                            this.setState({ callfulldrillGrid: !this.state.callfulldrillGrid, callfulldrillAgain: !this.state.callfulldrillAgain })
                                            if(this.state.name===''||this.state.name===null){
                                                this.setState({name:"Workflow wise"})
                                            }

                                        }}>GO</button>
                                    </div> */}
                                    {this.state.callfulldrillGrid && (fullDrill)}
                                    {this.state.callfulldrillAgain && (fullDrill)}
                                </div> : null
        );


    }
}

export default LongPending;