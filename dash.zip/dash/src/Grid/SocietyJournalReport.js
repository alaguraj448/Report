import React from "react";
import ChartContainer from '../Chart/SocietyJournalChart';
import Grid from './SocietyJournalGrid';
import { Journal_columns } from './SocietyJournalColumn';
import { DetailJournal_columns } from './SocietyJournalDetailColumn';
import { DetailJournal_columns2 } from './SocietyJournaldetailColumn2';

import { FullDetailJournal_columns } from './SocietyJournalFullColumn'
import moment from 'moment';
import DrillDown from './SocietyJournalDetail'
import DrillDown2 from './SocietyJournalDetail2'

import { Button } from '@progress/kendo-react-buttons';
import Chart from '../Chart/AuthorDetailChart'
import Drill from './SocietyJournalFullGrid'
import { ComboBox } from '@progress/kendo-react-dropdowns';
import { GridService } from '../services/grid.services';
import { filterBy } from '@progress/kendo-data-query';





let fromdate = new Date();
let todate = new Date();
let toDateCol = new Date();
//todate.setDate(todate.getDate() - 1)
if (fromdate.getDate() === 1) {
    fromdate.setDate(2);
    fromdate.setMonth(fromdate.getMonth() - 1)
    //todate=fromdate
}
else {

    fromdate.setDate(1);
    // todate=fromdate

}

class SocietyJournal extends React.Component {


    state = {
        Authorcolumns: Journal_columns,
        Datecolumns: [],
        DetailedColumn: DetailJournal_columns,
        DetailedColumn2: DetailJournal_columns2,
        FullDetailedColumn: FullDetailJournal_columns,
        Detailedaggregates: [],
        Reportaggregates: [],
        FullDetail: false,
        SelectionData: ["Published", "Not Published (< 40 Days)", "Not Published (> 40 Days)"],
        SelectionFilterData: ["Published", "Not Published (< 40 Days)", "Not Published (> 40 Days)"],
        Query: [],
        QueryFilterData: [],
        name:'Published',
        PM: [],
        PMFilterData: [],
        Stages: [],
        StagesFilterData: [],
        Workflow: [],
        WorkflowFilterData: [],
        Journal: [],
        JournalFilterData: [],
        fullFilter: "FullDetail",


        Publishedinput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '1'

        },

        Detailinput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '4'
        },
        Detailinput2: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '6'
        },
        chartInput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '8'

        },
        DrillchartInput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '2',
            "Workflow": "",
            "Stage": "",
            "PM": "",
            "Journal": ""

        },

        FullDetailInput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '5'
        },
        FullDetailInput2: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '7'
        },
        callGrid: true,
        callAgain: false,
        callchart: true,
        calldrillGrid: true,
        calldrillAgain: false,
        call: true,
        callchartAgain: false,
        callfulldrillGrid: true,
        callfulldrillAgain: false,
        fromdate: fromdate,
        todate: todate,
        Griddata: [],
        chartData: [],
        isDrill: false,
        gridsearchValue: "",
        PMname: "",
        Stagesname: "",
        journalname: "",
        workflowname: "",
        Queryname: ""

    }

    componentWillMount = () => {


        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    componentDidMount() {
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }

    }

    filterChange = (event) => {


        if (event.target.props.placeholder === "Select Type") {

            this.setState({
                SelectionData: this.filterData(event.filter, event.target.props.placeholder)
            });
        }
    }

    filterData(filter, name) {
        if (name === "Select Type") {
            const data = this.state.SelectionFilterData.slice();
            return filterBy(data, filter);

        }
    }

    backfromfulldrill = () => {
        let input = this.state.Detailinput;
        input["FromDate"] = moment(this.state.fromdate).format('YYYY-MM-DD')
        input["ToDate"] = moment(this.state.todate).format('YYYY-MM-DD')


        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {

            this.setState({ FullDetail: false })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else {
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);


    }

    backdrill = () => {
        let input = this.state.Publishedinput;
        input["FromDate"] = moment(this.state.fromdate).format('YYYY-MM-DD')
        input["ToDate"] = moment(this.state.todate).format('YYYY-MM-DD')


        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {

            this.setState({ isDrill: false })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else {
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);


    }

    ToGridData = (navopen, fromdat, todat) => {
        debugger
        let input = this.state.Publishedinput;
        input["FromDate"] = moment(fromdat).format('YYYY-MM-DD')
        input["ToDate"] = moment(todat).format('YYYY-MM-DD')

        this.setState({ navopen: navopen, input: input })
        this.setState({ fromdate: fromdat });
        this.setState({ todate: todat })
        this.setState({ callchart: !this.state.callchart })
        // this.setState({ Datecolumns: col })
        // setTimeout(() => {
        //     this.state.remove.map((d) => {
        //         col.pop()
        //     })
        // }, 500);
    }
    TodrillGridData = (navopen, fromdat, todat) => {
        debugger
        let input = this.state.DrillchartInput;
        input["FromDate"] = moment(fromdat).format('YYYY-MM-DD')
        input["ToDate"] = moment(todat).format('YYYY-MM-DD')
        this.setState({ navopen: navopen, DrillchartInput: input })
        this.setState({ fromdate: fromdat });
        this.setState({ todate: todat })
        this.setState({ callchart: !this.state.callchart })

    }

    chartData = (navopen, data, column, Griddata, search, input) => {
        debugger

        // let columnName = OTD_columns
        // column.map((d) => {
        //     columnName.push(d)
        // })

        this.setState({ navopen: navopen })
        // this.setState({ GridColumn: columnName })
        this.setState({ callchart: !this.state.callchart })


        // this.setState({isDrillchart:isDrill})
    }
    isFullDrill = (isfrom, from, to) => {
        debugger

        this.setState({ fullFilter: isfrom })
        this.setState({ fromdate: from });
        this.setState({ todate: to });
        this.setState({ FullDetail: !this.state.FullDetail })


    }
    isDrill = (isfrom, from, to) => {
        debugger
        if (isfrom === true) {
            let input = this.state.Detailinput;
            input["FromDate"] = moment(from).format('YYYY-MM-DD')
            input["ToDate"] = moment(to).format('YYYY-MM-DD')
            this.setState({ MonthDetailinput: input })
            this.setState({ monthfromdate: from });
            this.setState({ monthtodate: to });
            this.setState({ isDrill: !this.state.isDrill })
        }
        else {
            let input = this.state.Detailinput;
            input["FromDate"] = moment(from).format('YYYY-MM-DD')
            input["ToDate"] = moment(to).format('YYYY-MM-DD')

            this.setState({ Detailinput: input })
            this.setState({ fromdate: from });
            this.setState({ todate: to });
            this.setState({ isDrill: !this.state.isDrill })

        }
    }
    FalseIsComing = () => {
        this.setState({ isComing: false })
    }
    lastUpdatedate = (date) => {
        this.setState({ lastupdate: date })
    }

    render() {

        let grid = (<div>
            <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Only Tier3 information available in the customer's daily WIP report . Last updated on {this.state.lastupdate}</div>
            <Grid title={"Speed Report - PM"} lastUpdatedate={this.lastUpdatedate} navopen={this.state.navopen} isDrill={this.isDrill} FullDetail={false}
                gridsearchValue={this.state.gridsearchValue} FalseIsComing={this.FalseIsComing} Griddata={this.state.Griddata}
                isComing={this.state.isComing} name={this.state.name} input={this.state.Publishedinput} columns={this.state.Authorcolumns}
                aggregates={this.state.Reportaggregates} chart={this.state.chartData} chartData={this.chartData} fromdate={this.state.fromdate} todate={this.state.todate} /></div>


        )
        let chart = (

            <div>
            <div className="SpeedNotes" style={{marginLeft:5}}><span style={{color:"red"}}>Note :</span> Only Tier3 information available in the customer's daily WIP report . Last updated on {this.state.lastupdate}</div>
                <ChartContainer fromdate={this.state.fromdate} lastUpdatedate={this.lastUpdatedate}  title={"Speed Report - PM"} filter={this.state.name} todate={this.state.todate} chartData={this.state.chartData} input={this.state.chartInput} chartDatafunc={this.ToGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>



        )
        let drill = (

            <div className="Drillgrid">{/* To show drilldown grid */}
            <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Only Tier3 information available in the customer's daily WIP report . Last updated on {this.state.lastupdate}</div>

                <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backdrill}>Go Back</Button> {/* To go back to normal grid */}
                <DrillDown navopen={this.state.navopen} title={"Speed Report - PM - Detail"} isDrill={this.isFullDrill} chartData={this.chartData} input={this.state.Detailinput} DetailedColumn={this.state.DetailedColumn} Detailedaggregates={this.state.Detailedaggregates} fromdate={this.state.fromdate} todate={this.state.todate} filter={"FullDetail"} />
                <DrillDown2 navopen={this.state.navopen} title={"Speed Report - PM - Detail"} isDrill={this.isFullDrill} chartData={this.chartData} input={this.state.Detailinput2} DetailedColumn={this.state.DetailedColumn2} Detailedaggregates={this.state.Detailedaggregates} fromdate={this.state.fromdate} todate={this.state.todate} filter={"FullDetail2"} />

            </div>

        )

        let chartdrill = (
            <div>
                <div className="SpeedNotes" style={{marginLeft:5}}><span style={{color:"red"}}>Note :</span> Only Tier3 information available in the customer's daily WIP report . Last updated on {this.state.lastupdate}</div>

            <Chart fromdate={this.state.fromdate} todate={this.state.todate} title={"Speed Report - PM - Detail"} chartData={this.state.chartData} input={this.state.DrillchartInput} chartDatafunc={this.TodrillGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>


        )


        let fullDrill = (this.state.fullFilter === "FullDetail" ? <div className="Drillgrid">{/* To show drilldown grid */}
                <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Only Tier3 information available in the customer's daily WIP report . Last updated on {this.state.lastupdate}</div>

            <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backfromfulldrill}>Go Back</Button>
            <Drill navopen={this.state.navopen} title={"Speed Report - PM - Detail"} input={this.state.FullDetailInput} DetailedColumn={this.state.FullDetailedColumn} Detailedaggregates={this.state.Detailedaggregates} />

        </div> :
            <div className="Drillgrid">{/* To show drilldown grid */}
                <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Only Tier3 information available in the customer's daily WIP report . Last updated on {this.state.lastupdate}</div>

                <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backfromfulldrill}>Go Back</Button>
                <Drill navopen={this.state.navopen} title={"Speed Report - PM - Detail"} input={this.state.FullDetailInput2} DetailedColumn={this.state.FullDetailedColumn} Detailedaggregates={this.state.Detailedaggregates} />

            </div>)

        return (

            this.state.callchart === false && this.state.isDrill === false && this.state.FullDetail === false ?


                <div className='move-grid-container' id='grid-container'>
                    <div className="Multiselect" >
                    <div className="inn">Apply filter : 
                        <b style={{ fontWeight: "unset" }} title="Select Type"><ComboBox

                            style={{ width: "270px", marginLeft: '4px', marginTop: '3px' }}
                            data={this.state.SelectionData}
                            value={this.state.name}
                            filterable={true}
                            onFilterChange={this.filterChange}


                            onChange={(e) => {

                                let name = e.target.value,
                                    input = this.state.Publishedinput;


                                name !== null ? name === "Published" ? input["ReportType"] = "1" : name === "Not Published (< 40 Days)" ? input["ReportType"] = "2" : input["ReportType"] = "3" : input["ReportType"] = "1"

                                this.setState({
                                    input: input,
                                    name:name !== null ?name: "Published"

                                })
                            }
                            }
                            placeholder="Select Type"

                        /></b>

                        <button className="Go_button" title="Go" onClick={() => {

                            this.setState({ callGrid: !this.state.callGrid, callAgain: !this.state.callAgain })

                        }
                        }

                        >GO</button> </div></div>
                    {this.state.callGrid && (grid)}
                    {this.state.callAgain && (grid)}

                </div>

                :
                this.state.callchart === false && this.state.isDrill === true && this.state.FullDetail === false ?
                    <div className='move-grid-container' id='grid-container'>
                        <div className="Multiselect">

                        </div>

                        {this.state.calldrillGrid && (drill)}
                        {this.state.calldrillAgain && (drill)}
                    </div>
                    :

                    this.state.callchart === true && this.state.isDrill === false && this.state.FullDetail === false ?

                        <div className='move-chart-container' id='chart-container'>
                            <div className="Multiselect">
                           
                                {this.state.call && (chart)}
                                {this.state.callchartAgain && (chart)}
                            </div>
                        </div> :
                        this.state.callchart === true && this.state.isDrill === true && this.state.FullDetail === false ?

                            <div className='move-chart-container' id='chart-container'>
                                <div className="Multiselect">

                                    {this.state.call && (chartdrill)}
                                    {this.state.callchartAgain && (chartdrill)}
                                </div>
                            </div>


                            :
                            this.state.callchart === false && this.state.isDrill === true && this.state.FullDetail === true ?

                                <div className='move-grid-container' id='grid-container'>
                                    <div className="Multiselect" style={{ marginLeft: '0px', }}>


                                    </div>
                                    {this.state.callfulldrillGrid && (fullDrill)}
                                    {this.state.callfulldrillAgain && (fullDrill)}
                                </div> : null
        );


    }
}

export default SocietyJournal;