
import * as React from 'react';
import { process, filterBy, orderBy } from '@progress/kendo-data-query';
import {
    Grid, GridColumn, GridToolbar
} from '@progress/kendo-react-grid';
import { GridService } from '../services/grid.services'
import { saveAs, encodeBase64 } from '@progress/kendo-file-saver';
import { ExcelExport } from '@progress/kendo-react-excel-export';
import { Input } from "@progress/kendo-react-inputs";
import { Button } from '@progress/kendo-react-buttons';
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { ComboBox } from '@progress/kendo-react-dropdowns'
import { CustomColumnMenu } from './customColumnMenu.js';
import '../App.css';
import * as BiIcons from 'react-icons/bi';
import Header from './editHeader'
import DrillDown from './CCDrilldownGrid'
import { IntlProvider, load, LocalizationProvider, loadMessages, IntlService } from '@progress/kendo-react-intl';
import likelySubtags from 'cldr-core/supplemental/likelySubtags.json';
import currencyData from 'cldr-core/supplemental/currencyData.json';
import weekData from 'cldr-core/supplemental/weekData.json';
import numbers from 'cldr-numbers-full/main/es/numbers.json';
import currencies from 'cldr-numbers-full/main/es/currencies.json';
import caGregorian from 'cldr-dates-full/main/es/ca-gregorian.json';
import dateFields from 'cldr-dates-full/main/es/dateFields.json';
import timeZoneNames from 'cldr-dates-full/main/es/timeZoneNames.json';
load(likelySubtags, currencyData, weekData, numbers, currencies, caGregorian, dateFields, timeZoneNames);
const DATE_FORMAT = 'yyyy-MM-dd hh:mm:ss';
const intl = new IntlService('es-ES');
let products = [],fixed=[], tempdata = false, reordering = false
let value=new Date()
let fromDate=new Date();
let toDate=new Date()
fromDate.setMonth(fromDate.getMonth()-3);
fromDate.setDate(1)
toDate.setDate(toDate.getDate()-1)


export default class App extends React.Component {
    _export;
    // Function to export grid data
    export = () => {
        if (reordering) { /* Executed when reordeing is true */
            this.reorder()
            setTimeout(() => {
                this._export.save();
                this.setState({
                    data: products, columns: this.state.afterExportColumn, isLoading: false, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
                reordering = true
            }, 200);
        }
        else this._export.save(); /* Executed when reordeing is false */
    }
    gridPDFExport;

    anchor = null;
    anchor2 = null;
    // Variable to store template name from local storage
    QTRtemplateName = JSON.parse(localStorage.getItem('QTRtemplateName')) === null ? [] : JSON.parse(localStorage.getItem('QTRtemplateName'));
    // Variable to store template state from local storage
    QTRtemplateState = JSON.parse(localStorage.getItem('QTRtemplateState')) === null ? [] : JSON.parse(localStorage.getItem('QTRtemplateState'));
    constructor(props) {
        super(props); /* Gets Props 'name, input, columns, getData, aggregates, chartData ' */

        const dataState = this.createDataState({
            take: 25,
            skip: 0,
        });

        // this.getData = this.props.getData()

        // Initialize the state of the component
        this.state = {
            data: [],
            setMinWidth: false,
            columns: [...this.props.DetailedColumn],
            gridCurrent: 0,
            isLoading: false,
            showPopupOnRefresh: false,
            showPopupOnSaveTemp: false,
            inputSearchValue: null,
            searchvalue: "",
            newTemplate: null,
            tempCount: this.QTRtemplateName.length,
            exporting: false,
            filterable: false,
            chartData: [],
            viewChart: false,
            popupChart: false,
            itemPage: 25,
            group: [],
            isDrill:false,
            filter: { logic: "", filters: [] },
            reortered: false,
            afterExportColumn:[...this.props.DetailedColumn],
            chartInput:{"FromDate":fromDate,
        "ToDate":toDate},
            input: this.props.input,
            navopen: false,
            aggregates: [...this.props.Detailedaggregates],
            ...dataState
        };
    }
    minGridWidth = 0;
   
    componentDidMount() {
        debugger

        if (this.props.navopen) {
            document.getElementById('grid-container').style.marginLeft = "150px";
        }
        

        // Function to fetch data from api and load it to grid
        if (this.props.isComing === true) {
            this.setState({
                backgrid: this.props.Griddata
            })
            if (this.props.gridsearchValue !== "") {
                // document.getElementById("Searchbox").value=this.props.searchvalue
                this.setState({ searchvalue: this.props.gridsearchValue })
            }
            // products = this.props.Griddata.map((dataItem, idx) => Object.assign({ ID: idx, selected: false }, dataItem))
            this.setState({
                data: this.props.Griddata, columns: this.state.columns, ...this.createDataState({
                    take: this.state.itemPage,
                    skip: 0,
                    group: this.state.group,
                    sort: this.state.sort,
                    filter: this.state.filter
                })
            })
            setTimeout(() => {
                this.props.FalseIsComing()
            }, 400);
        }
        else{
         
            setTimeout(() => {   this.setState({ isLoading: true })
            }, 100);
            GridService.CCDetailedReport(this.props.input).then(response => {
                let d = response
                let data = JSON.parse(d.response)
                products = data.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                products.forEach(o => {
                        
                    o.ReceivedDate =o.ReceivedDate ===null?  '':intl.parseDate(o.ReceivedDate);
                    o.ProdDespatchDate =o.ProdDespatchDate ===null?  '':  intl.parseDate(o.ProdDespatchDate);
                    o.DespatchDate =o.DespatchDate ===null?  '': intl.parseDate(o.DespatchDate);
                });
                    fixed=products
                this.setState({
                    data: products,backgrid: products, columns: this.state.columns, isLoading: false, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
            }).catch(err => {
                console.log("error", err)
                this.setState({ isLoading: false })
    
            });
    

        }
      

    }



    // Executes every time when a state is created
    createDataState(dataState) {
        debugger
    
        const groups = dataState.group;
        if (groups) { groups.map(group => group.aggregates = this.state.aggregates); }
        const result = process(products.slice(0), dataState);
   
        if (tempdata === true || groups) {
            let total = result.total, newDataState = dataState, excel, take = dataState.take;
            newDataState.take = total
            newDataState.group = []
            excel = process(products.slice(0), newDataState).data
            tempdata = false
            newDataState.group = groups
            products = excel
            this.setState({ isLoading: false })
            newDataState.take = take
           
        }
        return {
            result: result,
            dataState: dataState,
        Footerdata:result.data,
        Footertotal:result.total
        };
    }

    // Executes every time when a state is changed
    dataStateChange = (event) => {
        this.setState(this.createDataState(event.dataState));
    }

    // Executes on the column menu submit
    onColumnsSubmit = (columnsState) => {
        this.setState({
            columns: columnsState
        });
    }

    expandChange = (event) => { // Executes on expand and close of grouped data 
        event.dataItem[event.target.props.expandField] = event.value;
        this.setState({
            result: Object.assign({}, this.state.result),
            dataState: this.state.dataState
        });
    }
    pageChange = (event) => { // Executes on page change in grid
        this.setState({
            skip: event.page.skip,
            take: event.page.take
        });
    }
    
   
    searchData = e => { // Function for common search in grid 
        debugger
        let value = e.target.value;
        this.setState({ searchvalue: e.target.value })
        let field = this.state.columns.map(column => { return { field: column.field, operator: "contains", value: value } })
        let filter = {
            logic: "or",
            filters: field
        };
       
        products = filterBy(this.state.data, filter)
        fixed=products
        this.dataStateChange(this.state)
    };

    filterChange = (event) => { // Function for filter change
 
        products = filterBy(this.state.data, event.filter)
        fixed=products
     
      
        this.setState({
            filter: event.filter,
            ...this.createDataState({
                take: this.state.itemPage,
                skip: 0
            })
            
        });
        setTimeout(() => {this.dataStateChange(this.state) }, 100);
        // products=this.state.refreshData
    }

    selectionChange = (event) => { // Executes when select or unselect header select in grid
        const data = this.state.data.map(item => {
            if (item.ID === event.dataItem.ID) {
                item.selected = !event.dataItem.selected;
            }
            return item;
        });
        this.setState({ data });
    }

    headerSelectionChange = (event) => { // Executes when select or unselect a row in grid
        const checked = event.syntheticEvent.target.checked;
        const data = this.state.data.map(item => {
            item.selected = checked;
            return item;
        });
        this.setState({ data });
    }

    cellRender(tdElement, cellProps) {  // This function is used for any changes in the cells in grid

        if (cellProps.dataItem.aggregates !== undefined) {
            let i = 0, key = Object.keys(cellProps.dataItem.aggregates)
            if (cellProps.rowType === 'groupFooter') {
                for (i; i < key.length; i++) {
                    if (cellProps.field === key[i]) {
                        return (
                            <td data-toggle="tooltip" >
                                <b title={"Sum: " + parseFloat(cellProps.dataItem.aggregates[key[i]].sum).toFixed(2)}>Sum: {parseFloat(cellProps.dataItem.aggregates[key[i]].sum).toFixed(2)}</b><br />
                                <b title={"Average: " + parseFloat(cellProps.dataItem.aggregates[key[i]].average).toFixed(2)}> Average: {parseFloat(cellProps.dataItem.aggregates[key[i]].average).toFixed(2)}</b>
                            </td>
                        );
                    }
                }

            }
        }
        if (cellProps.field === "selected") {
            return (tdElement)
        }
        else if (tdElement) {

            if (cellProps.field === 'ID') {
                return (<td className="extraID" style={{ textAlign: 'center' }} title={tdElement.props.children}>{tdElement.props.children}</td>)
            }
            else {

                return (<td className="extra-number" style={{ textAlign: 'center' }} title={tdElement.props.children}>{tdElement.props.children}</td>)
            }

        }
        return (tdElement)
    }

    // Function no executes on Refresh no option 
    no = () => { this.setState({ showPopupOnRefresh: !this.state.showPopupOnRefresh, inputSearchValue: null }) }

    // Function yes executes on Refresh yes option 
    yes = () => {
        reordering = false
        this.setState({
            columns: [...this.props.DetailedColumn],
            data: products,
            setMinWidth: false,
            gridCurrent: 0,
            filter: undefined,
            showPopupOnRefresh: false,
            initTemp: null,
            inputSearchValue: null,
            searchvalue: "",
            sort: [],
            itemPage: 25,
            group: [],
            filterable: false
        })
        this.componentDidMount();
        this.dataStateChange(this.state)

    }
    backdrill=()=>{
        this.props.isDrill(false)
        this.setState({isDrill:false})
    }
    // Function executes on Refresh
    onRefresh = () => {
        this.setState({ showPopupOnRefresh: !this.state.showPopupOnRefresh, inputSearchValue: "" });
    }



  

    sortChange = (event) => { // Function for sorting in grid
        this.setState({
            data: this.getProducts(event.sort),
            sort: event.sort
        });
        
        products = this.getProducts(event.sort)
        fixed=products
        this.dataStateChange(this.state)

    }

    getProducts = (sort) => {
        return orderBy(products, sort);
    }

    changeStuff(val, idx) { // Funtion to save edited column header changes from child component to state of parent component
        let editColumn = JSON.parse(JSON.stringify(this.state.columns));
        editColumn[idx].title = val
        this.setState({ columns: editColumn });
    }

    loadingPanel = ( /* Code for showing loading symbol */
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );

    Total = props => {
        const field = props.field || '';
        let count = this.state.Footertotal
        const total = fixed.reduce((acc, current) => {
            return acc + parseFloat(current[field])
        }, 0);
        const avg=total/count
        let average=parseFloat(avg).toFixed(2)
        let value = parseFloat(total).toFixed(2)
   setTimeout(() => {
       products=fixed
   }, 200);
        if(field==="JournalName"){
            return(  <td colSpan={props.colSpan} style={props.style} title={"Count:" + count}>Count: {count}</td>)
        }
        else if(field==="TatHours"){
            return(  <td colSpan={props.colSpan} style={props.style} title={"Average:" + average}>Average: {average}</td>)
        }
        // else if(field==="score"){
        //     return(            <td colSpan={props.colSpan} style={props.style} title={"Total:" + value}>Total: {value} </td> 
        //     )
        // }
      else{
          return(<td></td>)
      }
          
    };

    reorder = () => { // This function is used to save the reordered column in that order to state columns 
        let gridOrder = this.grid.columns, column = [], finalColumn = [], col = JSON.parse(JSON.stringify(this.state.columns))
        gridOrder.map(data => {
            if (data.field !== "selected") {
                column[data.orderIndex - 1] = this.state.columns.find(d => d.field === data.field)
            }
            return null
        })
        let hideColumn = this.state.columns.filter(d => d.show === false)
        finalColumn.push(...hideColumn)
        finalColumn.push(...column)
        this.setState({ columns: finalColumn, afterExportColumn: col })
        reordering = false
        // return column

    }


    render() {
        const grid = (
            //Telerik Grid Component
            <Grid
                // style={{ height: '400px'}}
                data={this.state.result}
                {...this.state.dataState}
                onDataStateChange={this.dataStateChange}
                sortable={{ mode: "multiple" }}
                sort={this.state.sort}
                onSortChange={this.sortChange}
                pageable={{ pageSizes: [5, 10, 20, 25] }}
                total={this.state.Footertotal}
                resizable={true}
                groupable={{ footer: 'visible' }}
                reorderable={true}
                filterable={true}
                filter={this.state.filter}
                onFilterChange={this.filterChange}
                expandField="expanded"
                onExpandChange={this.expandChange}
                selectedField={this.state.columns.length > 1 ? 'selected' : ''}
                onSelectionChange={this.selectionChange}
                onHeaderSelectionChange={this.headerSelectionChange}
                cellRender={this.cellRender}
                ref={(g) => { this.grid = g; }}
                onColumnReorder={() => reordering = true}


            >
                <GridToolbar>

                 
               
                  
                  

                    {/* Checkbox to enable / disable filter in grid */}
                    {/* <div className="col-md-12"> */}
                        <input
                            className="k-checkbox"
                            // defaultChecked={false}
                            checked={this.state.filterable}
                            id="previousNext"
                            type="checkbox"
                            onChange={e => { this.setState({ filterable: !this.state.filterable }); }}
                        />
                        <label
                            htmlFor="previousNext"
                            className="k-checkbox-label"
                        >
                            Enable Filter
                                </label>
                    {/* </div> */}

                    {/* Input field for Search within grid */}
                    <Input style={{ marginLeft: 20 }} maxLength="256" title='Search' type='search' onChange={this.searchData} placeholder={'Search'} value={this.state.searchvalue} />
 {/* Button to Export Excel */}
 <Button
                        // primary={true}
                        title="Export Excel"
                        onClick={this.export}
                    >
                        Export to Excel
                    </Button>
                    {/* Refresh icon to show popup for refresh */}
                    <ul><li title="Refresh" style={{ marginLeft: "-30px" }} ref={(li) => this.anchor = li} onClick={this.onRefresh}><BiIcons.BiRefresh color='#042e68' size='2em' /></li></ul>
  
                    {/* Popup for refresh grid */}
                    {this.state.showPopupOnRefresh && (
                        <Dialog title={"Please confirm"} onClose={this.no}>
                            <p
                                style={{
                                    margin: "25px",
                                    textAlign: "center",
                                }}
                            >
                                By refreshing, Filter and Search data will be cleared out. Are you sure want to continue?
                                </p>
                            <DialogActionsBar>

                                {/* Button to close and cancel refresh  */}
                                <button className="k-button" onClick={this.no}>
                                    No
                                    </button>

                                {/* Button to refresh grid */}
                                <button className="k-button" onClick={this.yes}>
                                    Yes
                                    </button>
                            </DialogActionsBar>
                        </Dialog>
                    )}

                </GridToolbar>

                {/* Column for MultiSelect rows */}
                {this.state.columns.length > 0 && (<GridColumn
                    field="selected"
                    width="0px"
                    filterable={false}
                    hidden={true}
                    headerSelectionValue={
                        this.state.data.findIndex(dataItem => dataItem.selected === false) === -1
                    } />)}

                {/* Code to show specific columns */}

                {
                    this.state.columns.map((column, idx) =>
                        column.show && (

                                <GridColumn
                                    key={idx}
                                    field={column.field}
                                    format={column.format}
                                    title={column.title}
                                    filter={column.filter}
                                    filterable={this.state.filterable}
                                    width={column.minWidnt}
                                    footerCell={this.Total}
                                    headerCell={ // Grid props to do changes in column header
                                        props =>

                                            <Header
                                                {...props}
                                                idx={idx}
                                                minwidth={column.minWidnt}
                                                changeHandler={this.changeStuff.bind(this)}
                                            />
                                    }
                                    columnMenu={ // Grid props for column menu
                                        props =>
                                            <CustomColumnMenu
                                                {...props}
                                                columns={this.state.columns}
                                                products={this.state.data}
                                                onColumnsSubmit={this.onColumnsSubmit}
                                                filterable={this.state.filterable}
                                            />
                                    }
                                /> 
                        )
                    )
                }

            </Grid>
        )

        return (
            
         <div className='move-grid-body' id="grid-body">
                <h5>{this.props.title}</h5> {/* To show normal grid */}
                {(this.state.isLoading) && (this.loadingPanel)}

                <ExcelExport // Telerik ExcelExport compnent to export grid data
                    fileName={this.props.fileName}
                    data={
                        this.state.data.filter((item) => item.selected === true).length > 0 ?
                            this.state.data.filter((item) => item.selected === true) : products
                    }
                    ref={exporter => this._export = exporter}
                >
                    {grid}

                </ExcelExport>
                <br />
            </div>
            
        );
    }
}
