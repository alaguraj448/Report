export const FullDetail_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "EmpName",
        title: "Employee Name",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
    ,
    
    {
        field: "Nos",
        title: "Nos",
        minWidnt: 185,
        filter: "text",
        show: true,
        format:"{0:0.00}" ,
        date:"no"
    }
    ,
    
    {
        field: "Collation",
        title: "Collation",
        minWidnt: 185,
        filter: "text",
        show: true,
        format:"{0:0.00}",
        date:"no"
    }
    ,
    
    {
        field: "Editorial Proofreading",
        title: "Editorial Proofreading",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "{0:0.00}",
        date:"no"
    }
    
]