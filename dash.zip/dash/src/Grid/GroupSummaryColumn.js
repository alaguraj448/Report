export const GroupSummary_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "Budget",
        title: "",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Plan_MTD",
        title: "Plan MTD",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Actuals",
        title: "Actuals",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Variance",
        title: "Variance",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Variance_per",
        title: "Variance Percentage",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
]