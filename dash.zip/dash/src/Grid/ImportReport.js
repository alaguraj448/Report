import React from "react"; 
import { GridService } from '../services/grid.services'  
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { IntlProvider, load, LocalizationProvider } from "@progress/kendo-react-intl";
import likelySubtags from "cldr-core/supplemental/likelySubtags.json";
import currencyData from "cldr-core/supplemental/currencyData.json";
import weekData from "cldr-core/supplemental/weekData.json";
import numbers from "cldr-numbers-full/main/es/numbers.json";
import caGregorian from "cldr-dates-full/main/es/ca-gregorian.json";
import dateFields from "cldr-dates-full/main/es/dateFields.json";
import timeZoneNames from "cldr-dates-full/main/es/timeZoneNames.json";
import moment from 'moment';
import { filterBy } from '@progress/kendo-data-query';  
import { Button } from '@progress/kendo-react-buttons';  
import { ComboBox } from '@progress/kendo-react-dropdowns';
import { throwStatement } from "@babel/types"; 
import {OutTable, ExcelRenderer} from 'react-excel-renderer'; 
import {NotificationContainer, NotificationManager} from 'react-notifications';
// import { isIPv4 } from "net";
load(likelySubtags, currencyData, weekData, numbers, caGregorian, dateFields, timeZoneNames); 
let fromdate = new Date();
let todate = new Date(); 

class ImportReport extends React.Component {
 
    
    locale = {
        language: "en-US",
        locale: "en"
    }
    
    state = { 
        dataLoaded: false,
        selectedStartDate:"",
        weekNumber:"",
        currentUser:"",
        FileName:"",
        selectedEndDate:"",
        dateDiffSelectedWeek:"",
        existingRecordCount:"",
        isValidWeek:false,
        selectedWeekInExcel:"",
        lastUploadedtime:"",
        jsonDataForImport:{},
        isValidDefectSheet:false,
        uploadFileFormat:"",
        showAlertfileUploadAlert:false,
        fileInput : React.createRef(), 
        Datecolumns: [],
        Monthcolumns: [], 
        Detailedaggregates: [],
        MonthDetailaggregates: [],
        Filter: ["Defect Report"],
        FilterData:["Defect Report"],
        Filter2: [  "Week 1", "Week 2", "Week 3", "Week 4", "Week 5", "Week 6", "Week 7", "Week 8", "Week 9", "Week 10", "Week 11", "Week 12", "Week 13", "Week 14", "Week 15", "Week 16", "Week 17", "Week 18", "Week 19", "Week 20", "Week 21", "Week 22", "Week 23", "Week 24", "Week 25", "Week 26", "Week 27", "Week 28", "Week 29", "Week 30", "Week 31", "Week 32", "Week 33", "Week 34", "Week 35", "Week 36", "Week 37", "Week 38", "Week 39", "Week 40", "Week 41", "Week 42", "Week 43", "Week 44", "Week 45", "Week 46", "Week 47", "Week 48", "Week 49", "Week 50", "Week 51", "Week 52"  ] ,
        Filter2Data: [  "Week 1", "Week 2", "Week 3", "Week 4", "Week 5", "Week 6", "Week 7", "Week 8", "Week 9", "Week 10", "Week 11", "Week 12", "Week 13", "Week 14", "Week 15", "Week 16", "Week 17", "Week 18", "Week 19", "Week 20", "Week 21", "Week 22", "Week 23", "Week 24", "Week 25", "Week 26", "Week 27", "Week 28", "Week 29", "Week 30", "Week 31", "Week 32", "Week 33", "Week 34", "Week 35", "Week 36", "Week 37", "Week 38", "Week 39", "Week 40", "Week 41", "Week 42", "Week 43", "Week 44", "Week 45", "Week 46", "Week 47", "Week 48", "Week 49", "Week 50", "Week 51", "Week 52"  ] ,
        Filtername: "Defect Report",
        Filtername2: "Select Week",
        FullDetail: false, 
        callGrid: true,
        callAgain: false,
        callchart: true,
        calldrillGrid: true,
        calldrillAgain: false,
        call: true,
        callchartAgain: false,
        callmonthGrid: true,
        callmonthAgain: false,
        callmonthdrillGrid: true,
        callmonthdrillAgain: false,
        callmonth: true,
        callmonthchartAgain: false,
        callfulldrillGrid: true,
        callfulldrillAgain: false,
        maintainto: todate,
        maintainfrom: fromdate,
        fromdate: fromdate,
        todate: todate,
        OTDReportaggregates: [],
        dateColumn: [],
        GridColumn: [],
        Griddata: [],
        chartData: [],
        remove: [],
        isDrill: false,
        gridsearchValue: "",
        changefilter: "Defect Report", 

    };
     importExcel =  () =>  {
         let sWeekStart = this.state.selectedStartDate;
         
         console.log(sWeekStart);  
         if(this.state.selectedStartDate === "" && this.state.selectedEndDate === "" ){ 
            NotificationManager.warning('Please select a Week', 'Alert!', 3000);
         } else if(Number(this.state.dateDiffSelectedWeek) < 0){
            NotificationManager.warning('Please select a valid Week', 'Alert!', 3000);
         } else if (this.state.isValidDefectSheet === false){
            NotificationManager.warning('Please select valid defect sheet', 'Alert!', 3000);
         }  
         else if (this.state.existingRecordCount > 0){ 
            NotificationManager.warning('Data already exists for the selected week', 'Alert!', 3000); 
         }  
         else if(this.state.weekNumber != this.state.selectedWeekInExcel  ){
            NotificationManager.warning('Selected Week is incorrect. Please check', 'Alert!', 3000);
         }else if(!this.state.isValidWeek ){
            NotificationManager.warning('Invalid Week number found. Please check', 'Alert!', 3000);
         }
         else { 
                if(this.state.jsonDataForImport.length > 0 && (this.state.uploadFileFormat == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"  || this.state.uploadFileFormat == "application/vnd.ms-excel")){
                 let postdataForLog ={
                        "User": this.state.User,
                        "FileName": this.state.FileName, 
                        "Week": this.state.weekNumber,
                        "FromDate": this.state.selectedStartDate,
                        "ToDate": this.state.selectedEndDate
                    } 
                 console.log(postdataForLog);
               //  setTimeout(() => {     this.setState({ isLoading: true }) }, 600);
                const postJsonofReport = this.state.jsonDataForImport; 
                        console.log('excelJson',postJsonofReport);
                        postJsonofReport.forEach(function (value,index) {
                                    console.log(value,index);
                                    GridService.importDefectsReport(value).then(response => {
                                            let resData = response.isSuccess 
                                            console.log(resData);  
                                        }).catch(err => {
                                            console.log("error", err)
                                            
                                        });
                                      if( postJsonofReport.length - 1 == index ){
                                        GridService.logImportedDefectReport(postdataForLog).then(response => {
                                            let resDataMsg = response.isSuccess 
                                            console.log(resDataMsg);  
                                        }).catch(err => {
                                            console.log("error", err)
                                            this.setState({ isLoading: false })
                                        });
                                          console.log("upload call end")
                                          setTimeout(() => {   NotificationManager.success('File has been uploaded. ', 'Success!', 3000);  }, 600);
                                                            setTimeout(() => {
                                                window.location.reload(); 
                                            }, 3000); 

                                      }
                                }); 
                                //setTimeout(() => {     this.setState({ isLoading: false }) }, 100);
                                
                                
                            //    setTimeout(() => { NotificationManager.success('File has been uploaded. ', 'Success!', 3000);  }, 600); 
                        // setTimeout(() => {
                        //     window.location.reload(); 
                        // }, 3000); 
                        
                        
                }else{
                        
                    NotificationManager.warning('Please select a valid file to upload', 'Alert!', 3000);
                    // alert('Please select a valid sheet.')
                }
            }
             } 
            
     componentWillMount = () => {


        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    componentDidMount() { 
        if (this.state.navopen) {
            document.getElementById('grid-container').style.marginLeft = "150px";
            // document.getElementById('grid-body').style.marginLeft = "50px";
        }

        GridService.getRecentUploadDetail().then(response => {
            let lastUploadedInfo = response.data.recordset[0];
            let lastUploadedTime = moment(lastUploadedInfo.CreatedDate).utc().format('DD-MM-YYYY hh:mm A') 
            console.log(lastUploadedInfo);
            this.setState({ lastUploadedtime : lastUploadedTime   })
        }) 
        let postDataIn =  { "weekNum": 100 }
         GridService.getWeekRange(postDataIn).then(response => {
            let weekRangeCollection = response.data.recordset; 
            console.log(weekRangeCollection); 
            this.setState({ Filter2 : weekRangeCollection   })
            this.setState({ Filter2Data : weekRangeCollection   })
        }) 
        this.setState({
            todatecheckyear: todate.getFullYear(),
            fromdatecheckyear: fromdate.getFullYear()  
        })  
    }
    
    filterChange = (event) => {
        if (event.target.props.placeholder === "Select Filter") {
            this.setState({
                Filter: this.filterData(event.filter, event.target.props.placeholder)
            });
        }
    }
    filterData(filter, name) {
    if (name === "Select Filter") {
        const data = this.state.FilterData.slice();
        return filterBy(data, filter);
    }

    }
    filterChange2 = (event) => {
         console.log("err"+event);
        if (event.target.props.placeholder === "Select Filter 2") {
            this.setState({
                Filter2: this.filterData2(event.filter, event.target.props.placeholder)
            });
           
        } 
    }
    filterData2(filter, name) {
    if (name === "Select Filter 2") { 
        const data = this.state.Filter2Data.slice();
        return filterBy(data, filter);
    }

    }
    
    openFileBrowser = () => {
        this.fileInput.current.click();
      }
    renderFile = (fileObj) => {
        //just pass the fileObj as parameter
        ExcelRenderer(fileObj, (err, resp) => {
          if(err){
            console.log(err);            
          }
          else{
            this.setState({
              dataLoaded: true,
              cols: resp.cols,
              rows: resp.rows
            });
          }
        }); 
    }
    closeAlert = (event) => { 
         this.setState({
             showAlertfileUploadAlert :false
         }); 
    }
	 fileHandler = (event) => {
			 let fileObj = event.target.files[0]; 
             this.setState({ uploadFileFormat: fileObj.type  });  
                if(fileObj.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"  || fileObj.type === "application/vnd.ms-excel"  ){
                            console.log(fileObj);     
                            let currUser = this.props.Name;
                            var date1 = moment('2016-10-08 10:29:23');
                            var date2 = moment('2016-10-08 11:06:55');
                            var diff = date2.diff(date1);
						console.log("entered 1",diff);
                        this.setState({ FileName: fileObj.name, User: currUser }); 
							//just pass the fileObj as parameter
							ExcelRenderer(fileObj, (err, resp) => {
							  if(err){
								console.log(err);            
							  }
							  else{
								// console.log(resp); 
								// console.log(resp.rows.join().split(",").map(x => "'" + x + "'").join());  
								const tRows =[];  
								const tObject =[]; 
                                const tHeaders = [];  
                                const tRowsUpated = [];   
                                const tWeekNumber = [];   
                                let isValidWeek = false; 
                                let invalidColmsCount = 0;
                                const defaultHeaders = ["DATE","ERROR CATEGORY","MANUSCRIPT_ID","PRODUCT","WEEK"].map(element => {
                                    return element.toUpperCase();
                                  });
                                
							     resp.rows.forEach(function (value,index) {
                                   if(index === 0){
                                    tHeaders.push(value)
                                   }
								if (index > 0){
								 tRows.push(value);
								//  console.log(value,index)
								} 
							   })
                               const tableHeadersUpper = tHeaders[0].map(element => {
                                return element.toUpperCase();
                              });
                
                console.log(tableHeadersUpper); 
                  //  const isIncluded =  defaultHeaders.some(value => tableHeadersUpper[0].includes(value))
                    const jsonArray = tableHeadersUpper.map(i => {
                    return { 'name': i, 'matched': defaultHeaders.includes(i) };
                 }); 
                 defaultHeaders.forEach(function (value,index) { 
                     console.log(tableHeadersUpper.indexOf(value)+value); 
                     if(tableHeadersUpper.indexOf(value) < 0){
                        ++invalidColmsCount;
                     }
                     console.log(invalidColmsCount); 
                }); 
                   if(invalidColmsCount === 0 ){
                          console.log(invalidColmsCount); 
                    this.setState({ isValidDefectSheet: true  }); 
                   }
                   else{
                    console.log(invalidColmsCount); 
                    this.setState({ isValidDefectSheet: false  }); 
                   }
                   
                    console.log(tRowsUpated)    
                    tRows.map((item,i) => (  
					 tObject.push({
					  "DefectDate":item[0],
                      "Month":item[1],
					  "DefectWeek": Number(item[2]),
					  "JournalAcronym": item[3],
					  "ProductionManager":  item[4],
					  "Supervisor":  item[5],
					  "ProductionEditor":  item[6],
					  "Supplier": item[7],
					  "ManuscriptID": item[8],
					  "Issue":  item[9],
					  "ArticleType":item[10],
					  "GroupID":item[11],
					  "DefectAreaLogged":item[12],
					  "DefectCategoryLogged":item[13],
					  "InstructionCategoryLogged":item[14],
					  "Workflow":item[15],
					  "Division":item[16],
					  "Stage":item[17],
					  "StageGroup":item[18],
					  "DU":item[19],
					  "Product":item[20],
					  "ErrorCategory":item[21],
					  "ErrorSubCategory":item[22],
					  "Element":item[23],
					  "TechnologyActionImplementedJournals":item[24],
					  "Repeated":item[25],
					  "QCAbleToDetect":item[26],
					  "NoOfError":item[27],
					  "iAuthorInternalOrExternal":item[28],
					  "Description":"Y",
					  "RequestedRCAOrFeedback":item[30],
					  "LoggedByUsername2":item[31],
					  "DateLogged2":item[32],
					  "SentToSupplier":item[33],
					  "DateReturned":item[34],
					  "RCA":item[35],
					  "Action":item[36],
					  "ImplementationDate":item[37],
					  "PMName":'', 
					  "CollationCompletedBy":'' 
								})
								 
								)) 
								console.log(tObject)  
								 this.setState({ jsonDataForImport: tObject }); 
                                 tObject.forEach(function (value,index) { 
                                    console.log(value.DefectWeek) 
                                    tWeekNumber.push(value.DefectWeek)  
                                });
                                isValidWeek = tWeekNumber.every( (val, i, arr) => val === arr[0] )
                                console.log(tWeekNumber.every( (val, i, arr) => val === arr[0] ) )
                                this.setState({ isValidWeek: isValidWeek });  
                                this.setState({ selectedWeekInExcel: tWeekNumber[0] }); 
							  }
							});               
                        }
                        else{ 
                            NotificationManager.warning('Please select valid Excel Sheet', 'Alert!', 3000);   
                        }
						  }
    render() {

      const selectedStartDate = this.state.selectedStartDate;
      const selectedEndDate = this.state.selectedEndDate;
      const postJsonofReport = this.state.jsonDataForImport; 
     
        return (
            <div className='move-grid-container' id='grid-container'><br />
             <div> 
              <NotificationContainer/>
            
            
                  <div className="Multiselect"> 
                        <h4 style={{ color: "#212529" }}>Import Excel for Dashboard - TandF  </h4>
                
                <div className="SpeedNotes" style={{marginLeft:5}}><span style={{color:"red"}}>Note : </span> Last upload done on {this.state.lastUploadedtime}</div> 
                   <b style={{ fontWeight: "unset" }} title="Select Filter"><ComboBox

                            style={{ width: "200px", marginLeft: '4px', marginTop: '30px' }}
                            data={this.state.Filter}
                            value={this.state.Filtername}
                            filterable={true}
                            onFilterChange={this.filterChange} 
                            onChange={(e) => {
                                let name = e.target.value, select;
                                name !== null ? select = name : select = "Defect Report"
                                // console.log(name)

                                this.setState({
                                    Filtername: select,

                                })
                            }
                            }
                            placeholder="Select Filter"

                        /></b>
                   <b style={{ fontWeight: "unset" }} title="Select Filter"><ComboBox

                            style={{ width: "320px", marginLeft: '20px', marginTop: '30px' }}
                            data={this.state.Filter2}
                            value= {this.state.Filtername2}
                            textField={'dateRange'}
                            filterable={true}
                            onFilterChange={this.filterChange}


                            onChange={(e) => {


                                let name = e.target.value, select;

                               

                                name !== null ? select = name : select = "Select Week"
                                 console.log(name)
                                   console.log(name.dateRange.split(" ")[1]);
                                   let weekNumberSelect = name.dateRange.split(" ")[1]; 
                                    let postDataIn =  { "weekNum": weekNumberSelect }
                                this.setState({
                                    Filtername2: select,
                                    weekNumber:weekNumberSelect
                                });
                                  GridService.getWeekRange(postDataIn).then(response => {
                                    let resData = response.data.recordset[0]; 
                                     let CurrentDate = moment(new Date()).format('DD-MM-YYYY');
                                    let StartOfWeek = moment(resData.StartOfWeek).format('DD-MM-YYYY');
                                    let EndOfWeek =  moment(resData.EndOfWeek).format('DD-MM-YYYY');
                                    let dateDiff =  resData.dayDiff; 
                                    console.log(resData); 
                                    if(resData.StartOfWeek === 'invalid' && resData.EndOfWeek === 'invalid'){
                                    alert('Please select valid week')
                                    }else{
                                     this.setState({ dataLoaded: true });
                                     this.setState({ selectedStartDate:  StartOfWeek});
                                     this.setState({ selectedEndDate: EndOfWeek }); 
                                     this.setState({ dateDiffSelectedWeek : dateDiff });  
                                     this.setState({ existingRecordCount : resData.defectsCountExists });   
                                    }
                                }).catch(err => {
                                    console.log("error", err)
                                    this.setState({ isLoading: false })
                                });
                            }
                            }
                            placeholder="Select Week"

                            /></b>
                    </div>
                    <div className='move-grid-body' id="grid-body">
                    <div className="fileUploadDiv" style={{ marginBottom:'20px',marginTop:'20px'}}>

                             { }
                       
                         </div>
                        { this.state.showAlertfileUploadAlert &&  
                    <div className="alert success"><span className="closebtn" onClick={this.closeAlert } >&times;</span><strong>Success!</strong> Uploaded Successfully.</div> 
                     } <h4></h4>  
                       
                        <input className="importExcelBtn" type="file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"  onChange={this.fileHandler.bind(this)} ref={this.fileInput} onClick={(event)=> { event.target.value = null }} style={{"padding":"5px"}} />
                      <Button primary={true} title="Upload Excel" onClick={this.importExcel } >Upload</Button>
                     { }
                    
                         
                        <h4></h4> 
                        <h4></h4> 

                        { }  
                </div>
                </div>
                </div>
        );


    }
}

export default ImportReport;