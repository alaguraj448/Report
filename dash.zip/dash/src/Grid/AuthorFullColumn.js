
export const AuthorFullDetail_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date: "no"
    },

    {
        field: "Book Code",
        title: "Book Code",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Division",
        title: "Division",
        minWidnt: 200,
        filter: "text",
        show: true,
        format: "",
        date: "no",
    },
    {
        field: "Stage",
        title: "Stage",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "WorkFlow",
        title: "WorkFlow",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Received Date (CATS)",
        title: "Received Date (CATS)",
        minWidnt: 195,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Due Date (CATS)",
        title: "Due Date (CATS)",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Hour(s)",
        title: "Hour(s)",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Prod. Despatch Date",
        title: "Prod. Despatch Date",
        minWidnt: 195,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "MS Pages",
        title: "MS Pages",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Word Count",
        title: "Word Count",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Query Status",
        title: "Query Status",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Query Date",
        title: "Query Date",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Query Text",
        title: "Query Text",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Project Manager",
        title: "Project Manager",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Cell",
        title: "Cell",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Responsible person",
        title: "Responsible person",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "InputType",
        title: "InputType",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Notes",
        title: "Notes",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Engine Status",
        title: "Engine Status",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "S3Response",
        title: "S3Response",
        minWidnt: 195,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "iTracksAcknowledgement",
        title: "iTracksAcknowledgement",
        minWidnt: 205,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Current Activity",
        title: "Current Activity",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Priority",
        title: "Priority",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    }

]