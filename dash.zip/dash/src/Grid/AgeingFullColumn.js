
export const AgeingFullDetail_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date: "no"
    },

    {
        field: "Acronym",
        title: "Acronym",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Production_Manager",
        title: "Production_Manager",
        minWidnt: 200,
        filter: "text",
        show: true,
        format: "",
        date: "no",
    },
    {
        field: "Production_Editor",
        title: "Production_Editor",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Ms_Workflow",
        title: "Ms_Workflow",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Manuscript_Id",
        title: "Manuscript_Id",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Secondary_Ms_Id",
        title: "Secondary_Ms_Id",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Status",
        title: "Status",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Issue",
        title: "Issue",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Num_Pages",
        title: "Num_Pages",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Num_Typeset_Pages",
        title: "Num_Typeset_Pages",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Accepted_Date",
        title: "Accepted_Date",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Received_Date",
        title: "Received_Date",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Entered_Date",
        title: "Entered_Date",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Published_Online",
        title: "Published_Online",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Days_Since_Entered",
        title: "Days_Since_Entered",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Days_Entered_To_Pub_Online",
        title: "Days_Entered_To_Pub_Online",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Last_Step",
        title: "Last_Step",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Last_Step_Date",
        title: "Last_Step_Date",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Days_Since_Last_Step",
        title: "Days_Since_Last_Step",
        minWidnt: 195,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "On_Sam_Yn",
        title: "On_Sam_Yn",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Host_Area",
        title: "Host_Area",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Ms_Type",
        title: "Ms_Type",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Copyright_Yn",
        title: "Copyright_Yn",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Copyr_Req",
        title: "Copyr_Req",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Notes",
        title: "Notes",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Supervisor",
        title: "Supervisor",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Issue_Workflow",
        title: "Issue_Workflow",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Group_Id",
        title: "Group_Id",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Speed_Target",
        title: "Speed_Target",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Matrix",
        title: "Matrix",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Advances_Approved",
        title: "Advances_Approved",
        minWidnt: 200,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "On_Hold_Yn",
        title: "On_Hold_Yn",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Hold_Reason",
        title: "Hold_Reason",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "OA_Status",
        title: "OA_Status",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "OA_Status_Change_Date",
        title: "OA_Status_Change_Date",
        minWidnt: 215,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    },
    {
        field: "Copyright_Uploaded",
        title: "Copyright_Uploaded",
        minWidnt: 190,
        filter: "text",
        show: true,
        format: "",
        date: "no"
    }

]