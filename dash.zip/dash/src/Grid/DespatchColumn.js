export const Despatch_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "SPMName",
        title: "SPM Name",
        minWidnt: 325,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Acronym",
        title: "Acronym",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "DispatchDate",
        title: "Dispatch Date",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "JobCardId",
        title: "Job Card ID",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "Pages",
        title: "Pages",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    }
    
]