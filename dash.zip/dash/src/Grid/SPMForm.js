
import * as React from 'react';
import { GridService } from '../services/grid.services'

import { Button } from '@progress/kendo-react-buttons';
import DrillDown from './SPMDrill'


import '../App.css';
let products = [], fixed = [], tempdata = false, reordering = false
let value = new Date()
let fromDate = new Date();
let toDate = new Date()
fromDate.setDate(1)
fromDate.setMonth(0);
toDate.setDate(31);
toDate.setMonth(11)


export default class App extends React.Component {
    _export;
    // Function to export grid data
    export = () => {
        if (reordering) { /* Executed when reordeing is true */
            this.reorder()
            setTimeout(() => {
                this._export.save();
                this.setState({
                    data: products, columns: this.state.afterExportColumn, isLoading: false, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
                reordering = true
            }, 200);
        }
        else this._export.save(); /* Executed when reordeing is false */
    }
    gridPDFExport;

    anchor = null;
    anchor2 = null;
    // Variable to store template name from local storage
    QTRtemplateName = JSON.parse(localStorage.getItem('QTRtemplateName')) === null ? [] : JSON.parse(localStorage.getItem('QTRtemplateName'));
    // Variable to store template state from local storage
    QTRtemplateState = JSON.parse(localStorage.getItem('QTRtemplateState')) === null ? [] : JSON.parse(localStorage.getItem('QTRtemplateState'));
    constructor(props) {
        super(props); /* Gets Props 'name, input, columns, getData, aggregates, chartData ' */

        this.state = {

            data: [],
         
            isLoading: false,
            chartData: [],
            viewChart: false,
            popupChart: false,
            isDrill: false,
            AvgSPMJournals:"",
            AvgSPMPages:"",
      
            T3Per:"",
            T1Per:"",
            chartInput: {
                "FromDate": fromDate,
                "ToDate": toDate
            },
            input: this.props.input,
            navopen: false,

        };
    }


    componentDidMount() {
        debugger

        if (this.props.navopen) {
            document.getElementById('grid-container').style.marginLeft = "150px";
            document.getElementById('grid-body').style.marginLeft = "50px";
        }

        // Function to fetch data from api and load it to grid
        if (this.props.isComing === true) {
            this.setState({
                backgrid: this.props.Griddata,chartData:this.props.chart,DetailData:this.props.drilldata
            })
            this.setState({AvgSPMJournals:this.props.Griddata[0].AvgSPMJournals,
                AvgSPMPages:this.props.Griddata[0].AvgSPMPages,
                T1Per:this.props.Griddata[0].T1Per,
                T3Per:this.props.Griddata[0].T3Per,
         
            }) 
            if (this.props.gridsearchValue !== "") {
                // document.getElementById("Searchbox").value=this.props.searchvalue
                this.setState({ searchvalue: this.props.gridsearchValue })
            }
            // products = this.props.Griddata.map((dataItem, idx) => Object.assign({ ID: idx, selected: false }, dataItem))
            this.setState({
                data: this.props.Griddata

            })
            setTimeout(() => {
                this.props.FalseIsComing()
            }, 400);
        }
        else {

            this.setState({ isLoading: true }) ;

            GridService.SPMReport(this.props.input).then(response => {

                let d = response
                let data = JSON.parse(d.response)
                this.setState({AvgSPMJournals:data.Table[0].AvgSPMJournals,
                    AvgSPMPages:data.Table[0].AvgSPMPages,
                    T1Per:data.Table[0].T1Per,
                    T3Per:data.Table[0].T3Per,
                    DetailData: data.Table1,
                    chartData:data.Table2,
                    backgrid:data.Table,
                    isLoading:false
                }) 
                
            }).catch(err => {
                console.log("error", err)
                this.setState({ isLoading: false })

            });


        }


    }
    loadingPanel = ( /* Code for showing loading symbol */
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );

    DetailedView=()=>{
        if (document.getElementById('grid-container').style.marginLeft === "150px") {
            this.setState({ navopen: true })
        }
        else{
            this.setState({ navopen: false })
        }
        setTimeout(() => {
            this.props.isDrill(true,this.state.navopen)
            this.setState({isDrill:true})   
        }, 200);
  
    }
    backdrill=()=>{
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else{
                this.setState({navopen:false})
            }
        }
        setTimeout(() => {
            this.props.isDrill(false)
        this.setState({isDrill:false})
        }, 100); 
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else{
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);

    } 

    render() {


        return (
     
            <div className='move-grid-body' id="grid-body">
                <h5>SPM workload (Norms and Actual) </h5> {/* To show normal grid */}
                {(this.state.isLoading) && (this.loadingPanel)}

                <div className="buttons">

                    <Button
                        // primary={true}
                        title="Export Excel"
                        onClick={this.DetailedView}
                    >
                        Detailed View
                    </Button>

                    <Button
                        // primary={true}
                        title="View as Chart"

                        onClick={() => {
    
                                setTimeout(() => {
                                    this.props.chartData(this.state.navopen, this.state.chartData, this.state.backgrid, this.state.searchvalue,this.state.DetailData)
                                }, 100);
                                // }






                        }}
                    >
                        View as Chart
                    </Button>
                    <div className="InputLabel">
                        <div className="journal" >
                            <label for="journal">Average journals per SPM</label>
                            <input type="text" id="journal" name="" value={this.state.AvgSPMJournals} readOnly></input><br></br>
                            <label for="lname">Average pages per SPM</label>
                            <input type="text" id="lname" name="" value={this.state.AvgSPMPages} readOnly></input>
                        </div>
                        <div className="Tier">
                            <h5>Portfolio Split by Tier</h5>
                            <label for="Tier1">Tier 1</label>
                            <input type="text" id="Tier1" name="" value={`${this.state.T1Per}%`} readOnly></input><br></br>
                            <label for="Tier2">Tier 3</label>
                            <input type="text" id="Tier2" name="" value={`${this.state.T3Per}%`} readOnly></input>
                        </div>
                    </div>

                </div>
                <br />
            </div> 
           
        );
                    
    }
}
