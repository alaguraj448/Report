export const Lag_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "KeyMetrix",
        title: "Key Metrix",
        tooltip:"hbj2",
        minWidnt: 210,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "Target",
        title: "Target",
        tooltip:"hbj3",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "{0:0.00}" ,
        date:"no"
    }
    ,
    {
        field: "Actual",
        title: "Actual",
        tooltip:"hbj4",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "{0:0.00}" ,
        date:"no"
    }
    ,
    {
        field: "Weightage",
        title: "Weightage",
        tooltip:"hbj5",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "{0:0.00}" ,
        date:"no"
    } ,
    {
        field: "Score",
        title: "Score",
        tooltip:"hbj6",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: "{0:0.00}" ,
        date:"no"
    }

]