export const longPendingfull_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    }, {
        field: "Ageing",
        title: "Delay in Days",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }, {
        field: "T1Open",
        title: "Open Queries",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "T1Closed",
        title: "Closed Queries",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "T1Blank",
        title: "Blank Queries",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "T3Open",
        title: "Open Queries",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "T3Closed",
        title: "Closed Queries",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "T3Blank",
        title: "Blank Queries",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "POpen",
        title: "Open Queries",
        minWidnt: 210,
        filter: "text",
        show: true,
        format: ""
    },{
        field: "PClosed",
        title: "Closed Queries",
        minWidnt: 210,
        filter: "text",
        show: true,
        format: ""
    },{
        field: "PBlank",
        title: "Blank Queries",
        minWidnt: 190,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Total",
        title: "Total",
        minWidnt: 180,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }, {
        field: "Tier1",
        title: "Tier1 Total",
        minWidnt: 180,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }, {
        field: "Tier3",
        title: "Tier3 Total",
        minWidnt: 180,
        filter: "text",
        show: true,
        format: "",
        Type:""
    },{
        field: "PEManaged",
        title: "PE managed Total",
        minWidnt: 250,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }
]
export const longPendingfull_column2 = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    }, {
        field: "Ageing",
        title: "Delay in Days",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }, {
        field: "US",
        title: "US",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "UK",
        title: "UK",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Total",
        title: "Total",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }
]
export const longPendingfull_column3 = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    }, {
        field: "Ageing",
        title: "Delay in Days",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }, {
        field: "Collation",
        title: "Collation",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "EPR",
        title: "EPR",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Total",
        title: "Total",
        minWidnt: 160,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }
]