import React from "react";
import GroupsummaryQTRGrid from './GroupsummaryQTRGrid'
import GroupsummaryGrid from './GroupSummaryGrid'
import ChartContainer from './QTRAsChart';
import { GroupSummary_column } from './GroupSummaryColumn';
import { GroupSummaryQTR_column } from './GroupSummaryQTRColumn';
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { IntlProvider, load, LocalizationProvider } from "@progress/kendo-react-intl";
import likelySubtags from "cldr-core/supplemental/likelySubtags.json";
import currencyData from "cldr-core/supplemental/currencyData.json";
import weekData from "cldr-core/supplemental/weekData.json";
import numbers from "cldr-numbers-full/main/es/numbers.json";
import caGregorian from "cldr-dates-full/main/es/ca-gregorian.json";
import dateFields from "cldr-dates-full/main/es/dateFields.json";
import timeZoneNames from "cldr-dates-full/main/es/timeZoneNames.json";
import { RadioButton } from "@progress/kendo-react-inputs";
import moment from 'moment'

load(likelySubtags, currencyData, weekData, numbers, caGregorian, dateFields, timeZoneNames);

const value = new Date();
class GroupSummary extends React.Component {
    locale = {
        language: "en-US",
        locale: "en"
    }
    state = {
        GroupsummaryColumn: GroupSummary_column,
        GroupsummaryQTRColumn: GroupSummaryQTR_column,
        input: {
            "SelecteDate": value.toISOString().split('T')[0],
            "RadioValue": "Target"

        },
        callGrid: true,
        callAgain: false,
        callchart: false,
        Groupsummaryaggregates: [
            { field: 'Budget', aggregate: 'sum' },
            { field: 'Plan_MTD', aggregate: 'sum' },
            { field: 'Actuals', aggregate: 'sum' },
            { field: 'Variance', aggregate: 'sum' },
            { field: 'Budget', aggregate: 'average' },
            { field: 'Plan_MTD', aggregate: 'average' },
            { field: 'Actuals', aggregate: 'average' },
            { field: 'Variance', aggregate: 'average' },
        ],
        GroupsummaryQTRColumnaggregates: [
            { field: 'Budget', aggregate: 'sum' },
            { field: 'Actuals', aggregate: 'sum' },
            { field: 'Variance', aggregate: 'sum' },
            { field: 'Budget', aggregate: 'average' },
            { field: 'Actuals', aggregate: 'average' },
            { field: 'Variance', aggregate: 'average' },
        ],
        selectedValue: "Target",
        Griddata: [],
        chartData: [],
        gridsearchValue: ""
    }
    componentWillMount = () => {
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) 
            {
                document.getElementById('grid-container').style.marginLeft = "45px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) 
            {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    componentDidMount() {
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    ToGridData = (navopen) => {
        this.setState({ isComing: true })

        this.setState({ navopen: navopen })
        this.setState({ callchart: !this.state.callchart })
    }
    chartData = (navopen, data, Griddata, search) => {
        debugger
        this.setState({ Griddata: Griddata })
        this.setState({ chartData: data })
        this.setState({ navopen: navopen })
        this.setState({ callchart: !this.state.callchart })
        this.setState({ gridsearchValue: search })
        // this.setState({isDrillchart:isDrill})
    }

    FalseIsComing = () => {
        this.setState({ isComing: false })
    }
    changeToStuff = (date) => {
        let input = this.state.input;
        input["SelecteDate"] = moment(date).format('YYYY-MM-DD')
        setTimeout(() => {
            this.setState({ input: input })
        }, 200);

    }
    handleChange = (e) => {
        let input = this.state.input;
        input["RadioValue"] = e.value
        this.setState({ selectedValue: e.value, input: input });
    };
    render() {

        // let grid = (<div></div>)
        let grid = (<div>    <GroupsummaryGrid navopen={this.state.navopen} selectedValue={this.state.selectedValue} IsKAM={this.props.IsKAM} IsKAMHead={this.props.IsKAMHead}
            gridsearchValue={this.state.gridsearchValue} FalseIsComing={this.FalseIsComing} Griddata={this.state.Griddata}
            isComing={this.state.isComing} name={this.state.name} input={this.state.input} columns={this.state.GroupsummaryColumn}
            aggregates={this.state.Groupsummaryaggregates} chartData={this.chartData} />
            <GroupsummaryQTRGrid navopen={this.state.navopen}  selectedValue={this.state.selectedValue} IsKAM={this.props.IsKAM} IsKAMHead={this.props.IsKAMHead}
                gridsearchValue={this.state.gridsearchValue} FalseIsComing={this.FalseIsComing} Griddata={this.state.Griddata}
                isComing={this.state.isComing} name={this.state.name} input={this.state.input} columns={this.state.GroupsummaryQTRColumn}
                aggregates={this.state.GroupsummaryQTRColumnaggregates} chartData={this.chartData} /></div>)


        return (

            this.state.callchart === false ?


                <div className='move-grid-container' id='grid-container'>

                    <div className={this.state.isDrill === true || this.state.isDrillchart === true ? "noMultiselect" : "Multiselect"}>

                        <b style={{ fontWeight: "unset", marginLeft: '4px', marginTop: '3px' }} title="To Date">
                            <LocalizationProvider language={this.locale.language}>
                                <IntlProvider locale={this.locale.locale}>
                                    <label className="k-form-field">
                                        <span><b>Select Date : </b></span>
                                        <DatePicker
                                            title="select Date"
                                            defaultValue={value}

                                            onChange={
                                                (e) => {
                                                    let value = e.target.value
                                                    this.changeToStuff(value)
                                                }
                                            }
                                        
                                        format="dd/MM/yyyy"

                                        />
                                    </label>                             </IntlProvider>
                            </LocalizationProvider>

                        </b>
                        <span className="RadioSelect">
                            <RadioButton
                                name="group1"
                                value="Target"
                                checked={this.state.selectedValue === "Target"}
                                label="Target"
                                onChange={this.handleChange}
                            />
                            <RadioButton
                                name="group1"
                                value="Budget"
                                checked={this.state.selectedValue === "Budget"}
                                label="Budget"
                                onChange={this.handleChange}
                            />

                        </span>
                        <button className="Go_button" title="Go" onClick={() => {

                            this.setState({ callGrid: !this.state.callGrid, callAgain: !this.state.callAgain, isFromGo: true })




                        }}>GO</button>


                    </div>
                    {this.state.callGrid && (grid)}
                    {this.state.callAgain && (grid)}
                </div>
                :
                <ChartContainer chartData={this.state.chartData} input={this.state.input} chartDatafunc={this.ToGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} />
        );


    }
}

export default GroupSummary;