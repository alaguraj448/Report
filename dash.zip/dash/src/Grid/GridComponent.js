
import * as React from 'react';
import { process, filterBy, orderBy } from '@progress/kendo-data-query';
import {
    Grid, GridColumn, GridToolbar
} from '@progress/kendo-react-grid';
import { GridService } from '../services/grid.services'
import { saveAs, encodeBase64 } from '@progress/kendo-file-saver';
import { ExcelExport } from '@progress/kendo-react-excel-export';
import { Input } from "@progress/kendo-react-inputs";
import { Button } from '@progress/kendo-react-buttons';
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { ComboBox } from '@progress/kendo-react-dropdowns'
import { CustomColumnMenu } from './customColumnMenu.js';
import '../App.css';
import * as BiIcons from 'react-icons/bi';
import Header from './editHeader'
import DrillDown from './DrilldownGrid'


let products = [],fixed=[],products1 = [],products2 = [],products3 = [],products4 = [],products5 = [], tempdata = false, reordering = false

export default class App extends React.Component {
    _export;
    _exportGridOne;
    _exportGridTwo;
    _exportGridThree;
    _exportGridFour;
    _exportGridFive;
    // Function to export grid data
    export = () => {
        if (reordering) { /* Executed when reordeing is true */
            this.reorder()
            setTimeout(() => {
                this._export.save();
            }, 200);
            this.setState({
                data: products, columns: this.state.afterExportColumn, isLoading: false, ...this.createDataState({
                    take: this.state.itemPage,
                    skip: 0,
                    group: this.state.group,
                    sort: this.state.sort,
                    filter: this.state.filter
                })
            })
            reordering = true


        }
        else this._export.save(); /* Executed when reordeing is false */


    }
    exportAll=()=>{
        this.setState({isLoading:true})
        let setCol = this.state.columns.find(c => c.field === 'Process')
        GridService.AllGridData(this.state.exportALL).then(response => {
            let d = response
            let data = JSON.parse(d.response)
 
            debugger
            let data1=data.Table1,data2=data.Table2,data3=data.Table3,data4=data.Table4,data5=data.Table5;
            let newcol1,newcol2,newcol3,newcol4,newcol5

            if (data1.length > 0) {
                if (data1[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol1 = this.state.columns1.map(c => {
                     
                            if (c.field === 'Process') {
                                c.title = data1[0]['Alias']
                                return c
                            }
                        

                        return c
                    })
                    this.setState({ columns1: newcol1 })
                }
                products1 = data1.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data1: products1,isLoading:false, columns1: this.state.columns1, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
            }
            if (data2.length > 0) {
                if (data2[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol2 = this.state.columns2.map(c => {
                     
                            if (c.field === 'Process') {
                                c.title = data2[0]['Alias']
                                return c
                            }
                        

                        return c
                    })
                    this.setState({ columns2: newcol2 })
                }
                products2 = data2.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data2: products2,isLoading:false, columns2: this.state.columns2, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
            }
            if (data3.length > 0) {
                if (data3[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol3 = this.state.columns3.map(c => {
                     
                            if (c.field === 'Process') {
                                c.title = data3[0]['Alias']
                                return c
                            }
                        

                        return c
                    })
                    this.setState({ columns3: newcol3 })
                }
                products3 = data3.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data3: products3,isLoading:false, columns3: this.state.columns3, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
            }
            if (data4.length > 0) {
                if (data4[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol4 = this.state.columns4.map(c => {
                     
                            if (c.field === 'Process') {
                                c.title = data4[0]['Alias']
                                return c
                            }
                        

                        return c
                    })
                    this.setState({ columns4: newcol4 })
                }
                products4 = data4.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data4: products4,isLoading:false, columns4: this.state.columns4, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
            }
            if (data5.length > 0) {
                if (data5[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol5 = this.state.columns5.map(c => {
                     
                            if (c.field === 'Process') {
                                c.title = data5[0]['Alias']
                                return c
                            }
                        

                        return c
                    })
                    this.setState({ columns5: newcol5 })
                }
                products5 = data5.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data5: products5,isLoading:false, columns5: this.state.columns5, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
        const optionsGridOne = this._exportGridOne.workbookOptions();
        const optionsGridTwo = this._exportGridTwo.workbookOptions();
        const optionsGridThree  = this._exportGridThree.workbookOptions();
        const optionsGridFour =this._exportGridFour.workbookOptions();
        const optionsGridFive = this._exportGridFive.workbookOptions();
        optionsGridOne.sheets[1] = optionsGridTwo.sheets[0];
        optionsGridOne.sheets[2] = optionsGridThree.sheets[0];
        optionsGridOne.sheets[3] = optionsGridFour.sheets[0];
        optionsGridOne.sheets[4] = optionsGridFive.sheets[0];
        optionsGridOne.sheets[0].title = "By Entity";
        optionsGridOne.sheets[1].title = "By Function";
        optionsGridOne.sheets[2].title = "By KAM";
        optionsGridOne.sheets[3].title = "By DU";
        optionsGridOne.sheets[4].title = "Top 15 Customer";
        this._exportGridOne.save(optionsGridOne);
            } }).catch(err => {
                console.log("error", err)
                this.setState({ isLoading: false })

            });
        
    }
    gridPDFExport;

    anchor = null;
    anchor2 = null;
    // Variable to store template name from local storage
    templateName = JSON.parse(localStorage.getItem('templatename')) === null ? [] : JSON.parse(localStorage.getItem('templatename'));    // Variable to store template state from local storage
    // templateState = JSON.parse(localStorage.getItem('templateState')) === null ? [] : JSON.parse(localStorage.getItem('templateState'));
    constructor(props) {
        super(props); /* Gets Props 'name, input, columns, getData, aggregates, chartData ' */

        const dataState = this.createDataState({
            take: 25,
            skip: 0,
        });

        // this.getData = this.props.getData()

        // Initialize the state of the component
        this.state = {
            path: 'http://inet:81/OIVADashBoard/OIVADashboardOverall',
            data: [],
            data1:[],
            data2:[],
            data3:[],
            data4:[],
            data5:[],
            saveTempInput: {	
                "TemplateName": "",	
                "TemplateJSON": "",	
                "EmpCode": this.props.EmpCode,	
                "CustomerID": "1",	
                "IsForAllUsers": "1",	
                "Notes": "Notes 1"	
            },
            reloadonsavepopup:false,
            setMinWidth: false,
            columns: [...this.props.columns],
            columns1:[...this.props.columns1],
            columns2:[...this.props.columns2],
            columns3:[...this.props.columns3],
            columns4:[...this.props.columns4],
            columns5:[...this.props.columns5],
            exportALL:{
                "FromDate": "2021/04/01 00:00:00",
                "ToDate": "2022/04/01 00:00:00",
                "GroupID": "4",
                "DivisionId": "",
                "KAMHeadID": "",
                "DUHeadID": "",
                "CountryID": "",
                "CustomerID": "",
                "ReportType": "All",
                "RadioValue":"Target"
            },
            gridCurrent: 0,
            isLoading: false,
            showPopupOnRefresh: false,
            showPopupOnSaveTemp: false,
            inputSearchValue: null,
            searchvalue: "",
            newTemplate: null,
            tempCount: this.templateName.length,
            exporting: false,
            filterable: false,
            chartData: [],
            viewChart: false,
            popupChart: false,
            itemPage: 25,
            group: [],
            filter: { logic: "", filters: [] },
            reortered: false,
            afterExportColumn: [...this.props.columns],
            drillDown: false,
            drilldownData: [],
            input: this.props.input,
            navopen: false,
            backfromDrill: [],
            isFromTemp:false,
            MTDplanTotal:0,
            MTDActualTotal:0,
            QTDplanTotal:0,
            QTDActualTotal:0,
            YTDplanTotal:0,
            YTDActualTotal:0,
            aggregates: [...this.props.aggregates],
            ...dataState
        };
    }
    minGridWidth = 0;

    componentDidMount() {
        debugger

        if (this.props.navopen) {
            document.getElementById('grid-container').style.marginLeft = "150px";
            document.getElementById('grid-body').style.marginLeft = "50px";
        }
        let setCol = this.state.columns.find(c => c.field === 'Process')
        // Function to fetch data from api and load it to grid

        if (this.props.isComing === true) {
            this.setState({
                backgrid: this.props.Griddata
            })
            if (this.props.gridsearchValue !== "") {
                // document.getElementById("Searchbox").value=this.props.searchvalue
                this.setState({ searchvalue: this.props.gridsearchValue })
            }
            // products = this.props.Griddata.map((dataItem, idx) => Object.assign({ ID: idx, selected: false }, dataItem))
            this.setState({
                data: this.props.Griddata, columns: this.state.columns, ...this.createDataState({
                    take: this.state.itemPage,
                    skip: 0,
                    group: this.state.group,
                    sort: this.state.sort,
                    filter: this.state.filter
                })
            })
            setTimeout(() => {
                this.props.FalseIsComing()
            }, 400);
        }
        else if (this.props.isDrillchart) {

            let newcol

            if (this.props.Drillchartdata.length > 0) {
                if (this.props.Drillchartdata[0]['Alias'] !== undefined) {
                    newcol = this.state.columns.map(c => {

                        if (c.field === 'Process') {
                            c.title = this.props.Drillchartdata[0]['Alias']
                            return c

                        }

                        return c
                    })
                    this.setState({ columns: newcol })
                }
            }
            products = this.props.Drillchartdata.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
            fixed=products
            this.setState({
                data: products, backgrid: products, columns: this.state.columns, ...this.createDataState({
                    take: this.state.itemPage,
                    skip: 0,
                    group: this.state.group,
                    sort: this.state.sort,
                    filter: this.state.filter
                })
            })

        }
        else if (this.props.isTemplateLoad === true && this.props.isFromGo===false) {	
            debugger	
            let TemplateJSON=JSON.parse(this.props.LoadTemplate.templatejson)	
            // console.log(TemplateJSON)	
            this.setState({ columns:TemplateJSON.columns, filter: TemplateJSON.filter, sort: TemplateJSON.sort, itemPerPage: TemplateJSON.itemPerPage, group: TemplateJSON.group })	
            this.setState({tempName:TemplateJSON.name})	
            this.setState({newTemplate:TemplateJSON.name})
            setTimeout(() => {	
                this.setState({ isLoading: true })	
                GridService.GridData(TemplateJSON.input).then(response => {	
                    let d = response	
                    let data = JSON.parse(d.response)	
                    // console.log(data)	
                    let newcol	
                    if (data.length > 0) {	
                        if (data[0]['Alias'] !== undefined && setCol !== undefined) {	
                            newcol = this.state.columns.map(c => {	
                                if (c.title === "") {	
                                    if (c.field === 'Process') {	
                                        c.title = data[0]['Alias']	
                                        return c	
                                    }	
                                }	
                                return c	
                            })	
                            this.setState({ columns: newcol })	
                        }	
                    }	
                    products = data.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))	
                    fixed=products
                    this.setState({	
                        data: products, backgrid: products, columns: this.state.columns, isLoading: false, ...this.createDataState({	
                            take: this.state.itemPage,	
                            skip: 0,	
                            group: this.state.group,	
                            sort: this.state.sort,	
                            filter: this.state.filter	
                        })	
                    })	
                }).catch(err => {	
                    console.log("error", err)	
                    this.setState({ isLoading: false })	
                });	
            }, 200);	
        }
        else {
            setTimeout(() => {
                this.setState({ isLoading: true })
            }, 200);
            GridService.GridData(this.props.input).then(response => {
                let d = response
                let data = JSON.parse(d.response)
                // console.log(data)
                let newcol

                if (data.length > 0) {
                    if (data[0]['Alias'] !== undefined && setCol !== undefined) {
                        newcol = this.state.columns.map(c => {
                         
                                if (c.field === 'Process') {
                                    c.title = data[0]['Alias']
                                    return c
                                }
                            

                            return c
                        })
                        this.setState({ columns: newcol })
                    }
                }
               
                products = data.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
              fixed=products
                this.setState({
                    data: products, backgrid: products, columns: this.state.columns, isLoading: false, ...this.createDataState({
                        take: this.state.itemPage,
                        skip: 0,
                        group: this.state.group,
                        sort: this.state.sort,
                        filter: this.state.filter
                    })
                })
            }).catch(err => {
                console.log("error", err)
                this.setState({ isLoading: false })

            });


        }

    }



    // Executes every time when a state is created
    createDataState(dataState) {
        debugger
        
        const groups = dataState.group;
        if (groups) { groups.map(group => group.aggregates = this.state.aggregates); }
       const result = process(products.slice(0), dataState);
       products=fixed
        if (groups) {
            let total = result.total, newDataState = dataState, excel, take = dataState.take;
            newDataState.take = total
            newDataState.group = []
            excel = process(products.slice(0), newDataState).data
            tempdata = false
            newDataState.group = groups
            products = excel
            this.setState({ isLoading: false })
            newDataState.take = take
            products=fixed
        }
        return {
            result: result,
            dataState: dataState,
            
        };
    }

    // Executes every time when a state is changed
    dataStateChange = (event) => {
        this.setState(this.createDataState(event.dataState));
    }

    // Executes on the column menu submit
    onColumnsSubmit = (columnsState) => {
        this.setState({
            columns: columnsState
        });
    }

    expandChange = (event) => { // Executes on expand and close of grouped data 
        event.dataItem[event.target.props.expandField] = event.value;
        this.setState({
            result: Object.assign({}, this.state.result),
            dataState: this.state.dataState
        });
    }
    pageChange = (event) => { // Executes on page change in grid
        this.setState({
            skip: event.page.skip,
            take: event.page.take
        });
    }

    searchData = e => { // Function for common search in grid 
        let value = e.target.value;
        this.setState({ searchvalue: e.target.value })
        let field = this.state.columns.map(column => { return { field: column.field, operator: "contains", value: value } })
        let filter = {
            logic: "or",
            filters: field
        };
        products = filterBy(this.state.data, filter)
        this.dataStateChange(this.state)
    };

    filterChange = (event) => { // Function for filter change
        products = filterBy(this.state.data, event.filter)
        this.setState({
            filter: event.filter
        });
        this.dataStateChange(this.state)
        // products=this.state.refreshData
    }

    selectionChange = (event) => { // Executes when select or unselect header select in grid
        const data = this.state.data.map(item => {
            if (item.ID === event.dataItem.ID) {
                item.selected = !event.dataItem.selected;
            }
            return item;
        });
        this.setState({ data });
    }

    headerSelectionChange = (event) => { // Executes when select or unselect a row in grid
        const checked = event.syntheticEvent.target.checked;
        const data = this.state.data.map(item => {
            item.selected = checked;
            return item;
        });
        this.setState({ data });
    }

    cellRender(tdElement, cellProps) {  // This function is used for any changes in the cells in grid

        if (cellProps.dataItem.aggregates !== undefined) {
            let i = 0, key = Object.keys(cellProps.dataItem.aggregates)
            if (cellProps.rowType === 'groupFooter') {
                for (i; i < key.length; i++) {
                    if (cellProps.field === key[i]) {
                        return (
                            <td data-toggle="tooltip" >
                                <b title={"Sum: " + parseFloat(cellProps.dataItem.aggregates[key[i]].sum).toFixed(1)}>Sum: {parseFloat(cellProps.dataItem.aggregates[key[i]].sum).toFixed(1)}</b><br />
                                <b title={"Average: " + parseFloat(cellProps.dataItem.aggregates[key[i]].average).toFixed(1)}> Average: {parseFloat(cellProps.dataItem.aggregates[key[i]].average).toFixed(1)}</b>
                            </td>
                        );
                    }
                }

            }
        }
        if (cellProps.field === "selected") {
            return (tdElement)
        }
        else if (tdElement) {

            if (cellProps.field === "Process") {
                return (<td className="extra" title={tdElement.props.children}>{tdElement.props.children}</td>)
            }
            if (cellProps.field === 'ID') {
                return (<td className="extraID" style={{ textAlign: 'center' }} title={tdElement.props.children}>{tdElement.props.children}</td>)
            }
            if (cellProps.field === 'QTDAchPer') {
                return (<td className="extra-number" style={{ textAlign: 'right' }} title={tdElement.props.children}>{tdElement.props.children}%</td>)
            }
            if (cellProps.field === 'MTDAchPer') {
                return (<td className="extra-number" style={{ textAlign: 'right' }} title={tdElement.props.children}>{tdElement.props.children}%</td>)
            }
            if (cellProps.field === 'YTDAchPer') {
                return (<td className="extra-number" style={{ textAlign: 'right' }} title={tdElement.props.children}>{tdElement.props.children}%</td>)
            }
            else {

                return (<td className="extra-number" style={{ textAlign: 'right' }} title={tdElement.props.children}>{tdElement.props.children}</td>)
            }

        }
        return (tdElement)
    }


    // Function no executes on Refresh no option 
    no = () => { this.setState({ showPopupOnRefresh: !this.state.showPopupOnRefresh, inputSearchValue: null }) }

    // Function yes executes on Refresh yes option 
    yes = () => {
        reordering = false
        this.setState({
            columns: [...this.props.columns],
            data: products,
            setMinWidth: false,
            gridCurrent: 0,
            filter: undefined,
            showPopupOnRefresh: false,
            initTemp: null,
            inputSearchValue: null,
            searchvalue: "",
            sort: [],
            itemPage: 25,
            group: [],
            filterable: false
        })
        this.componentDidMount();
        this.dataStateChange(this.state)

    }
    backdrill = () => {
        debugger
        this.props.isDrill(false)
        products = this.state.backfromDrill
        setTimeout(() => {
            this.setState({ drillDown: false })
        }, 100);
        setTimeout(() => {
            this.setState({ isLoading: false })
        }, 200);
    }
    // Function executes on Refresh
    onRefresh = () => {
        this.setState({ showPopupOnRefresh: !this.state.showPopupOnRefresh, inputSearchValue: "" });
    }

    // Function executes onClick Save Template Button
    onSaveTemplate = () => {
        this.setState({ showPopupOnSaveTemp: !this.state.showPopupOnSaveTemp});
    }
	dontReload=()=>{	
        this.setState({reloadonsavepopup:false})	
    }	
    Reload=()=>{	
        this.setState({reloadonsavepopup:false})	
        window.location.reload()	
    }
    // Function executes onClick on popup Save Template, Save Button
    saveTemplate = () => {	
        debugger	
       this.setState({ isLoading: true})	
        let finalColumn = []	
        let tempState = {}	
        let pushValue = this.state.newTemplate	
        let existing 
        if(this.props.isTemplateLoad){
            if(pushValue===this.state.tempName){
            existing =-1
            }
            else{
                existing =this.templateName.findIndex(element => element === pushValue)
            }
        }
        else{
        existing =this.templateName.findIndex(element => element === pushValue)	

        }
        let column = JSON.parse(JSON.stringify(this.state.columns))	
        if (existing === -1) {	
       	
        if (reordering) {	
            let gridOrder = this.grid.columns;	
            column = []	
            gridOrder.map(data => {	
                if (data.field !== "selected") {	
                    column[data.orderIndex - 1] = this.state.columns.find(d => d.field === data.field)	
                }	
                return null	
            })	
            let hideColumn = this.state.columns.filter(d => d.show === false)	
            finalColumn.push(...hideColumn)	
            finalColumn.push(...column)	
            reordering = false	
            tempState = {	
                name: pushValue,	
                columns: finalColumn,	
                itemPerPage: this.state.dataState.take,	
                group: this.state.dataState.group.map(group => { return { field: group.field, dir: group.dir } }),	
                sort: this.state.sort,	
                filter: this.state.filter,	
                input: this.props.input,	
                DUDescription:this.props.DUDescription===undefined?[]:this.props.DUDescription,	
                KAMHeadDescription:this.props.KAMHeadDescription===undefined?[]:this.props.KAMHeadDescription,	
                DUHeadDescription:this.props.DUHeadDescription===undefined?[]:this.props.DUHeadDescription,	
                CustomerDescription:this.props.CustomerDescription===undefined?[]:this.props.CustomerDescription,	
                CountryDescription:this.props.CountryDescription===undefined?[]:this.props.CountryDescription,	
                ReportTypeDescription:this.props.ReportTypeDescription===undefined? this.props.IsKAM === true || this.props.IsKAMHead === true ? ["By Function"]: ["By KAM"]:this.props.ReportTypeDescription	
            }	
        }	
        else {	
            tempState = {	
                name: pushValue,	
                columns: column,	
                itemPerPage: this.state.dataState.take,	
                group: this.state.dataState.group.map(group => { return { field: group.field, dir: group.dir } }),	
                sort: this.state.sort,	
                filter: this.state.filter,	
                input: this.props.input,	
                DUDescription:this.props.DUDescription===undefined?[]:this.props.DUDescription,	
                KAMHeadDescription:this.props.KAMHeadDescription===undefined?[]:this.props.KAMHeadDescription,	
                DUHeadDescription:this.props.DUHeadDescription===undefined?[]:this.props.DUHeadDescription,	
                CustomerDescription:this.props.CustomerDescription===undefined?[]:this.props.CustomerDescription,	
                CountryDescription:this.props.CountryDescription===undefined?[]:this.props.CountryDescription,	
                ReportTypeDescription:this.props.ReportTypeDescription===undefined? this.props.IsKAM === true || this.props.IsKAMHead === true ? ["By Function"]: ["By KAM"]:this.props.ReportTypeDescription	
            }	
        }	
        setTimeout(() => {	
            GridService.Savetemplate({	
                "TemplateName":pushValue ,	
                "TemplateJSON": JSON.stringify(tempState),	
                "EmpCode": this.props.EmpCode,	
                "CustomerID": "1",	
                "IsForAllUsers": "1",	
                "Notes": "Notes 1"	
            }).then(response => {	
                let d = response.response	
                	
          if(d==="1 rows were affected."){	
            this.setState({ newTemplate: "", showPopupOnSaveTemp: false })	
            this.setState({ isLoading: false})	
          setTimeout(() => {	
            this.templateName.push(pushValue);	
            this.setState({reloadonsavepopup:true})	
            localStorage.setItem("templatename",JSON.stringify(this.templateName))	
        	
          }, 100);  	
           	
          }	
     	
            }).catch(err => {	
                console.log("error", err)	
                this.setState({ isLoading: false})	
            });	
        }, 200);	
        } else {	
            	
            alert("A Template Already Exist in the name " + pushValue)	
            if(this.props.isTemplateLoad===true){
                this.setState({ isLoading:false, showPopupOnSaveTemp: false })	
            }
            else{
                this.setState({ isLoading:false, newTemplate: "", showPopupOnSaveTemp: false })	
            }
           
        }	
    }	

    // Function executes onClick on popup Save Template, Cancel Button
    dontSaveTemplate = () =>{
        if(this.props.isTemplateLoad===true){
            this.setState({ newTemplate: this.state.tempName, showPopupOnSaveTemp: false })	
        }
        else{
            this.setState({  newTemplate: "", showPopupOnSaveTemp: false })	
        }
    }

    tempChange = (event) => { // Executes when a template is selected from dropdown
        if (event.target.value !== null) {
            let newState = this.templateState.find(data => data.name === event.target.value)
            this.setState({ isLoading: true, Loadtemp: true, columns: newState.columns,input:newState.input, filter: newState.filter, sort: newState.sort, initTemp: event.target.value, itemPage: newState.itemPerPage, group: newState.group,isFromTemp:true })
            tempdata = true
           setTimeout(() => {
            this.componentDidMount()
           }, 200); 
        }
        else this.setState({ initTemp: null })
    }

    sortChange = (event) => { // Function for sorting in grid
        this.setState({
            data: this.getProducts(event.sort),
            sort: event.sort
        });
        products = this.getProducts(event.sort)
        this.dataStateChange(this.state)

    }

    getProducts = (sort) => {
        return orderBy(products, sort);
    }

    changeStuff(val, idx) { // Funtion to save edited column header changes from child component to state of parent component
        let editColumn = JSON.parse(JSON.stringify(this.state.columns));
        editColumn[idx].title = val
        this.setState({ columns: editColumn });
    }

    loadingPanel = ( /* Code for showing loading symbol */
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );
    
    Total = props => {
   
        let value ;
        const field = props.field || '';
        let count = products.length
        const total = products.reduce((acc, current) => {
            return acc + parseFloat(current[field])
        }, 0);
        value = parseFloat(total).toFixed(1)
 
        if(field==="QTDVar"){
            let qtdplan=products.reduce((acc, current) => {
               return acc + parseFloat(current["QTDPlan"])
           }, 0);
           let qtdactual=products.reduce((acc, current) => {
               return acc + parseFloat(current["QTDActual"])
           }, 0);
       let value=qtdactual-qtdplan
       let val= parseFloat(value).toFixed(1)
   
       return (<td colSpan={props.colSpan} style={props.style} title={"Total:" + val}>Total: {val}</td> )
               
   
   }
   if(field==="MTDVar"){
       let mtdplan=products.reduce((acc, current) => {
          return acc + parseFloat(current["MTDPlan"])
      }, 0);
      let mtdactual=products.reduce((acc, current) => {
          return acc + parseFloat(current["MTDActual"])
      }, 0);
   let value=mtdactual-mtdplan
   let val= parseFloat(value).toFixed(1)
   
   return (<td colSpan={props.colSpan} style={props.style} title={"Total:" + val}>Total: {val}</td> )
          
   
   }
   if(field==="YTDVar"){
       let ytdplan=products.reduce((acc, current) => {
          return acc + parseFloat(current["YTDPlan"])
      }, 0);
      let ytdactual=products.reduce((acc, current) => {
          return acc + parseFloat(current["YTDActual"])
      }, 0);
   let value=ytdactual-ytdplan
   let val= parseFloat(value).toFixed(1)
   
   return (<td colSpan={props.colSpan} style={props.style} title={"Total:" + val}>Total: {val} </td> )
          
   
   }         
        
       
       

     if(field==="QTDAchPer"){
         let qtdplan=products.reduce((acc, current) => {
            return acc + parseFloat(current["QTDPlan"])
        }, 0);
        let qtdactual=products.reduce((acc, current) => {
            return acc + parseFloat(current["QTDActual"])
        }, 0);
    let value=(qtdactual/qtdplan)*100
    let val= parseFloat(value).toFixed(1)
    if(val !== "NaN" && val !== "Infinity"){
        return(<td colSpan={props.colSpan} style={props.style} title={"Total:" + val}>Total: {val}% </td> )
    }  
    else{
        return(<td colSpan={props.colSpan} style={props.style} title={"Total:0.0%"}>Total:0.0%</td>)
    }
  

}
if(field==="MTDAchPer"){
    let mtdplan=products.reduce((acc, current) => {
       return acc + parseFloat(current["MTDPlan"])
   }, 0);
   let mtdactual=products.reduce((acc, current) => {
       return acc + parseFloat(current["MTDActual"])
   }, 0);
let value=(mtdactual/mtdplan)*100
let val= parseFloat(value).toFixed(1)
if(val !== "NaN" && val !== "Infinity" ){
return(<td colSpan={props.colSpan} style={props.style} title={"Total:" + val}>Total: {val}% </td>)
}
 else{
    return(<td colSpan={props.colSpan} style={props.style} title={"Total:0.0%"}>Total:0.0%</td>)
 }

       

}
if(field==="YTDAchPer"){
    let ytdplan=products.reduce((acc, current) => {
       return acc + parseFloat(current["YTDPlan"])
   }, 0);
   let ytdactual=products.reduce((acc, current) => {
       return acc + parseFloat(current["YTDActual"])
   }, 0);
let value=(ytdactual/ytdplan)*100
let val= parseFloat(value).toFixed(1)
if(val !== "NaN" && val !== "Infinity" ){
    return(<td colSpan={props.colSpan} style={props.style} title={"Total:" + val}>Total: {val}% </td> )
}
else{
    return(<td colSpan={props.colSpan} style={props.style} title={"Total:0.0%"}>Total:0.0%</td>)
}

if(val !== "NaN" && val !== "Infinity"){	
    return(<td colSpan={props.colSpan} style={props.style} title={"Total:" + val}>Total: {val}% </td> )	
}  	
else{	
    return(<td colSpan={props.colSpan} style={props.style} title={"Total:0.00%"}>Total:0.00%</td>)	
}	


}

else{
  
    return value !== 'NaN' ?
    <td colSpan={props.colSpan} style={props.style} title={"Total:" + value}>Total: {value} </td> :
    <td colSpan={props.colSpan} style={props.style} title={"Count:" + count}>Count: {count}</td>
}
       
       
    };

    reorder = () => { // This function is used to save the reordered column in that order to state columns 
        debugger

        let gridOrder = this.grid.columns, column = [], finalColumn = [], col = JSON.parse(JSON.stringify(this.state.columns))
        gridOrder.map(data => {
            if (data.field !== "selected") {
                column[data.orderIndex - 1] = this.state.columns.find(d => d.field === data.field)
            }
            return null
        })
        let hideColumn = this.state.columns.filter(d => d.show === false)
        finalColumn.push(...hideColumn)
        finalColumn.push(...column)
        this.setState({ columns: finalColumn, afterExportColumn: col })
        reordering = false
        // return column

    }

    handleChange = e => {
        const fileReader = new FileReader();
        fileReader.readAsText(e.target.files[0], "UTF-8");
        fileReader.onload = e1 => {
            let newState = JSON.parse(e1.target.result)
            let oldcolumn = this.state.columns.map((d => d.field))
            let importcolumn = newState.columns.map((d => d.field))
            let l = oldcolumn.sort().join(',')
            let m = importcolumn.sort().join(',')
            if (l === m) {
                if (newState.columns !== undefined) {
                    let pushValue = newState.name
                    let existing = this.templateName.findIndex(element => element === pushValue)
                    if (existing === -1) {
                        this.templateName.push(pushValue)
                        localStorage.setItem('templateName', JSON.stringify(this.templateName));
                        this.templateState.push(newState)
                        localStorage.setItem('templateState', JSON.stringify(this.templateState));
                    }
                    this.setState({ isLoading: true, columns: newState.columns, filter: newState.filter, sort: newState.sort, initTemp: newState.name, itemPage: newState.itemPerPage, group: newState.group })
                    tempdata = true
                    this.componentDidMount()
                }
                else {
                    alert("Select a valid template json file")
                }
            }
            else alert("Select a valid template json file")
        };
    };
    drillData = (name) => {
        debugger
        GridService.getGridData(

            {
                "MasterType": "Function",

            },
            'Function'
        ).then(response => {
            let d = response
            let data = JSON.parse(d.response);
            data.map((dataitem, id) => {
                if (dataitem.Process === name) {
                    let input = JSON.parse(JSON.stringify(this.props.input))
                    input["DivisionId"] = `(${dataitem.Condition})`
                    input["ReportType"] = "Division"
                    this.props.isDrill(true)
                    this.setState({ drilldownData: name, input: input })
                    this.setState({ drillDown: true })
                }

                return null
            })
        }).catch(err => {
            console.log("error", err)
        });
    }
    deleteTemplate=()=>{	
        debugger	
        GridService.DeleteTemplate({	
            "EmpCode":this.props.EmpCode,	
            "CustomerID":"1",	
            "TemplateName":this.state.tempName	
        }).then(response => {	
            let d = response	
            
        if(d.response==="Deleted Successfully"){	
            this.templateName = this.templateName.filter(e => e !== this.state.tempName)	
           setTimeout(() => {	
            localStorage.setItem("templatename",JSON.stringify(this.templateName))	
            this.props.LoadDefaultTemplate( ) 	
           }, 100); 	
        }	
        else{	
            this.props.LoadDefaultTemplate()	
        }	
         
            
        }).catch(err => {	
            console.log("error", err)	
        });	
            
    }
    render() {
        const grid = (
            //Telerik Grid Component
            <Grid
                // style={{ height: '400px'}}
                data={this.state.result}
                {...this.state.dataState}
                onDataStateChange={this.dataStateChange}
                sortable={{ mode: "multiple" }}
                sort={this.state.sort}
                onSortChange={this.sortChange}
                total={this.state.data.length}
                pageable={{ pageSizes: [5, 10, 20, 25] }}
              
                resizable={true}
                groupable={{ footer: 'visible' }}
                reorderable={true}
                filterable={true}
                filter={this.state.filter}
                onFilterChange={this.filterChange}
                expandField="expanded"
                onExpandChange={this.expandChange}
                selectedField={this.state.columns.length > 1 ? 'selected' : ''}
                onSelectionChange={this.selectionChange}
                onHeaderSelectionChange={this.headerSelectionChange}
                cellRender={this.cellRender}
                ref={(g) => { this.grid = g; }}
                onColumnReorder={() => reordering = true}
                onRowDoubleClick={(e) => {
                    // console.log(e.dataItem)

                    if (this.props.input["ReportType"] === "Top 15 Customers" && e.dataItem.Process !== "Others") {
                        // console.log(e.dataItem)
                        this.setState({ backfromDrill: this.state.data })
                        this.props.CustomerFilterData.map((data) => {

                            if (data.Descriptions === e.dataItem.Process) {
                                let input = JSON.parse(JSON.stringify(this.props.input))
                                input["CustomerID"] = `${data.ID}`
                                input["ReportType"] = "Division"
                                // console.log(data.ID,"please")
                                this.setState({ drilldownData: data.Descriptions, input: input })
                                this.setState({ drillDown: true })
                                this.props.isDrill(true)
                            }
                           
                           
                        })
                    }
                  else if (this.props.input["ReportType"] === "Top 15 Customers" && e.dataItem.Process === "Others") {
                        // console.log(e.dataItem)
                        debugger
                        this.setState({ backfromDrill: this.state.data })
                        let input = JSON.parse(JSON.stringify(this.props.input)) ,index, CustomerID = [], Id;
                        this.props.CustomerFilterData.map((data) => {

                            if (data.Descriptions !=="Pearson" && data.Descriptions !=="Taylor and Francis" && data.Descriptions !=="Cambridge University Press" && data.Descriptions !=="	Bloomsbury PLC" && data.Descriptions !=="John Wiley and Sons" && data.Descriptions !=="De Gruyter" && data.Descriptions !=="Infinitas Learning" && data.Descriptions !=="OUP" && data.Descriptions !=="IOP Publishing"  && data.Descriptions !=="Wolters Kluwer" && data.Descriptions !=="Cengage Learning" && data.Descriptions !=="Hodder Education" && data.Descriptions !=="ICL - Institute for Community Living" && data.Descriptions !=="ASQ" && data.Descriptions !=="SAGE publishing" ) {
                                index = this.props.Customer['Descriptions'].indexOf(data.Descriptions)
                                Id = this.props.Customer['ID'][index]
                                CustomerID.push(Id)
                               
                             
                                // console.log(data.ID,"please")
                             
                            }
                           
                           
                        })
                        input["CustomerID"] = `(${CustomerID})`
                        input["ReportType"] = "Division"
                        this.setState({ drilldownData:"Other Customers", input: input })
                        this.setState({ drillDown: true })
                        this.props.isDrill(true)
                    }

                   else if (this.props.input["ReportType"] === "By Function") {
                        // console.log(e.dataItem)


                        this.setState({ backfromDrill: this.state.data })
                        setTimeout(() => {

                            this.drillData(e.dataItem.Process)
                            this.setState({ isLoading: true })
                        }, 100)
                    }
                    // if(e.dataItem.Customer === "Sagayaraj" || e.dataItem.Process === "UK" || e.dataItem.Process === "US"){
                    //     let dillType={
                    //         "Sagayaraj" : "Sagayaraj",
                    //         "UK" : "Integra UK",
                    //         "US" :  "Integra US"
                    //     }
                    //     let input= JSON.parse(JSON.stringify(this.props.input))
                    //     input["ReportType"]=dillType[e.dataItem.Process]
                    //     this.setState({drillDown: true,drilldownData:dillType[e.dataItem.Process] , input: input})
                    // }
                }}
            >
                <GridToolbar>

                    {/* Button to Export Excel */}
                    <Button
                        // primary={true}
                        title="Export Excel"
                        onClick={this.export}
                    >
                        Export to Excel
                    </Button>
                    <Button
                        // primary={true}
                        title="Export Excel"
                        onClick={this.exportAll}
                    >
                        Export All as Excel
                    </Button>
                    {/* Button to show popup for save template */}
                    <button className="k-button"
                        onClick={this.onSaveTemplate}
                        title="Save Template"
                        ref={(button) => {
                            this.anchor2 = button;

                        }}>

                        Save Template</button>
                        {	
                            this.state.reloadonsavepopup &&	(
                            <Dialog title={"Save Template"} onClose={this.dontReload}>	
            <p	
                style={{	
                    margin: "25px",	
                    textAlign: "center",	
                }}	
            >	
                Template Saved Successfully,On Clicking OK the page will be reloaded and currently saved template will be available on side menu	
            </p>	
            <DialogActionsBar>	
                {/* Button to close template save popup*/}	
                {/* <button className="k-button" onClick={this.dontReload}>	
                    Cancel	
                </button>	 */}
                {/* Button to save new template */}	
                <button className="k-button" onClick={this.Reload} >	
                    OK	
                </button>	
            </DialogActionsBar>	
        </Dialog>)	
                        }

                    {/* Popup for save template */}
                    {this.state.showPopupOnSaveTemp && (
                        <Dialog title={"Save Template"} onClose={this.dontSaveTemplate}>
                            <p
                                style={{
                                    margin: "25px",
                                    textAlign: "center",
                                }}
                            >
                                <label>Template Name : </label>
                                {/* Input tag for getting template name to be saved */}
                                <Input value={this.state.newTemplate} maxLength="256" onChange={(e) => this.setState({ newTemplate: e.value })} />
                            </p>
                            <div className="col-md-12"  style={{
                                 
                                    marginLeft: "30px",
                                }}>
                            <input
                            className="k-checkbox"
                            // defaultChecked={false}
                            checked={true}
                            id="previousNext"
                            type="checkbox"
                            // onChange={e => { this.setState({ filterable: !this.state.filterable }); }}
                        />
                        <label
                            htmlFor="previousNext"
                            className="k-checkbox-label"
                        >
                            For all Users
                                </label>
                                </div>
                            <DialogActionsBar>
                                {/* Button to close template save popup*/}
                                <button className="k-button" onClick={this.dontSaveTemplate}>
                                    Cancel
                                    </button>
                                {/* Button to save new template */}
                                <button className="k-button" onClick={this.saveTemplate} disabled={!this.state.newTemplate}>
                                    Save
                                    </button>
                            </DialogActionsBar>
                        </Dialog>
                    )}

                    {/* Dropdown to show list of available templates */}
                    {/* {localStorage.getItem('templateState') === null ? <div /> : <b style={{ fontWeight: "unset" }} title="Select Template"><ComboBox
                        style={{ width: "220px" }}
                        data={this.templateName}
                        value={this.state.initTemp}
                        onChange={this.tempChange}
                        placeholder="Template" /></b>
                    } */}

                    {/* Checkbox to enable / disable filter in grid */}
                        <input
                            className="k-checkbox"
                            // defaultChecked={false}
                            checked={this.state.filterable}
                            id="previousNext"
                            type="checkbox"
                            onChange={e => { this.setState({ filterable: !this.state.filterable }); }}
                        />
                        <label
                            htmlFor="previousNext"
                            className="k-checkbox-label"
                        >
                            Enable Filter
                                </label>

                    {/* Input field for Search within grid */}
                    <Input style={{ marginLeft: 20 }} maxLength="256" title='Search' type='search' onChange={this.searchData} placeholder={'Search'} value={this.state.searchvalue} />

                    {/* Button to switch from grid component to chart component */}

                    <Button
                        // primary={true}
                        title="View as Chart"
                        onClick={() => {
                            let columnName = this.state.columns.filter(col => col.show === true), mapData
                            let selectData = this.state.data.filter((item) => item.selected === true)
                            if (selectData.length > 0) mapData = selectData;
                            else mapData = products
                            let sendData = mapData.map(data => {
                                let newObject = {}
                                columnName.map(col => newObject[col.field] = data[col.field])
                                return newObject
                            })
                            
                            this.setState({ chartData: sendData, viewChart: true })
                            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                                this.setState({ navopen: true })
                            }
                            else {
                                this.setState({ navopen: false })
                            }
                            if (this.props.isDrillchart) {
                                setTimeout(() => {
                                    this.props.chartData(this.state.navopen, sendData, this.state.backgrid, this.state.searchvalue)
                                }, 100);
                            }
                            else {
                                setTimeout(() => {
                                    this.props.chartData(this.state.navopen, sendData, this.state.backgrid, this.state.searchvalue)
                                }, 100);
                            }



                        }}
                    >
                        View as Chart
                            </Button>
                            {this.props.isTemplateLoad === true && this.props.isFromGo===false&&(<Button onClick={() => {this.deleteTemplate() }} title='Delete Selected Template'>Delete Selected Template</Button>)}
                    {/* <Button onClick={() => { this.upload.click() }} title='Choose a template json file from downloads,On importing it will automatically added to local storage'>Import Template File</Button>
                    <input ref={(ref) => this.upload = ref} type="file" accept=".json" id="getFile" onChange={this.handleChange} style={{ width: "90px", display: "none" }} /> */}
                    {/* Refresh icon to show popup for refresh */}
                    <ul><li title="Refresh" style={{ marginLeft: "-30px" }} ref={(li) => this.anchor = li} onClick={this.onRefresh}><BiIcons.BiRefresh color='#042e68' size='2em' /></li></ul>

                    {/* Popup for refresh grid */}
                    {this.state.showPopupOnRefresh && (
                        <Dialog title={"Please confirm"} onClose={this.no}>
                            <p
                                style={{
                                    margin: "25px",
                                    textAlign: "center",
                                }}
                            >
                                By refreshing, Filter and Search data will be cleared out. Are you sure want to continue?
                                </p>
                            <DialogActionsBar>

                                {/* Button to close and cancel refresh  */}
                                <button className="k-button" onClick={this.no}>
                                    No
                                    </button>

                                {/* Button to refresh grid */}
                                <button className="k-button" onClick={this.yes}>
                                    Yes
                                    </button>
                            </DialogActionsBar>
                        </Dialog>
                    )}

                </GridToolbar>

                {/* Column for MultiSelect rows */}
                {this.state.columns.length > 0 && (<GridColumn
                    field="selected"
                    width="30px"
                    filterable={false}
                    hidden={true}
                    headerSelectionValue={
                        this.state.data.findIndex(dataItem => dataItem.selected === false) === -1
                    } />)}

                {/* Code to show specific columns */}

                {
                    this.state.columns.map((column, idx) =>
                        column.show && (

                            this.props.IsKAM === false && this.props.IsKAMHead === false ?
                                <GridColumn
                                    key={idx}
                                    field={column.field}
                                    format={column.format}
                                    title={column.title}
                                    filter={column.filter}
                                    filterable={this.state.filterable}
                                    width={column.minWidnt}
                                    footerCell={this.Total}
                                    headerCell={ // Grid props to do changes in column header
                                        props =>

                                            <Header
                                                {...props}
                                                idx={idx}
                                                minwidth={column.minWidnt}
                                                changeHandler={this.changeStuff.bind(this)}
                                            />
                                    }
                                    columnMenu={ // Grid props for column menu
                                        props =>
                                            <CustomColumnMenu
                                                {...props}
                                                columns={this.state.columns}
                                                products={this.state.data}
                                                onColumnsSubmit={this.onColumnsSubmit}
                                                filterable={this.state.filterable}
                                            />
                                    }
                                /> : <GridColumn
                                    key={idx}
                                    field={column.field}
                                    format={column.format}
                                    title={column.title}
                                    filter={column.filter}
                                    filterable={this.state.filterable}
                                    width={column.minWidnt}
                                    footerCell={this.Total}
                                    columnMenu={ // Grid props for column menu
                                        props =>
                                            <CustomColumnMenu
                                                {...props}
                                                columns={this.state.columns}
                                                products={this.state.data}
                                                onColumnsSubmit={this.onColumnsSubmit}
                                                filterable={this.state.filterable}
                                            />
                                    }
                                />
                        )
                    )
                }

            </Grid>
        )

        return (
            !this.state.drillDown ? <div className='move-grid-body' id="grid-body"> {/* To show normal grid */}
                {(this.state.isLoading) && (this.loadingPanel)}

                <ExcelExport // Telerik ExcelExport compnent to export grid data
                    fileName="OIReport"
                    data={
                        this.state.data.filter((item) => item.selected === true).length > 0 ?
                            this.state.data.filter((item) => item.selected === true) : products
                    }
                    ref={exporter => this._export = exporter}
                >
                    {grid}

                </ExcelExport>
                <ExcelExport
          data={this.state.data1}
          ref={(exporter) => {
            this._exportGridOne = exporter;
          }}
        >
          <Grid data={this.state.data1} style={{ height: "490px",display:'none' }}>
           {this.state.columns1?
                 this.state.columns1.map(column=><GridColumn field={column.field} title={column.title} width={column.width} />)
                   :null}
          
          </Grid>
        </ExcelExport>
        <ExcelExport
          data={this.state.data2}
          ref={(exporter) => {
            this._exportGridTwo = exporter;
          }}
        >
          <Grid data={this.state.data2} style={{ height: "490px",display:'none' }}>
           {this.state.columns2?
                 this.state.columns2.map(column=><GridColumn field={column.field} title={column.title} width={column.width} />)
                   :null}
          
          </Grid>
        </ExcelExport>
        <ExcelExport
          data={this.state.data3}
          ref={(exporter) => {
            this._exportGridThree = exporter;
          }}
        >
          <Grid data={this.state.data3} style={{ height: "490px",display:'none' }}>
           {this.state.columns3?
                 this.state.columns3.map(column=><GridColumn field={column.field} title={column.title} width={column.width} />)
                   :null}
          
          </Grid>
        </ExcelExport>
        <ExcelExport
          data={this.state.data4}
          ref={(exporter) => {
            this._exportGridFour = exporter;
          }}
        >
          <Grid data={this.state.data4} style={{ height: "490px",display:'none' }}>
           {this.state.columns4?
                 this.state.columns4.map(column=><GridColumn field={column.field} title={column.title} width={column.width} />)
                   :null}
          
          </Grid>
        </ExcelExport>
        <ExcelExport
          data={this.state.data5}
          ref={(exporter) => {
            this._exportGridFive = exporter;
          }}
        >
          <Grid data={this.state.data5} style={{ height: "490px",display:'none' }}>
              
           {
    
           this.state.columns5?
                 this.state.columns5.map(column=><GridColumn field={column.field} title={column.title} width={column.width} />)
                   :null}
          
         
          </Grid>
        </ExcelExport>
        

                <br />
            </div> : <div> {/* To show drilldown grid */}
                    {this.state.viewChart === false ? <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backdrill}>Go Back</Button> : null} {/* To go back to normal grid */}
                    <DrillDown column1={this.state.columns1}column2={this.state.columns2}column3={this.state.columns3}column4={this.state.columns4}column5={this.state.columns5}data={this.state.drilldownData} CustomerFilterData={this.props.CustomerFilterData} Customer={this.props.Customer}input={this.state.input} IsKAM={this.props.IsKAM} IsKAMHead={this.props.IsKAMHead} gridsearchValue={this.state.searchvalue} />
                </div>
        );
    }
}
