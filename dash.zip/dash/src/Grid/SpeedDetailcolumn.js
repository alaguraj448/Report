export const speedDetail_column = [
    {
        field: "OFFICE_GROUP",
        title: "OFFICE GROUP",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "VOLUME_YEAR",
        title: "VOLUME YEAR",
        minWidnt: 205,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "OFFICE",
        title: "OFFICE",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "HOST_AREA",
        title: "HOST AREA",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PM",
        title: "PM",
        minWidnt: 195,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "SUP",
        title: "SUP",
        minWidnt: 195,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PE",
        title: "PE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "ACRONYM",
        title: "ACRONYM",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "MS_WORKFLOW",
        title: "MS WORKFLOW",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "MS_PROFILE",
        title: "MS PROFILE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "IFIRST_YN",
        title: "IFIRST_YN",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "ON_SAM_YN",
        title: "ON_SAM_YN",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "COPEDIT_BY_TS_YN",
        title: "COPEDIT_BY_TS_YN",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "MANUSCRIPT_ID",
        title: "MANUSCRIPT_ID",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_RECEIPT_TO_ACCEPT",
        title: "DAYS_FROM_RECEIPT_TO_ACCEPT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ACCEPTANCE_TO_ENTRY",
        title: "DAYS_FROM_ACCEPTANCE_TO_ENTRY",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ENTRY_TO_NXT",
        title: "DAYS_FROM_ENTRY_TO_NXT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ENTRY_TO_TAG",
        title: "DAYS_FROM_ENTRY_TO_TAG",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FOR_TAG",
        title: "DAYS_FOR_TAG",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_TAG_TO_CE",
        title: "DAYS_FROM_TAG_TO_CE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_TAG_TO_INIT_TS",
        title: "DAYS_FROM_TAG_TO_INIT_TS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ENTRY_TO_INIT_TS",
        title: "DAYS_FROM_ENTRY_TO_INIT_TS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_CE_TO_INIT_TS",
        title: "DAYS_FROM_CE_TO_INIT_TS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FOR_INIT_TS",
        title: "DAYS_FOR_INIT_TS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },{
        field: "DAYS_FROM_INIT_TS_TO_PROOFS",
        title: "DAYS_FROM_INIT_TS_TO_PROOFS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FOR_AUTH_PROOFING",
        title: "DAYS_FOR_AUTH_PROOFING",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FOR_AE_PROOFING",
        title: "DAYS_FOR_AE_PROOFING",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_FINAL_PRFS_BK_TO_NXT",
        title: "DAYS_FROM_FINAL_PRFS_BK_TO_NXT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_PROOFS_BACK_TO_TFO",
        title: "DAYS_FROM_PROOFS_BACK_TO_TFO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_FNL_RPRFS_BK_TO_NXT",
        title: "DAYS_FROM_FNL_RPRFS_BK_TO_NXT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_REV_FILE_TO_FINAL",
        title: "DAYS_FROM_REV_FILE_TO_FINAL",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_FF_REC_TO_OA_APPRV",
        title: "DAYS_FROM_FF_REC_TO_OA_APPRV",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_OA_APPRV_TO_TFO",
        title: "DAYS_FROM_OA_APPRV_TO_TFO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_OA_APPRV_TO_PUB",
        title: "DAYS_FROM_OA_APPRV_TO_PUB",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_TO_TFO_TO_PUB",
        title: "DAYS_FROM_TO_TFO_TO_PUB",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_RECEIPT_TO_AMO",
        title: "DAYS_FROM_RECEIPT_TO_AMO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_RECEIPT_TO_PUB",
        title: "DAYS_FROM_RECEIPT_TO_PUB",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ACCEPTANCE_TO_AMO",
        title: "DAYS_FROM_ACCEPTANCE_TO_AMO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ACCEPTANCE_TO_PUB",
        title: "DAYS_FROM_ACCEPTANCE_TO_PUB",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ENTRY_TO_AMO",
        title: "DAYS_FROM_ENTRY_TO_AMO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ENTRY_TO_OA_APPRV",
        title: "DAYS_FROM_ENTRY_TO_OA_APPRV",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "DAYS_FROM_ENTRY_TO_PUB",
        title: "DAYS_FROM_ENTRY_TO_PUB",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "RECEIVED_DATE",
        title: "RECEIVED_DATE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "ACCEPTED_DATE",
        title: "ACCEPTED_DATE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "ENTERED_DATE",
        title: "ENTERED_DATE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "TO_TAG",
        title: "TO_TAG",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "FROM_TAG",
        title: "FROM_TAG",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "TRANSFER_TO_TFO_AMO",
        title: "TRANSFER_TO_TFO_AMO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "PUBLISHED_ON_AMO",
        title: "PUBLISHED_ON_AMO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "TO_CE",
        title: "TO_CE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "FROM_CE",
        title: "FROM_CE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "TO_INIT",
        title: "TO_INIT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "FROM_INIT",
        title: "FROM_INIT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "TO_PROOFS",
        title: "TO_PROOFS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "FROM_AUTH_PROOFS",
        title: "FROM_AUTH_PROOFS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "FROM_AE_PROOFS",
        title: "FROM_AE_PROOFS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    }
   ,
	{
        field: "TO_MARKED_PAGES",
        title: "TO_MARKED_PAGES",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "FROM_MARKED_PAGES",
        title: "FROM_MARKED_PAGES",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "TO_REV_PROOFS",
        title: "TO_REV_PROOFS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "FROM_AUTH_REV_PROOFS",
        title: "FROM_AUTH_REV_PROOFS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "FROM_AE_REV_PROOFS",
        title: "FROM_AE_REV_PROOFS",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "TO_QC",
        title: "TO_QC",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "ONLINE_FF_REC",
        title: "ONLINE_FF_REC",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "ONLINE_ADVANCES",
        title: "ONLINE_ADVANCES",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "TRANSFER_TO_TFO",
        title: "TRANSFER_TO_TFO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "PUBLISHED_ON_TFO",
        title: "PUBLISHED_ON_TFO",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "MS_TYPE",
        title: "MS_TYPE",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "ON_HOLD_TIME",
        title: "ON_HOLD_TIME",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "VOLUME_NUMBER",
        title: "VOLUME_NUMBER",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "ISSUE_NUMBER",
        title: "ISSUE_NUMBER",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
	{
        field: "ISSUE_WORKFLOW",
        title: "ISSUE_WORKFLOW",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    }
   
 
]