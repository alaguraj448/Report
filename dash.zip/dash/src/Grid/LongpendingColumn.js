export const longPending_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    
    {
        field: "Ageing",
        title: "Delay in Days",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"Stage"
    },
  
    {
        field: "BuildOnline",
        title: "Build Online",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"StageGroup"
    }
    ,
  
    {
        field: "ELDs",
        title: "ELDs",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"StageGroup"
    },
  
    {
        field: "FirstPassXML",
        title: "First Pass XML",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"StageGroup"
    },
  
    {
        field: "FirstProof",
        title: "First Proof",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"StageGroup"
    },
  
    {
        field: "PreEditing",
        title: "Pre-Editing",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"StageGroup"
    },
  
    {
        field: "Preview",
        title: "Preview",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"StageGroup"
    },
  
    {
        field: "Revises",
        title: "Revises",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"StageGroup"
    },
  
    {
        field: "Entry",
        title: "Entry",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:"StageGroup"
    }, {
        field: "Total",
        title: "Total",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: "",
        Type:""
    }
    
]