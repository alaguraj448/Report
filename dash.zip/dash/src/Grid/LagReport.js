import React from "react";
import ChartContainer from './OTDChart';
import LagGrid from './LagGrid';
import { Lag_columns } from './LagColumn';
import { OTDDetail_columns } from './OTDDetailcolumn';
import { OTDmonthDetail_columns } from './OTDMonthDetailColumn';
import { FullDetail_column } from './OTDFullColumn'
import { filterBy } from '@progress/kendo-data-query';

import { OTDMonth_columns } from './OTDMonthColumn'
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { IntlProvider, load, LocalizationProvider } from "@progress/kendo-react-intl";
import likelySubtags from "cldr-core/supplemental/likelySubtags.json";
import currencyData from "cldr-core/supplemental/currencyData.json";
import weekData from "cldr-core/supplemental/weekData.json";
import numbers from "cldr-numbers-full/main/es/numbers.json";
import caGregorian from "cldr-dates-full/main/es/ca-gregorian.json";
import dateFields from "cldr-dates-full/main/es/dateFields.json";
import timeZoneNames from "cldr-dates-full/main/es/timeZoneNames.json";
import moment from 'moment';
import DrillDown from './OTDDetailview'
import { Button } from '@progress/kendo-react-buttons';
import Chart from '.././Chart/OTDDetailChart'
import Drill from './OTDFullDetail'
import { ComboBox } from '@progress/kendo-react-dropdowns';
import { CustomCalendar } from './customCalender'

import { throwStatement } from "@babel/types";


// import Moment from 'moment';
// import { extendMoment } from 'moment-range';

// const moment = extendMoment(Moment);
load(likelySubtags, currencyData, weekData, numbers, caGregorian, dateFields, timeZoneNames);


let fromdate = new Date();
let todate = new Date();
let toDateCol = new Date();
//todate.setDate(todate.getDate() - 1)
if (fromdate.getDate() === 1) {
    fromdate.setDate(2);
    fromdate.setMonth(fromdate.getMonth() - 1)
    //todate=fromdate
}
else {

    fromdate.setDate(1);
    // todate=fromdate

}
let todatemax = new Date();
let todatemin = new Date();
//todate.setDate(todate.getDate() - 1)
if (todatemax.getDate() === 1) {
    todatemax.setDate(1);
    todatemax.setMonth(todatemax.getMonth() - 1)
    //todate=fromdate
}
else {

    todatemax.setDate(1);
    // todate=fromdate

}
let charttodate = new Date()
charttodate.setDate(charttodate.getDate() - 1)
let chartfromdate = new Date();
if (chartfromdate.getDate() === 1) {
    chartfromdate.setDate(1);
    chartfromdate.setMonth(chartfromdate.getMonth() - 1)
}
else {

    chartfromdate.setDate(1);

}
let drilltodate = new Date()
drilltodate.setDate(drilltodate.getDate())
let drillfromdate = new Date();
if (drillfromdate.getDate() === 1) {
    drillfromdate.setDate(1);
    drillfromdate.setMonth(drillfromdate.getMonth() - 1)
}
else {

    drillfromdate.setDate(1);

}
let max = new Date(), min = new Date()
max = new Date(max.getFullYear(), max.getMonth() + 1, 0);

min.setMonth(min.getMonth() - 5)
min.setDate(1);
let frommax = new Date(), frommin = new Date()
// frommax = new Date(frommax.getFullYear(), frommax.getMonth() + 1, 0);

frommin.setMonth(frommin.getMonth() - 5)
frommin.setDate(1);
let tomax = new Date(), tomin = new Date()
// frommax = new Date(frommax.getFullYear(), frommax.getMonth() + 1, 0);

tomin.setMonth(tomin.getMonth() - 5)
tomin.setDate(1);
let monthtodate = new Date()
monthtodate.setDate(1)
let monthfromdate = new Date();
monthfromdate.setDate(1);
monthfromdate.setMonth(monthfromdate.getMonth() - 5)
let fromdateColumn = moment(fromdate).format('YYYY-MM-DD');
// toDateCol.setDate(todate.getDate())
let toDateColumn = moment(todate).format('YYYY-MM-DD');
Date.prototype.addDays = function (days) {
    var dat = new Date(this.valueOf())
    dat.setDate(dat.getDate() + days);
    return dat;
}
class LagReport extends React.Component {
    getDates(startDate, stopDate) {
        var dateArray = new Array();
        var currentDate = startDate;
        while (currentDate <= stopDate) {
            dateArray.push(currentDate)
            currentDate = currentDate.addDays(1);
        }
        return dateArray;
    }
    locale = {
        language: "en-US",
        locale: "en"
    }
    state = {
        columns: Lag_columns,
        Datecolumns: [],
        DetailedColumn: OTDDetail_columns,
        MonthDetailColumn: OTDmonthDetail_columns,
        FullDetailedColumn: FullDetail_column,
        Detailedaggregates: [],
        MonthDetailaggregates: [],
        Filter: ["Day Wise", "Week Wise", "Month Wise"],
        FilterData: ["Day Wise", "Week Wise", "Month Wise"],
        Filtername: "Day Wise",
        FullDetail: false,
        input: {
            "FromDate": moment(monthtodate).format('YYYY-MM-DD'),
            

        },
        Detailinput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '7'
        },
        chartInput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '1'

        },
        DrillchartInput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '10'

        },

        MonthDrillchartInput: {
            "FromDate": moment(monthfromdate).format('YYYY-MM-DD'),
            "ToDate": moment(monthtodate).format('YYYY-MM-DD'),
            "ReportType": '11'

        },
        MonthGridinput: {
            "FromDate": moment(monthfromdate).format('YYYY-MM-DD'),
            "ToDate": moment(monthtodate).format('YYYY-MM-DD'),
            "ReportType": '8'

        },
        MonthDetailinput: {
            "FromDate": moment(monthfromdate).format('YYYY-MM-DD'),
            "ToDate": moment(monthtodate).format('YYYY-MM-DD'),
            "ReportType": '3'
        },
        MonthchartInput: {
            "FromDate": moment(monthfromdate).format('YYYY-MM-DD'),
            "ToDate": moment(monthtodate).format('YYYY-MM-DD'),
            "ReportType": '9'

        },

        FullDetailInput: {
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '5'
        },
        FullMonthDetailInput: {
            "FromDate": moment(monthfromdate).format('YYYY-MM-DD'),
            "ToDate": moment(monthtodate).format('YYYY-MM-DD'),
            "ReportType": '5'

        },
        WeekGridinput: {
            "FromDate": "2021-01-01",
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '13'

        },
        WeekchartInput: {
            "FromDate": "2021-01-01",
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '12'

        },
        WeekDrillchartInput: {
            "FromDate": "2021-01-01",
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '15'
        },
        WeekDrillgridInput: {
            "FromDate": "2021-01-01",
            "ToDate": moment(todate).format('YYYY-MM-DD'),
            "ReportType": '14'
        },
        callGrid: true,
        callAgain: false,
        callchart: false,
        calldrillGrid: true,
        calldrillAgain: false,
        call: true,
        callchartAgain: false,
        callmonthGrid: true,
        callmonthAgain: false,
        callmonthdrillGrid: true,
        callmonthdrillAgain: false,
        callmonth: true,
        callmonthchartAgain: false,
        callfulldrillGrid: true,
        callfulldrillAgain: false,
        maintainto: todate,
        maintainfrom: fromdate,
        fromdate: fromdate,
        todate: todate,
        drillfromdate: drillfromdate,
        drilltodate: drilltodate,
        chartfromdate: chartfromdate,
        charttodate: charttodate,
        monthfromdate: monthfromdate,
        monthtodate: monthtodate,
        fromdatecol: moment(fromdate).format('YYYY-MM-DD'),
        todatecol: moment(todate).format('YYYY-MM-DD'),
        monthfromdatecol: moment(monthfromdate).format('YYYY-MM-DD'),
        monthtodatecol: moment(monthtodate).format('YYYY-MM-DD'),
        OTDReportaggregates: [],
        dateColumn: [],
        GridColumn: [],
        Griddata: [],
        chartData: [],
        remove: [],
        isDrill: false,
        gridsearchValue: "",
        changefilter: "Day Wise",
        WeekColumn: [],
        WeekColumn2: []

    }

    componentWillMount = () => {
debugger

        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    componentDidMount() {
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
        this.setState({
            todatecheckyear: todate.getFullYear(),
            fromdatecheckyear: fromdate.getFullYear(),
            todatecheckdate: todate.getDate(),
            todatecheckmonth: todate.getMonth(),
            fromdatecheckdate: fromdate.getDate(),
            fromdatecheckmonth: fromdate.getMonth(),
            charttodatecheckyear: todate.getFullYear(),
            chartfromdatecheckyear: fromdate.getFullYear(),
            charttodatecheckdate: todate.getDate(),
            charttodatecheckmonth: todate.getMonth(),
            chartfromdatecheckdate: fromdate.getDate(),
            chartfromdatecheckmonth: fromdate.getMonth(),
            drilltodatecheckyear: todate.getFullYear(),
            drillfromdatecheckyear: fromdate.getFullYear(),
            drilltodatecheckdate: todate.getDate(),
            drilltodatecheckmonth: todate.getMonth(),
            drillfromdatecheckdate: fromdate.getDate(),
            drillfromdatecheckmonth: fromdate.getMonth(),
            monthtodatecheckyear: monthtodate.getFullYear(),
            monthfromdatecheckyear: monthfromdate.getFullYear(),
            monthtodatecheckdate: monthtodate.getDate(),
            monthtodatecheckmonth: monthtodate.getMonth(),
            monthfromdatecheckdate: monthfromdate.getDate(),
            monthfromdatecheckmonth: monthfromdate.getMonth(),
        })


    }
    monthbackdrill = () => {

        let input = this.state.MonthGridinput;
        input["FromDate"] = moment(this.state.monthfromdate).format('YYYY-MM-DD')
        input["ToDate"] = moment(this.state.monthtodate).format('YYYY-MM-DD')

        let dateEnd, dateStart, colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "Title",
                title: "",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall OTD MTD",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "no"
            }
        ], datcol = [], col = []
        let End = moment(this.state.monthtodate).format('YYYY-MM-DD');
        let Start = moment(this.state.monthfromdate).format('YYYY-MM-DD');
        dateEnd = moment(End);
        dateStart = moment(Start);

        while (dateEnd > dateStart || dateStart.format('M') === dateEnd.format('M')) {
            col = {
                field: dateStart.format('MMM'),
                title: dateStart.format('MMM'),
                minWidnt: "150",
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "yes"
            }
            datcol.push(col)
            dateStart.add(1, 'month');
        }

        datcol.map((d) => {
            colu.push(d)
        })


        this.setState({ Dayscolumns: colu })
        setTimeout(() => {
            datcol.map((d) => {
                colu.pop()
            })
        }, 200);
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {

            this.setState({ isDrill: false })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else {
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);


    }
    backfromfulldrill = () => {
        let input = this.state.Detailinput;
        input["FromDate"] = moment(this.state.fromdate).format('YYYY-MM-DD')
        input["ToDate"] = moment(this.state.todate).format('YYYY-MM-DD')

        let endDate, startDate, colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "StageGroup",
                title: "Stage Group",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "no"
            }

        ], datcol = [], col = []
        endDate = new Date(this.state.todate);
        startDate = new Date(this.state.fromdate);
        let a = this.getDates(startDate, endDate);

        a.map((a) => {
            col = {
                field: moment(a).format('DD-MMM'),
                title: moment(a).format('DD-MMM'),
                minWidnt: "150",
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "yes"
            }
            datcol.push(col)
        }

        )
        this.setState({ dateColumn: datcol })
        datcol.map((d) => {
            colu.push(d)
        })


        this.setState({ DetailedColumn: colu })
        setTimeout(() => {
            datcol.map((d) => {
                colu.pop()
            })
        }, 200);
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {

            this.setState({ FullDetail: false })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else {
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);


    }
    backfrommonthfulldrill = () => {
        let input = this.state.MonthDetailinput;
        input["FromDate"] = moment(this.state.monthfromdate).format('YYYY-MM-DD')
        input["ToDate"] = moment(this.state.monthtodate).format('YYYY-MM-DD')
        let dateEnd, dateStart, colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "StageGroup",
                title: "Stage Group",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "no"
            }

        ], datcol = [], col = []
        let End = moment(this.state.monthtodate).format('YYYY-MM-DD');
        let Start = moment(this.state.monthfromdate).format('YYYY-MM-DD');
        dateEnd = moment(End);
        dateStart = moment(Start);

        while (dateEnd > dateStart || dateStart.format('M') === dateEnd.format('M')) {
            col = {
                field: dateStart.format('MMM'),
                title: dateStart.format('MMM'),
                minWidnt: "150",
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "yes"
            }
            datcol.push(col)
            dateStart.add(1, 'month');
        }

        datcol.map((d) => {
            colu.push(d)
        })


        this.setState({ MonthDetailColumn: colu })
        setTimeout(() => {
            datcol.map((d) => {
                colu.pop()
            })
        }, 200);
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {

            this.setState({ FullDetail: false })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else {
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);


    }
    backdrill = () => {

        let input = this.state.input;
        input["FromDate"] = moment(this.state.fromdate).format('YYYY-MM-DD')
        input["ToDate"] = moment(this.state.todate).format('YYYY-MM-DD')

        let endDate, startDate, colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "Title",
                title: "",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall OTD MTD",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "no"
            }
        ], datcol = [], col = []
        endDate = new Date(this.state.todate);
        startDate = new Date(this.state.fromdate);
        let a = this.getDates(startDate, endDate);

        a.map((a) => {
            col = {
                field: moment(a).format('DD-MMM'),
                title: moment(a).format('DD-MMM'),
                minWidnt: "150",
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "yes"
            }
            datcol.push(col)
        }

        )
        this.setState({ dateColumn: datcol })
        datcol.map((d) => {
            colu.push(d)
        })


        this.setState({ Datecolumns: colu })
        setTimeout(() => {
            datcol.map((d) => {
                colu.pop()
            })
        }, 200);
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else {
                this.setState({ navopen: false })
            }
        }
        setTimeout(() => {

            this.setState({ isDrill: false })
        }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('grid-container').style.marginLeft = "150px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else {
                document.getElementById('grid-container').style.marginLeft = "15px";
                //document.getElementById('grid-body').style.marginLeft = "50px";
            }
        }, 200);


    }
    TomonthGridData = (navopen, fromdat, todat) => {
        debugger
        let input = this.state.MonthGridinput;
        input["FromDate"] = moment(fromdat).format('YYYY-MM-DD')
        input["ToDate"] = moment(todat).format('YYYY-MM-DD')

        let dateEnd, dateStart, colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "Title",
                title: "",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall OTD MTD",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "no"
            }
        ], datcol = [], col = []
        let End = moment(todat).format('YYYY-MM-DD');
        let Start = moment(fromdat).format('YYYY-MM-DD');
        dateEnd = moment(End);
        dateStart = moment(Start);

        while (dateEnd > dateStart || dateStart.format('M') === dateEnd.format('M')) {
            col = {
                field: dateStart.format('MMM'),
                title: dateStart.format('MMM'),
                minWidnt: "150",
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "yes"
            }
            datcol.push(col)
            dateStart.add(1, 'month');
        }

        datcol.map((d) => {
            colu.push(d)
        })


        this.setState({ Dayscolumns: colu })
        setTimeout(() => {
            datcol.map((d) => {
                colu.pop()
            })
        }, 200);
        this.setState({ navopen: navopen, MonthGridinput: input })
        this.setState({ monthfromdate: fromdat });
        this.setState({ monthtodate: todat })
        this.setState({ callchart: !this.state.callchart })
        // this.setState({ Datecolumns: col })
        // setTimeout(() => {
        //     this.state.remove.map((d) => {
        //         col.pop()
        //     })
        // }, 500);
    }
    ToGridData = (navopen, fromdat, todat) => {
        debugger
        let input = this.state.input;
        input["FromDate"] = moment(fromdat).format('YYYY-MM-DD')
        input["ToDate"] = moment(todat).format('YYYY-MM-DD')

        let endDate, startDate, colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "Title",
                title: "",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall OTD MTD",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "no"
            }
        ], datcol = [], col = []
        endDate = new Date(todat);
        startDate = new Date(fromdat);
        let a = this.getDates(startDate, endDate);

        a.map((a) => {
            col = {
                field: moment(a).format('DD-MMM'),
                title: moment(a).format('DD-MMM'),
                minWidnt: "150",
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "yes"
            }
            datcol.push(col)
        }

        )
        this.setState({ dateColumn: datcol })
        datcol.map((d) => {
            colu.push(d)
        })


        this.setState({ Datecolumns: colu })
        setTimeout(() => {
            datcol.map((d) => {
                colu.pop()
            })
        }, 200);
        this.setState({ navopen: navopen, input: input })
        this.setState({ fromdate: fromdat });
        this.setState({ todate: todat })
        this.setState({ callchart: !this.state.callchart })
        // this.setState({ Datecolumns: col })
        // setTimeout(() => {
        //     this.state.remove.map((d) => {
        //         col.pop()
        //     })
        // }, 500);
    }
    TodrillGridData = (navopen, fromdat, todat) => {
        debugger
        let input = this.state.DrillchartInput;
        input["FromDate"] = moment(fromdat).format('YYYY-MM-DD')
        input["ToDate"] = moment(todat).format('YYYY-MM-DD')

        let endDate, startDate, colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "StageGroup",
                title: "Stage Group",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "no"
            }

        ], datcol = [], col = []
        endDate = new Date(todat);
        startDate = new Date(fromdat);
        let a = this.getDates(startDate, endDate);

        a.map((a) => {
            col = {
                field: moment(a).format('DD-MMM'),
                title: moment(a).format('DD-MMM'),
                minWidnt: "150",
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "yes"
            }
            datcol.push(col)
        }

        )
        this.setState({ dateColumn: datcol })
        datcol.map((d) => {
            colu.push(d)
        })


        this.setState({ DetailedColumn: colu })
        setTimeout(() => {
            datcol.map((d) => {
                colu.pop()
            })
        }, 200);
        this.setState({ navopen: navopen, DrillchartInput: input })
        this.setState({ fromdate: fromdat });
        this.setState({ todate: todat })
        this.setState({ callchart: !this.state.callchart })

    }
    TodrillmonthGridData = (navopen, fromdat, todat) => {
        debugger
        let input = this.state.MonthDrillchartInput;
        input["FromDate"] = moment(fromdat).format('YYYY-MM-DD')
        input["ToDate"] = moment(todat).format('YYYY-MM-DD')
        let dateEnd, dateStart, colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "StageGroup",
                title: "Stage Group",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "no"
            }

        ], datcol = [], col = []
        let End = moment(todat).format('YYYY-MM-DD');
        let Start = moment(fromdat).format('YYYY-MM-DD');
        dateEnd = moment(End);
        dateStart = moment(Start);

        while (dateEnd > dateStart || dateStart.format('M') === dateEnd.format('M')) {
            col = {
                field: dateStart.format('MMM'),
                title: dateStart.format('MMM'),
                minWidnt: "150",
                filter: "text",
                show: true,
                format: "{0:0.00}",
                date: "yes"
            }
            datcol.push(col)
            dateStart.add(1, 'month');
        }

        datcol.map((d) => {
            colu.push(d)
        })


        this.setState({ MonthDetailColumn: colu })
        setTimeout(() => {
            datcol.map((d) => {
                colu.pop()
            })
        }, 200);
        this.setState({ navopen: navopen, MonthDrillchartInput: input })
        this.setState({ fromdate: fromdat });
        this.setState({ todate: todat })
        this.setState({ callchart: !this.state.callchart })

    }
    chartData = (navopen, data, column, Griddata, search, input) => {
        debugger

        // let columnName = OTD_columns
        // column.map((d) => {
        //     columnName.push(d)
        // })

        this.setState({ Griddata: Griddata })
        this.setState({ chartData: data })
        this.setState({ navopen: navopen })
        // this.setState({ GridColumn: columnName })
        this.setState({ callchart: !this.state.callchart })
        this.setState({ gridsearchValue: search, remove: column })


        // this.setState({isDrillchart:isDrill})
    }
    isFullDrill = (isfrom, from, to) => {
        debugger
        if (this.state.Filtername === "Month Wise") {
            let input = this.state.FullMonthDetailInput;
            input["FromDate"] = moment(from).format('YYYY-MM-DD')
            input["ToDate"] = moment(to).format('YYYY-MM-DD')


            this.setState({ FullMonthDetailInput: input })
            this.setState({ monthfromdate: from });
            this.setState({ monthtodate: to });
            this.setState({ FullDetail: true })
        }
        else {
            let input = this.state.FullDetailInput;
            input["FromDate"] = moment(from).format('YYYY-MM-DD')
            input["ToDate"] = moment(to).format('YYYY-MM-DD')

            this.setState({ FullDetailInput: input })
            this.setState({ fromdate: from });
            this.setState({ todate: to });
            this.setState({ FullDetail: !this.state.FullDetail })

        }
    }
    isDrill = (isfrom, from, to) => {
        debugger
        if (isfrom === true) {
            let input = this.state.MonthDetailinput;
            input["FromDate"] = moment(from).format('YYYY-MM-DD')
            input["ToDate"] = moment(to).format('YYYY-MM-DD')
            let dateEnd, dateStart, colu = [
                {
                    field: "ID",
                    title: "SI.No.",
                    minWidnt: 185,
                    filter: "text",
                    show: false,
                    format: "",
                    date: "no"
                },

                {
                    field: "StageGroup",
                    title: "Stage Group",
                    minWidnt: 185,
                    filter: "text",
                    show: true,
                    format: "",
                    date: "no"
                },
                {
                    field: "Total",
                    title: "Overall",
                    minWidnt: 185,
                    filter: "text",
                    show: true,
                    format: "{0:0.00}",
                    date: "no"
                }

            ], datcol = [], col = []
            let End = moment(to).format('YYYY-MM-DD');
            let Start = moment(from).format('YYYY-MM-DD');
            dateEnd = moment(End);
            dateStart = moment(Start);

            while (dateEnd > dateStart || dateStart.format('M') === dateEnd.format('M')) {
                col = {
                    field: dateStart.format('MMM'),
                    title: dateStart.format('MMM'),
                    minWidnt: "150",
                    filter: "text",
                    show: true,
                    format: "{0:0.00}",
                    date: "yes"
                }
                datcol.push(col)
                dateStart.add(1, 'month');
            }

            datcol.map((d) => {
                colu.push(d)
            })


            this.setState({ MonthDetailColumn: colu })
            setTimeout(() => {
                datcol.map((d) => {
                    colu.pop()
                })
            }, 200);

            this.setState({ MonthDetailinput: input })
            this.setState({ monthfromdate: from });
            this.setState({ monthtodate: to });
            this.setState({ isDrill: !this.state.isDrill })
        }
        else {
            let input = this.state.Detailinput;
            input["FromDate"] = moment(from).format('YYYY-MM-DD')
            input["ToDate"] = moment(to).format('YYYY-MM-DD')

            let endDate, startDate, colu = [
                {
                    field: "ID",
                    title: "SI.No.",
                    minWidnt: 185,
                    filter: "text",
                    show: false,
                    format: "",
                    date: "no"
                },

                {
                    field: "StageGroup",
                    title: "Stage Group",
                    minWidnt: 185,
                    filter: "text",
                    show: true,
                    format: "",
                    date: "no"
                },
                {
                    field: "Total",
                    title: "Overall",
                    minWidnt: 185,
                    filter: "text",
                    show: true,
                    format: "{0:0.00}",
                    date: "no"
                }

            ], datcol = [], col = []
            endDate = new Date(to);
            startDate = new Date(from);
            let a = this.getDates(startDate, endDate);

            a.map((a) => {
                col = {
                    field: moment(a).format('DD-MMM'),
                    title: moment(a).format('DD-MMM'),
                    minWidnt: "150",
                    filter: "text",
                    show: true,
                    format: "{0:0.00}",
                    date: "yes"
                }
                datcol.push(col)
            }

            )
            this.setState({ dateColumn: datcol })
            datcol.map((d) => {
                colu.push(d)
            })


            this.setState({ DetailedColumn: colu })
            setTimeout(() => {
                datcol.map((d) => {
                    colu.pop()
                })
            }, 200);
            this.setState({ Detailinput: input })
            this.setState({ fromdate: from });
            this.setState({ todate: to });
            this.setState({ isDrill: !this.state.isDrill })

        }
    }
    FalseIsComing = () => {
        this.setState({ isComing: false })
    }
    changedrillToStuff = (date) => {
        this.setState({ drilltodate: date })

        if (date !== null) {

            let input = this.state.Detailinput;
            input["ToDate"] = moment(date).format('YYYY-MM-DD')
            setTimeout(() => {
                this.setState({
                    Detailinput: input,
                    drilltodatecheckyear: date.getFullYear(),
                    drilltodatecheckmonth: date.getMonth(),
                    drilltodatecheckdate: date.getDate()
                })
            }, 200);
        }

    }
    changedrillFromStuff = (date) => {
        this.setState({ drillfromdate: date })

        if (date !== null) {

            let input = this.state.Detailinput;
            input["FromDate"] = moment(date).format('YYYY-MM-DD')
            setTimeout(() => {
                this.setState({
                    Detailinput: input,
                    drillfromdatecheckyear: date.getFullYear(),
                    drillfromdatecheckmonth: date.getMonth(),
                    drillfromdatecheckdate: date.getDate()
                })
            }, 200);
        }
    }
    changeToStuff = (date) => {
        this.setState({ todate: date })
        if (date !== null) {
            let input = this.state.input, chartinput = this.state.chartInput, drillinput = this.state.Detailinput, FullDetailInput = this.state.FullDetailInput, DrillchartInput = this.state.DrillchartInput, to = new Date();
            input["ToDate"] = moment(date).format('YYYY-MM-DD')
            chartinput["ToDate"] = moment(date).format('YYYY-MM-DD')
            drillinput["ToDate"] = moment(date).format('YYYY-MM-DD')
            FullDetailInput["ToDate"] = moment(date).format('YYYY-MM-DD')
            DrillchartInput["ToDate"] = moment(date).format('YYYY-MM-DD')
            this.setState({ maintainto: date })
            setTimeout(() => {
                to.setDate(this.state.todate.getDate())
                to.setMonth(this.state.todate.getMonth())
                to.setFullYear(this.state.todate.getFullYear())
                this.setState({
                    todatecol: moment(this.state.todate).format('YYYY-MM-DD'),
                    input: input,
                    chartInput: chartinput,
                    Detailinput: drillinput,
                    FullDetailInput: FullDetailInput,
                    DrillchartInput: DrillchartInput,
                    todatecheckyear: date.getFullYear(),
                    todatecheckmonth: date.getMonth(),
                    todatecheckdate: date.getDate()
                })
            }, 200);
        }

    }
    changeFromStuff = (date) => {
        debugger
        this.setState({ fromdate: date })

        if (date !== null) {
            tomax=new Date(date)
            let current=new Date()
            tomax.setDate(tomax.getDate() + 30)
            let tochecktomax=moment(tomax).format('YYYY-MM-DD')
            let tocheckcurrent=moment(current).format('YYYY-MM-DD')
            if(moment(tochecktomax)
            .isAfter(tocheckcurrent)){
                tomax=new Date();
                this.setState({todate:tomax })
            }
            else{
                this.setState({todate:tomax })
            }
            tomin.setDate(date.getDate())
            tomin.setMonth(date.getMonth())
            tomin.setFullYear(date.getFullYear())
         
            let input = this.state.input,
                chartinput = this.state.chartInput,
                drillinput = this.state.Detailinput,
                FullDetailInput = this.state.FullDetailInput,
                DrillchartInput = this.state.DrillchartInput,
                fromdate = new Date();
            input["FromDate"] = moment(date).format('YYYY-MM-DD')
            input["ToDate"] = moment(tomax).format('YYYY-MM-DD')

            chartinput["FromDate"] = moment(date).format('YYYY-MM-DD')
            chartinput["ToDate"] = moment(tomax).format('YYYY-MM-DD')

            drillinput["FromDate"] = moment(date).format('YYYY-MM-DD')
            drillinput["ToDate"] = moment(tomax).format('YYYY-MM-DD')

            FullDetailInput["FromDate"] = moment(date).format('YYYY-MM-DD')
            FullDetailInput["ToDate"] = moment(tomax).format('YYYY-MM-DD')
            
            DrillchartInput["FromDate"] = moment(date).format('YYYY-MM-DD')
            DrillchartInput["ToDate"] = moment(tomax).format('YYYY-MM-DD')

            this.setState({ maintainfrom: date })

            setTimeout(() => {
                fromdate.setDate(this.state.fromdate.getDate())
                fromdate.setMonth(this.state.fromdate.getMonth())
                fromdate.setFullYear(this.state.fromdate.getFullYear())
                this.setState({
                    fromdatecol: moment(this.state.fromdate).format('YYYY-MM-DD'),
                    todatecol:moment(tomax).format('YYYY-MM-DD'),
                    input: input,
                    chartInput: chartinput,
                    Detailinput: drillinput,
                    FullDetailInput: FullDetailInput,
                    DrillchartInput: DrillchartInput,
                    fromdatecheckyear: date.getFullYear(),
                    fromdatecheckmonth: date.getMonth(),
                    fromdatecheckdate: date.getDate()
                })

            }, 200);
        }
    }
    changemonthToStuff = (date) => {
        // var To_date = dat;
        // var date = new Date(To_date.getFullYear(), To_date.getMonth() + 1, 0);


        this.setState({ monthtodate: date })
        if (date !== null) {
            let input = this.state.MonthGridinput, chartinput = this.state.MonthchartInput, drillinput = this.state.MonthDetailinput, FullMonthDetailInput = this.state.FullMonthDetailInput, MonthDrillchartInput = this.state.MonthDrillchartInput, to = new Date();
            input["ToDate"] = moment(date).format('YYYY-MM-DD')
            chartinput["ToDate"] = moment(date).format('YYYY-MM-DD')
            drillinput["ToDate"] = moment(date).format('YYYY-MM-DD')
            FullMonthDetailInput["ToDate"] = moment(date).format('YYYY-MM-DD')
            MonthDrillchartInput["ToDate"] = moment(date).format('YYYY-MM-DD')
            setTimeout(() => {

                this.setState({
                    monthtodatecol: moment(this.state.monthtodate).format('YYYY-MM-DD'),
                    MonthGridinput: input,
                    MonthchartInput: chartinput,
                    MonthDetailinput: drillinput,
                    MonthDrillchartInput: MonthDrillchartInput,
                    FullMonthDetailInput: FullMonthDetailInput,
                    monthtodatecheckyear: date.getFullYear(),
                    monthtodatecheckmonth: date.getMonth(),
                    monthtodatecheckdate: date.getDate()
                })
            }, 200);
        }

    }
    changemonthFromStuff = (date) => {
        debugger
        //console.log(date)

        this.setState({ monthtodate: date })

        if (date !== null) {
         
            let input = this.state.input, MonthDrillchartInput = this.state.MonthDrillchartInput, chartinput = this.state.MonthchartInput, drillinput = this.state.MonthDetailinput, FullMonthDetailInput = this.state.FullMonthDetailInput, fromdate = new Date();
            input["FromDate"] = moment(date).format('YYYY-MM-DD')
            chartinput["FromDate"] = moment(date).format('YYYY-MM-DD')
            drillinput["FromDate"] = moment(date).format('YYYY-MM-DD')
            FullMonthDetailInput["FromDate"] = moment(date).format('YYYY-MM-DD')
            MonthDrillchartInput["FromDate"] = moment(date).format('YYYY-MM-DD')

            setTimeout(() => {

                this.setState({
                    monthfromdatecol: moment(this.state.monthfromdate).format('YYYY-MM-DD'),
                    input: input,
                    MonthchartInput: chartinput,
                    MonthDetailinput: drillinput,
                    FullMonthDetailInput: FullMonthDetailInput,
                    MonthDrillchartInput: MonthDrillchartInput,
                    monthfromdatecheckyear: date.getFullYear(),
                    monthfromdatecheckmonth: date.getMonth(),
                    monthfromdatecheckdate: date.getDate()
                })

            }, 200);
        }
    }
    changechartToStuff = (date) => {
        this.setState({ charttodate: date })

        if (date !== null) {
            let input = this.state.chartInput
            input["ToDate"] = moment(date).format('YYYY-MM-DD')
            this.setState({

                chartInput: input,
                charttodatecheckyear: date.getFullYear(),
                charttodatecheckmonth: date.getMonth(),
                charttodatecheckdate: date.getDate()
            })
        }



    }
    changechartFromStuff = (date) => {
        this.setState({ chartfromdate: date })

        if (date !== null) {
            debugger
            let input = this.state.chartInput
            input["FromDate"] = moment(date).format('YYYY-MM-DD');


            setTimeout(() => {

                this.setState({

                    chartInput: input,
                    chartfromdatecheckyear: date.getFullYear(),
                    chartfromdatecheckmonth: date.getMonth(),
                    chartfromdatecheckdate: date.getDate()
                })

            }, 200);
        }
    }
    filterChange = (event) => {
        if (event.target.props.placeholder === "Select Filter") {
            this.setState({
                Filter: this.filterData(event.filter, event.target.props.placeholder)
            });
        }
    }
    filterData(filter, name) {
        if (name === "Select Filter") {
            const data = this.state.FilterData.slice();
            return filterBy(data, filter);
        }

    }
    lastUpdatedate = (date) => {
        this.setState({ lastupdate: date })
    }
    weekColumn = (column) => {
        let colu = [
            {
                field: "ID",
                title: "SI.No.",
                minWidnt: 185,
                filter: "text",
                show: false,
                format: "",
                date: "no"
            },

            {
                field: "Title",
                title: "",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            },
            {
                field: "Total",
                title: "Overall",
                minWidnt: 185,
                filter: "text",
                show: true,
                format: "",
                date: "no"
            }

        ],
            col1 = [
                {
                    field: "ID",
                    title: "SI.No.",
                    minWidnt: 185,
                    filter: "text",
                    show: false,
                    format: "",
                    date: "no"
                },

                {
                    field: "StageGroup",
                    title: "Stage Group",
                    minWidnt: 185,
                    filter: "text",
                    show: true,
                    format: "",
                    date: "no"
                },
                {
                    field: "Total",
                    title: "Overall",
                    minWidnt: 185,
                    filter: "text",
                    show: true,
                    format: "{0:0.00}",
                    date: "no"
                }

            ], datcol = [], datcol1 = [], col = []

        column.map((a) => {
            col = {
                field: a,
                title: "Week of " + a,
                minWidnt: 300,
                filter: "text",
                show: true,
                format: "",
                date: "yes"
            }
            datcol.push(col)
            datcol1.push(col)
        }

        )
        datcol.map((d) => {
            colu.push(d)
        })
        datcol1.map((d) => {
            col1.push(d)
        })


        this.setState({ WeekColumn: colu })
        this.setState({ WeekColumn2: col1 })


    }
    render() {

        let grid = (<div className="OTD"><div className="SpeedNotes"><span style={{color:"red"}}>Note : </span>Last updated on {this.state.lastupdate}</div><LagGrid title={"Lag Report"} navopen={this.state.navopen} isDrill={this.isDrill} FullDetail={false}
            gridsearchValue={this.state.gridsearchValue} FalseIsComing={this.FalseIsComing}  lastUpdatedate={this.lastUpdatedate}  Griddata={this.state.Griddata}
            isComing={this.state.isComing} name={this.state.name} input={this.state.input} columns={this.state.columns}
            aggregates={this.state.OTDReportaggregates} chart={this.state.chartData} chartData={this.chartData} fromdate={this.state.fromdate} todate={this.state.todate} /></div>
          

        )
        let chart = (
            this.state.changefilter === "Day Wise" ?
                <div><div className="SpeedNotes">Note : Last updated on {this.state.lastupdate}</div> <ChartContainer fromdate={this.state.fromdate} title={"OTD - Day Wise"} weekColumn=
                    {this.weekColumn} todate={this.state.todate} chartData={this.state.chartData} input={this.state.chartInput} lastUpdatedate={this.lastUpdatedate} chartDatafunc={this.ToGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>
                : this.state.changefilter === "Week Wise" ? <div><div className="SpeedNotes">Note : Last updated on {this.state.lastupdate}</div> <ChartContainer fromdate={this.state.fromdate} title={"OTD - Week Wise"} todate={this.state.todate} chartData={this.state.chartData} input={this.state.WeekchartInput} lastUpdatedate={this.lastUpdatedate} chartDatafunc={this.ToGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div> :
                    <div><div className="SpeedNotes">Note : Last updated on {this.state.lastupdate}</div> <ChartContainer fromdate={this.state.monthfromdate} title={"OTD - Month Wise"} todate={this.state.monthtodate} chartData={this.state.chartData} input={this.state.MonthchartInput} lastUpdatedate={this.lastUpdatedate} chartDatafunc={this.TomonthGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>


        )
        let drill = (
            this.state.changefilter === "Day Wise" ?
                <div className="OTD"><div className="Drillgrid">{/* To show drilldown grid */}
                    <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Last updated on {this.state.lastupdate}</div>
                    <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backdrill}>Go Back</Button> {/* To go back to normal grid */}
                    <DrillDown navopen={this.state.navopen} filter={"Day Wise"} title={"OTD - Detail- Day Wise"} isDrill={this.isFullDrill} chartData={this.chartData} input={this.state.Detailinput} DetailedColumn={this.state.DetailedColumn} Detailedaggregates={this.state.Detailedaggregates} fromdate={this.state.fromdate} todate={this.state.todate} />
                </div></div>
                : this.state.changefilter === "Week Wise" ?
                    <div className="OTD"><div className="Drillgrid">{/* To show drilldown grid */}
                        <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Last updated on {this.state.lastupdate}</div>
                        <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backdrill}>Go Back</Button> {/* To go back to normal grid */}
                        <DrillDown navopen={this.state.navopen} filter={"Week Wise"} title={"OTD - Detail- Week Wise"} isDrill={this.isFullDrill} chartData={this.chartData} input={this.state.WeekDrillgridInput} DetailedColumn={this.state.WeekColumn2} Detailedaggregates={this.state.Detailedaggregates} fromdate={this.state.fromdate} todate={this.state.todate} />
                    </div></div>
                    :
                    <div className="OTD"><div className="Drillgrid">{/* To show drilldown grid */}
                        <div className="SpeedNotes"><span style={{color:"red"}}>Note :</span> Last updated on {this.state.lastupdate}</div>
                        <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.monthbackdrill}>Go Back</Button> {/* To go back to normal grid */}
                        <DrillDown navopen={this.state.navopen} filter={"Month Wise"} title={"OTD - Detail - Month Wise"} chartData={this.chartData} isDrill={this.isFullDrill} input={this.state.MonthDetailinput} DetailedColumn={this.state.MonthDetailColumn} Detailedaggregates={this.state.MonthDetailaggregates} fromdate={this.state.monthfromdate} todate={this.state.monthtodate} />
                    </div></div>
        )

        let chartdrill = (
            this.state.changefilter === "Day Wise" ?
                <div><div className="SpeedNotes">Note : Last updated on {this.state.lastupdate}</div>
                    <Chart fromdate={this.state.fromdate} todate={this.state.todate} title={"OTD - Detail- Day Wise"} chartData={this.state.chartData} input={this.state.DrillchartInput} chartDatafunc={this.TodrillGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>
                : this.state.changefilter === "Week Wise" ?
                    <div><div className="SpeedNotes">Note : Last updated on {this.state.lastupdate}</div>
                        <Chart fromdate={this.state.fromdate} todate={this.state.todate} title={"OTD - Detail- Week Wise"} chartData={this.state.chartData} input={this.state.WeekDrillchartInput} chartDatafunc={this.TodrillGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>
                    :
                    <div><div className="SpeedNotes">Note : Last updated on {this.state.lastupdate}</div>

                        <Chart fromdate={this.state.monthfromdate} todate={this.state.monthtodate} title={"OTD - Detail - Month Wise"} chartData={this.state.chartData} input={this.state.MonthDrillchartInput} chartDatafunc={this.TodrillmonthGridData} navopen={this.state.navopen} isDrillchart={this.state.isDrillchart} toGridfromdrillchart={this.toGridfromdrillchart} /></div>


        )


        let fullDrill = (this.state.changefilter === "Day Wise" ? <div className="Drillgrid">{/* To show drilldown grid */}
            <div className="SpeedNotes">Note : Last updated on {this.state.lastupdate}</div>

            <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backfromfulldrill}>Go Back</Button>
            <Drill navopen={this.state.navopen} title={"OTD - Detail"} input={this.state.FullDetailInput} DetailedColumn={this.state.FullDetailedColumn} Detailedaggregates={this.state.MonthDetailaggregates} />

        </div>
            :
            <div className="Drillgrid">{/* To show drilldown grid */}
                <div className="SpeedNotes">Note : Last updated on {this.state.lastupdate}</div>

                <Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backfrommonthfulldrill}>Go Back</Button> {/* To go back to normal grid */}
                <Drill navopen={this.state.navopen} title={"OTD - Detail"} input={this.state.FullMonthDetailInput} DetailedColumn={this.state.FullDetailedColumn} Detailedaggregates={this.state.MonthDetailaggregates} />
            </div>)

        return (

            this.state.callchart === false && this.state.isDrill === false && this.state.FullDetail === false ?


                <div className='move-grid-container' id='grid-container'>
                    <div className="Multiselect">

                    <div className="inn">Apply filter :  
                      
                        <LocalizationProvider language={this.locale.language}>
                            <IntlProvider locale={this.locale.locale}>

                            <label className="k-form-field">
                                                            {/* <span className="CCToDate">From Date : </span> */}
                                                            <DatePicker
                                                                title="From Date"
                                                                value={this.state.monthtodate}
                                                                min={min}
                                                                max={max}
                                                                onChange={
                                                                    (e) => {
                                                                        let value = e.target.value
                                                                        this.changemonthFromStuff(value)
                                                                    }
                                                                }
                                                                calendar={CustomCalendar}

                                                                format="MMM-yyyy"

                                                            /></label>
                            </IntlProvider>
                        </LocalizationProvider>



                      

                        <button className="Go_button" title="Go" onClick={() => {
                            debugger
                   


                                this.setState({ changefilter: this.state.Filtername, callGrid: !this.state.callGrid, callAgain: !this.state.callAgain })


                           
                           
                        }}>GO</button>

                    </div></div>
                    {this.state.callGrid && (grid)}
                    {this.state.callAgain && (grid)}
                </div>

                
               : null
        );


    }
}

export default LagReport;