export const RFTReport_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "TypeSetter",
        title: "Typesetter",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Tierlevel",
        title: "Tier Level",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "shortName",
        title: "Journal Name",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
    ,
    {
        field: "Production_Editor",
        title: "Production Editor",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
    ,
    {
        field: "BookCode",
        title: "Book Code",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
    ,
    {
        field: "CountryName",
        title: "Country",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }

    ,
    {
        field: "TotalRevises",
        title: "Total No. Revises",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
    ,
    {
        field: "TotalPreview",
        title: "Total No. Preview",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
    ,
    {
        field: "Total",
        title: "Total",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
   
]