export const OUPMaster_column = [
    {
        field: "PM",
        title: "PM",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "Location",
        title: "Location",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "Journal Name",
        title: "Journal Name",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Journal TAT(weeks/days)",
        title: "Journal TAT(weeks/days)",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Manuscript ID",
        title: "Manuscript ID",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Article ID",
        title: "Article ID",
        minWidnt: 205,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "HS email date",
        title: "HS email date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Ingest Status",
        title: "Ingest Status",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Correction Notice",
        title: "Correction Notice",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Ageing",
        title: "Ageing",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Count down days",
        title: "Count down days",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "License Type",
        title: "License Type",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "License Recd date",
        title: "License Recd date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Embargo",
        title: "Embargo",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Article Type",
        title: "Article Type",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },

    {
        field: "Notes to Typesetter",
        title: "Notes to Typesetter",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "TS Pages",
        title: "TS Pages",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Article Received date",
        title: "Article Received date",
        minWidnt: 205,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PAP-A due date",
        title: "PAP-A due date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PAP-A delivered date",
        title: "PAP-A delivered date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PAP-A TAT",
        title: "PAP-A TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PAP-A OTD status",
        title: "PAP-A OTD status",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FL sent date",
        title: "FL sent date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FL due date",
        title: "FL due date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FL recd date",
        title: "FL recd date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FL TAT",
        title: "FL TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FL OTD",
        title: "FL OTD",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FP due date",
        title: "FP due date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FP delivered date",
        title: "FP delivered date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FP delivered TAT",
        title: "FP delivered TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "FP OTD Status",
        title: "FP OTD Status",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Proof out date",
        title: "Proof out date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Proof out due date",
        title: "Proof out due date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    }
    , {
        field: "Proof corr received date",
        title: "Proof corr received date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Proof out TAT",
        title: "Proof out TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Proof out OTD status",
        title: "Proof out OTD status",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Editor sent date",
        title: "Editor sent date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Editor due date",
        title: "Editor due date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Editor corr received date",
        title: "Editor corr received date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Editor TAT",
        title: "Editor TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Editor OTD status",
        title: "Editor OTD status",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "Collation due date",
        title: "Collation due date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Collation completion date",
        title: "Collation completion date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Collation TAT",
        title: "Collation TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Collation OTD",
        title: "Collation OTD status",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Revises in-date",
        title: "Revises in-date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Revises due date",
        title: "Revises due date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Revises completion date(PM approval date)",
        title: "Revises completion date(PM approval date)",
        minWidnt: 400,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Revises TAT",
        title: "Revises TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Ontime / Delay",
        title: "Revises OTD status",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "PM review TAT",
        title: "PM review TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Preview TAT",
        title: "Preview TAT",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Preview OTD",
        title: "Preview OTD status",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PAP-B due date",
        title: "PAP-B due date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "PAP-B published date",
        title: "PAP-B published date",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    
   
    {
        field: "Overall AT(weeks/days)",
        title: "Article overall TAT(weeks/days)",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Article overall OTD",
        title: "Article overall OTD status",
        minWidnt: 235,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "Volume/Issue No",
        title: "Volume/Issue No",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },

    


    {
        field: "Current Status of the article",
        title: "Current Status of the article",
        minWidnt: 275,
        filter: "text",
        show: true,
        format: ""
    },
      
    {
        field: "Second Proof round",
        title: "Second Proof round",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "ESR OTD",
        title: "ESR OTD",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },

    {
        field: "Delay Category",
        title: "Delay Category",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Delay Remarks",
        title: "Delay Remarks",
        minWidnt: 245,
        filter: "text",
        show: true,
        format: ""
    }

]