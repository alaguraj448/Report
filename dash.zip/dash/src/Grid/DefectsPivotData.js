let DefectPivotData=[{
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Blind manuscript",  
    Defects: 31
    },
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Revised Preview 3" ,
    "Defects":1
    },
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Revises1" ,
    "Defects":6
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Pre-Editing" ,
    "Defects":21
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Editorial proof reading" ,
    "Defects":1
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Preview" ,
    "Defects":5
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Revised Preview" ,
    "Defects":1
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"First Proof" ,
    "Defects":9
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"ELDs" ,
    "Defects":4
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Copy editing" ,
    "Defects":1
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Pre-Editing" ,
    "Defects":5
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Final" ,
    "Defects":3
    }
    ,
    {
    "Month":"April",
    "Country":"US",
    "Customer":"Taylor and Francis",
    "Stages":"Technical Editing",
    "Defects":9
    },
    
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Blind manuscript",  
    Defects: 3
    },
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Revised Preview 3" ,
    "Defects":11
    },
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Revises1" ,
    "Defects":16
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Pre-Editing" ,
    "Defects":2
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Editorial proof reading" ,
    "Defects":11
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Preview" ,
    "Defects":15
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Revised Preview" ,
    "Defects":10
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"First Proof" ,
    "Defects":19
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"ELDs" ,
    "Defects":14
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Copy editing" ,
    "Defects":11
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Pre-Editing" ,
    "Defects":5
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Final" ,
    "Defects":30
    }
    ,
    {
    "Month":"April",
    "Country":"UK",
    "Customer":"Taylor and Francis",
    "Stages":"Technical Editing",
    "Defects":19
    },
    
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Blind manuscript",  
    Defects: 30
    },
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Revised Preview 3" ,
    "Defects":9
    },
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Revises1" ,
    "Defects":6
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Pre-Editing" ,
    "Defects":23
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Editorial proof reading" ,
    "Defects":11
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Preview" ,
    "Defects":5
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Revised Preview" ,
    "Defects":1
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"First Proof" ,
    "Defects":9
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"ELDs" ,
    "Defects":20
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Copy editing" ,
    "Defects":1
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Pre-Editing" ,
    "Defects":50
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Final" ,
    "Defects":3
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"Technical Editing",
    "Defects":9
    },
    
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Blind manuscript",  
    Defects: 3
    },
    {
    "Month":"April",
    "Country":"Dove",
    "Customer":"Taylor and Francis",
    "Stages":"Revised Preview 3" ,
    "Defects":29
    },
    {
    "Month":"April",
    "Country":"Dove",
    "Customer":"Taylor and Francis",
    "Stages":"Revises1" ,
    "Defects":3
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Pre-Editing" ,
    "Defects":3
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Editorial proof reading" ,
    "Defects":1
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Preview" ,
    "Defects":15
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Revised Preview" ,
    "Defects":12
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Taylor and Francis",
    "Stages":"First Proof" ,
    "Defects":9
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"ELDs" ,
    "Defects":2
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Copy editing" ,
    "Defects":13
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Pre-Editing" ,
    "Defects":5
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Final" ,
    "Defects":31
    }
    ,
    {
    "Month":"April",
    "Country":"New Zealand",
    "Customer":"Dove",
    "Stages":"Technical Editing",
    "Defects":19
    },
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    ]