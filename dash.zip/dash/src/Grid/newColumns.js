export const new_column= [
    { 
        field: "ID", 
        title: "SI.No.", 
        minWidnt: 135,
        filter:"text",
        show:false ,
        format:""
    },
    { 
        field: "Process", 
        title: "", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
   {   
        field: "MonthlyPlan", 
        title: "Monthly Plan", 
        minWidnt: 140,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "MTDPlan", 
        title: "MTD Plan", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "MTDActual", 
        title: "MTD Actual", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "MTDVar", 
        title: "MTD Variant", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "MTDAchPer", 
        title: "MTD Achv %", 
        minWidnt: 137,
        filter:"text",
        show:true ,
        format:""
    },
    {   
        field: "QtrlyPlan", 
        title: "Qtrly Plan", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "QTDPlan", 
        title: "QTD Plan", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "QTDActual", 
        title: "QTD Actual", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "QTDVar", 
        title: "QTD Variant", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "QTDAchPer", 
        title: "QTD Achv %", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    {   
        field: "YearlyPlan", 
        title: "Yearly Plan", 
        minWidnt:135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "YTDPlan", 
        title: "YTD Plan", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "YTDActual", 
        title: "YTD Actual", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "YTDVar", 
        title: "YTD Variant", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    },
    { 
        field: "YTDAchPer", 
        title: "YTD Achv %", 
        minWidnt: 135,
        filter:"text",
        show:true ,
        format:""
    }
]