export const FullDetail_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    
    {
        field: "Acronym",
        title: "Acronym",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "Issue",
        title: "Issue",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Production_Editor",
        title: "Production Editor",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Media",
        title: "Media",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Issue_Status",
        title: "Issue Status",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Status",
        title: "Status",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    
  
    {
        field: "O_Publish_Plan",
        title: "O_Publish Plan",
        minWidnt: 190,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "O_Publish_Estimate",
        title: "O_Publish Estimate",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "O_Publish_Actual",
        title: "O_Publish Actual",
        minWidnt: 200,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "P_Ship_Plan",
        title: "P_Ship Plan",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "P_Ship_Estimate",
        title: "P_Ship Estimate",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "P_Ship_Actual",
        title: "P_Ship Actual",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "Notes",
        title: "Notes",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
      
    
   
]