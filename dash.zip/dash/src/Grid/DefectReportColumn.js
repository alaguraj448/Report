export const DefectReport_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    
    {
        field: "Error Category",
        title: "Error Category",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    
    {
        field: "Month",
        title: "Month",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Complaint No",
        title: "Complaint No.",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Complaint Date",
        title: "Complaint Date",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Book Code",
        title: "Book Code",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Customer Name",
        title: "Customer Name",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    
  
    {
        field: "Stage Name",
        title: "Stage Name",
        minWidnt: 190,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "DU",
        title: "DU",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Nature of Complaint",
        title: "Nature of Complaint",
        minWidnt: 200,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Process",
        title: "Process",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Error Type",
        title: "Error Type",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Employee",
        title: "Employee",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "Severity",
        title: "Severity",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }, {
        field: "Repetitive Error",
        title: "Repetitive Error",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
    , {
        field: "Status",
        title: "Status",
        minWidnt: 185,
        filter: "text",
        show: true,
        format: ""
    }
    
   
]