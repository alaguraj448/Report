import React from "react";
import '../App.css';

import { ComboBox } from '@progress/kendo-react-dropdowns'
import {
    Chart,
    ChartArea,
    ChartTitle,
    ChartSeries,
    ChartSeriesItem,
    ChartSeriesLabels,
    ChartCategoryAxis,
    ChartCategoryAxisTitle,
    ChartCategoryAxisItem,
    ChartValueAxis,
    ChartValueAxisItem,
    ChartValueAxisTitle,
    ChartLegend,
    exportVisual
} from '@progress/kendo-react-charts';

import 'hammerjs';
import { exportPDF } from '@progress/kendo-drawing';
import { Button } from '@progress/kendo-react-buttons';
import { exportImage } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { DropDownList } from '@progress/kendo-react-dropdowns';




export default class ViewChart extends React.Component {

    constructor(props) {
        super(props);
        // this.getData = this.props.getData()
        this.state =
        {
            // data: [...data],
            chartType: "column",
            viewGrid: false,
            jsonData: [],
            title: "",
            categories: [],
            chartDatavalue: [],
            json: [],
            sort: [],
            categoryField: "",
            fieldname: "",
            categorykey: "",
            categorykey2: "",
            charts: [], /*["area","bar","boxPlot","bubble","bullet","donut","funnel","line","pie","polar","radar","rangeArea","rangeBar","scatter","waterfall"] this are the available chart type need to transfer data accordingly */
            sortingOrder: "Sort Descending by Alphabet",
            Sort: true,
            drillChartToGrid: [],
            IsDrillChart: false,
            isLoading: false,
            fieldName: ["Budget", "Actuals", "Variance"],
            //sample data for donut chart
        }

    }
    componentDidMount = () => {
        //while component mounting itself data are set to state
        debugger
        //   console.log("plese",this.props.chartData)
        if (this.props.navopen) {
            document.getElementById('chart-bordy').style.left = "120px";
            document.getElementById('chart-bordy').style.marginLeft = "83px"
        }

        if (this.props.chartData) {
            this.setState({ charts: ["column", "area", "line", "bar"] })
            this.setState({ jsonData: this.props.chartData })
            //Here we had just separated data and value for drawing charts, so the fields which need to be compare are separated as name and data
            setTimeout(() => {
                let Budget = this.state.jsonData.map(item => item.Budget)
                let Actuals = this.state.jsonData.map(item => item.Actuals)
                let Variance = this.state.jsonData.map(item => item.Variance)

                this.setState({
                    json: [{
                        name: "Budget",
                        data: Budget
                    }, {
                        name: "Actuals",
                        data: Actuals
                    },
                    {
                        name: "Variance",
                        data: Variance
                    }
                    ]
                })
                this.categories();
                // console.log(this.state.json)
            }, 100);

            this.setState({ yaxisname: "", xaxisname: "" })


        }


    }

    sorting = () => {
        //sorting the chart data alphabetically
        debugger
        this.setState({ ascValue: '', descValue: '' })
        this.setState({ Sort: !this.state.Sort })

        setTimeout(() => {
            if (this.state.Sort === true) {
                this.setState({ sortingOrder: "Sort Descending by Alphabet" })
                if (this.state.categorykey === "ID") {
                    this.state.jsonData.sort((a, b) => {

                        let fa = a[this.state.categorykey2].toLowerCase(),
                            fb = b[this.state.categorykey2].toLowerCase();
                        if (fa < fb) {
                            return -1;
                        }
                        if (fa > fb) {
                            return 1;
                        }
                        return 0;
                    })
                }
                else {
                    this.state.jsonData.sort((a, b) => {

                        let fa = a[this.state.categorykey].toLowerCase(),
                            fb = b[this.state.categorykey].toLowerCase();
                        if (fa < fb) {
                            return -1;
                        }
                        if (fa > fb) {
                            return 1;
                        }
                        return 0;
                    })
                }

            }

            else {
                this.setState({ sortingOrder: "Sort Ascending by Alphabet" })
                if (this.state.categorykey === "ID") {
                    this.state.jsonData.sort((a, b) => {
                        let fa = a[this.state.categorykey2].toLowerCase(),
                            fb = b[this.state.categorykey2].toLowerCase();
                        if (fa > fb) {
                            return -1;
                        }
                        if (fa < fb) {
                            return 1;
                        }
                        return 0;
                    });
                }
                else {
                    this.state.jsonData.sort((a, b) => {
                        let fa = a[this.state.categorykey].toLowerCase(),
                            fb = b[this.state.categorykey].toLowerCase();
                        if (fa > fb) {
                            return -1;
                        }
                        if (fa < fb) {
                            return 1;
                        }
                        return 0;
                    });
                }
            }
        }, 100);

        setTimeout(() => {
            let Budget = this.state.jsonData.map(item => item.Budget)
            let Actuals = this.state.jsonData.map(item => item.Actuals)
            let Variance = this.state.jsonData.map(item => item.Variance)

            this.setState({
                json: [{
                    name: "Budget",
                    data: Budget
                }, {
                    name: "Actuals",
                    data: Actuals
                },
                {
                    name: "Variance",
                    data: Variance
                }
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

        this.setState({ yaxisname: "", xaxisname: "" })
    }

    onPDFExportClick = () => {
        //export the chart as PDF
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportPDF(chartVisual, {
                paperSize: "A2",
                landscape: true
            }).then(dataURI => saveAs(dataURI, "GroupSummaryQTR"));
        }
    }

    onImageExportClick = () => {
        //export the chart as image
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportImage(chartVisual).then(dataURI => saveAs(dataURI, "GroupSummaryQTR"));
        }
    }

    categories = () => {
        //this method used to set, on what basics the chart to be view (to set category)
        debugger

        var categories = []
        let key = Object.keys(this.state.jsonData[0]);
        this.setState({ categorykey: key[0] })
        this.setState({ categorykey2: key[1] })
        // console.log(this.state.categorykey);


        this.state.jsonData.map((item, i) => {
            if (this.state.categorykey === 'ID') {
                return (categories.push(item[this.state.categorykey2]))
            }
            return (categories.push(item[this.state.categorykey]))

        })


        this.setState({ categories: categories })


    }
    labelContent = (e) => {
        //for label for chart
        if (e.value !== 0) {
            return (e.value);
        }
        else {
            return ("")
        }

    }



    changeChart = (value) => {
        //used to set the chart type
        this.setState({ chartType: value })
    }

    viewGrid = () => {
        debugger
        if (document.getElementById('chart-bordy').style.left === "120px") {
            this.setState({ chartnavopen: true })
        }
       
        setTimeout(() => {
            this.props.chartDatafunc(this.state.chartnavopen)
        }, 100);


    }
    rotateChart = () => {
        //rotate the column and bar chart
        if (this.state.chartType === "column") {
            this.setState({ chartType: "bar" })
        }
        else if (this.state.chartType === "bar") {
            this.setState({ chartType: "column" })
        }
    }
    sortAscending = (e) => {
        this.setState({ ascValue: e.target.value })
        this.setState({ descValue: "" });
        if (e.target.value === "Budget") {
            this.state.jsonData.sort((a, b) => {
                return a.Budget - b.Budget;
            });
        }
        else if (e.target.value === "Actuals") {
            this.state.jsonData.sort((a, b) => {
                return a.Actuals - b.Actuals;
            });
        }
        else if (e.target.value === "Variance") {
            this.state.jsonData.sort((a, b) => {
                return a.Variance - b.Variance;
            });
        
     
        }
        setTimeout(() => {
            let Budget = this.state.jsonData.map(item => item.Budget)
            let Actuals = this.state.jsonData.map(item => item.Actuals)
            let Variance = this.state.jsonData.map(item => item.Variance)

            this.setState({
                json: [{
                    name: "Budget",
                    data: Budget
                }, {
                    name: "Actuals",
                    data: Actuals
                },
                {
                    name: "Variance",
                    data: Variance
                }
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

    }
    sortDescending = (e) => {
        this.setState({ descValue: e.target.value });
        this.setState({ ascValue: "" })
        if (e.target.value === "Budget") {
            this.state.jsonData.sort((a, b) => {
                return b.Budget - a.Budget;
            });
        }
        else if (e.target.value === "Actuals") {
            this.state.jsonData.sort((a, b) => {
                return b.Actuals - a.Actuals;
            });
        }
        else if (e.target.value === "Variance") {
            this.state.jsonData.sort((a, b) => {
                return b.Variance - a.Variance;
            });
        
       
        }
        setTimeout(() => {
            let Budget = this.state.jsonData.map(item => item.Budget)
            let Actuals = this.state.jsonData.map(item => item.Actuals)
            let Variance = this.state.jsonData.map(item => item.Variance)

            this.setState({
                json: [{
                    name: "Budget",
                    data: Budget
                }, {
                    name: "Actuals",
                    data: Actuals
                },
                {
                    name: "Variance",
                    data: Variance
                }
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

    }
    //loader for chart
    loadingPanel = (
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );


    render() {
        return (


            <div className='chart-bordy' id="chart-bordy">
                {(this.state.isLoading) && (this.loadingPanel)}
                <div>
                    <div className="chartheader">  <p className="Charttype" data-toggle="tooltip" title="Chart Type">Chart Type</p>

                        <DropDownList data={this.state.charts} defaultValue="column" value={this.state.chartType} onChange={(event) => { this.changeChart(event.target.value) }} />
                        {this.state.chartType === "column" || this.state.chartType === "bar" ? <Button title="Rotate" primary={true} onClick={this.rotateChart}>Rotate</Button> : null}
                        <Button primary={true} title="Export as image" onClick={this.onImageExportClick}>Export as Image</Button>
                        <Button primary={true} title="Export as PDF" onClick={this.onPDFExportClick}>Export as PDF</Button>
                        {
                            this.state.IsDrillChart ? null : <Button primary={true} title="View as grid" onClick={() => this.viewGrid()}>View as Grid</Button>
                        }
                        <Button primary={true} title={this.state.sortingOrder} onClick={() => this.sorting()}>{this.state.sortingOrder}</Button>
                        <div title="Sort ascending by value"><ComboBox
                            style={{ paddingLeft: "5px", width: "177px", height: "52px" }}
                            data={this.state.fieldName}
                            value={this.state.ascValue}
                            onChange={this.sortAscending}
                            placeholder="Sort ascending by value" /></div>
                        <div title="Sort descending by value"><ComboBox
                            style={{ paddingLeft: "5px", width: "185px", height: "52px" }}
                            data={this.state.fieldName}
                            value={this.state.descValue}
                            onChange={this.sortDescending}
                            placeholder="Sort descending by value" /></div>
                    </div>



                    <Chart style={{paddingTop: "20px" }} pannable={true} zoomable={{
                        mousewheel: {
                            lock: "y",
                        },
                        selection: {
                            lock: "y",
                        },
                    }} ref={(cmp) => this._chart = cmp}>
                         <ChartArea  margin={20} width={'1110'}/>
                        <ChartTitle text={this.state.title} />
                        <ChartLegend position="bottom" />
                        <ChartCategoryAxis>

                            <ChartCategoryAxisItem max={4} categories={this.state.categories}>
                                <ChartCategoryAxisTitle text={this.state.yaxisname} font='bold 14px Arial, sans-serif' />
                            </ChartCategoryAxisItem>

                        </ChartCategoryAxis>
                        <ChartValueAxis>
                            <ChartValueAxisItem >
                                <ChartValueAxisTitle text={this.state.xaxisname} font='bold 14px Arial, sans-serif' />
                            </ChartValueAxisItem>
                        </ChartValueAxis>

                        <ChartSeries>
                            {
                                this.state.json.map((item, i) => {
                                    if (i / 2 === 0) {
                                        return (<ChartSeriesItem key={i} type={this.state.chartType} data=
                                            {item.data} name={item.name} tooltip={{ visible: true }}   >
                                            <ChartSeriesLabels content={this.labelContent} />
                                        </ChartSeriesItem>)
                                    }
                                    else {
                                        return (<ChartSeriesItem key={i} type={this.state.chartType} data=
                                            {item.data} name={item.name} tooltip={{ visible: true }}   >
                                            <ChartSeriesLabels content={this.labelContent} />
                                        </ChartSeriesItem>)
                                    }

                                })
                            }


                        </ChartSeries>
                    </Chart>



                </div>

            </div>

        );
    }
}

