export const SPM_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    }
    ,
    {
        field: "SPMName",
        title: "SPM Name",
        minWidnt: 375,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Acronym",
        title: "Acronym",
        minWidnt: 275,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Category",
        title: "Category",
        minWidnt: 275,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Pages",
        title: "Pages",
        minWidnt: 275,
        filter: "text",
        show: true,
        format: ""
    }
]