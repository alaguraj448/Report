import React from "react";
import OUPMasterGrid from './OUPMasterGrid';
import { OUPMaster_column } from './OUPMasterColumn';
import { filterBy } from '@progress/kendo-data-query';

import { DatePicker } from "@progress/kendo-react-dateinputs";
import { IntlProvider, load, LocalizationProvider } from "@progress/kendo-react-intl";
import likelySubtags from "cldr-core/supplemental/likelySubtags.json";
import currencyData from "cldr-core/supplemental/currencyData.json";
import weekData from "cldr-core/supplemental/weekData.json";
import numbers from "cldr-numbers-full/main/es/numbers.json";
import caGregorian from "cldr-dates-full/main/es/ca-gregorian.json";
import dateFields from "cldr-dates-full/main/es/dateFields.json";
import timeZoneNames from "cldr-dates-full/main/es/timeZoneNames.json";
import moment from 'moment';
import { Button } from '@progress/kendo-react-buttons';
import { ComboBox } from '@progress/kendo-react-dropdowns';
import { CustomCalendar } from './customCalender'

import { throwStatement } from "@babel/types";


// import Moment from 'moment';
// import { extendMoment } from 'moment-range';

// const moment = extendMoment(Moment);
load(likelySubtags, currencyData, weekData, numbers, caGregorian, dateFields, timeZoneNames);

let fromdate = new Date();
let todate = new Date();
let toDateCol = new Date();
//todate.setDate(todate.getDate() - 1)
if (fromdate.getDate() === 1) {
    fromdate.setDate(2);
    fromdate.setMonth(fromdate.getMonth() - 1)
    //todate=fromdate
}
else {

    fromdate.setDate(1);
    // todate=fromdate

}
let todatemax = new Date();
let todatemin = new Date();
//todate.setDate(todate.getDate() - 1)
if (todatemax.getDate() === 1) {
    todatemax.setDate(1);
    todatemax.setMonth(todatemax.getMonth() - 1)
    //todate=fromdate
}
else {

    todatemax.setDate(1);
    // todate=fromdate

}
let max = new Date(), min = new Date()
max = new Date(max.getFullYear(), max.getMonth() + 1, 0);

min.setMonth(min.getMonth() - 5)
min.setDate(1);
let frommax = new Date(), frommin = new Date()
// frommax = new Date(frommax.getFullYear(), frommax.getMonth() + 1, 0);

frommin.setMonth(frommin.getMonth() - 5)
frommin.setDate(1);
let tomax = new Date(), tomin = new Date()
// frommax = new Date(frommax.getFullYear(), frommax.getMonth() + 1, 0);

tomin.setMonth(tomin.getMonth() - 5)
tomin.setDate(1);
class OUPMaster extends React.Component {
    locale = {
        language: "en-US",
        locale: "en"
    }
    state = {
        columns: OUPMaster_column,
        aggregates: [],
        FullDetail: false,
        input: {

            "Filter1":  moment(fromdate).format('YYYY-MM-DD'),
            "Filter2": moment(todate).format('YYYY-MM-DD'),
            "Filter3": "",
            "Filter4": "",
            "Filter5": ""



        },
        callGrid: true,
        callAgain: false,
        callchart: false,
        call: true,
        callchartAgain: false,
        callfulldrillGrid: true,
        callfulldrillAgain: false,
        isDrill: false,
        fromdate: fromdate,
        todate: todate,


    }

    componentWillMount = () => {


        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    componentDidMount() {
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });

            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }


    }
    changeToStuff = (date) => {
        this.setState({ todate: date })
        if (date !== null) {
            let input = this.state.input, to = new Date();
            input["Filter2"] = moment(date).format('YYYY-MM-DD')

            this.setState({ maintainto: date })
            setTimeout(() => {
                to.setDate(this.state.todate.getDate())
                to.setMonth(this.state.todate.getMonth())
                to.setFullYear(this.state.todate.getFullYear())
                this.setState({
                    todatecol: moment(this.state.todate).format('YYYY-MM-DD'),
                    input: input,
                    todatecheckyear: date.getFullYear(),
                    todatecheckmonth: date.getMonth(),
                    todatecheckdate: date.getDate()
                })
            }, 200);
        }

    }
    changeFromStuff = (date) => {
        debugger
        this.setState({ fromdate: date })

        if (date !== null) {
            // tomax = new Date(date)
            // let current = new Date()
            // tomax.setDate(tomax.getDate() + 30)
            // let tochecktomax = moment(tomax).format('YYYY-MM-DD')
            // let tocheckcurrent = moment(current).format('YYYY-MM-DD')
            // if (moment(tochecktomax)
            //     .isAfter(tocheckcurrent)) {
            //     tomax = new Date();
            //     this.setState({ todate: tomax })
            // }
            // else {
            //     this.setState({ todate: tomax })
            // }
            // tomin.setDate(date.getDate())
            // tomin.setMonth(date.getMonth())
            // tomin.setFullYear(date.getFullYear())

            let input = this.state.input,

                fromdate = new Date();
            input["Filter1"] = moment(date).format('YYYY-MM-DD')
            input["Filter2"] = moment(tomax).format('YYYY-MM-DD')


            this.setState({ maintainfrom: date })

            setTimeout(() => {
                fromdate.setDate(this.state.fromdate.getDate())
                fromdate.setMonth(this.state.fromdate.getMonth())
                fromdate.setFullYear(this.state.fromdate.getFullYear())
                this.setState({
                    fromdatecol: moment(this.state.fromdate).format('YYYY-MM-DD'),
                    todatecol: moment(tomax).format('YYYY-MM-DD'),
                    input: input,

                    fromdatecheckyear: date.getFullYear(),
                    fromdatecheckmonth: date.getMonth(),
                    fromdatecheckdate: date.getDate()
                })

            }, 200);
        }
    }
    render() {

        let grid = (
            <div className="OTD">
                <OUPMasterGrid title={"Master Report"} navopen={this.state.navopen} isDrill={this.isDrill} FullDetail={false}
                    gridsearchValue={this.state.gridsearchValue} FalseIsComing={this.FalseIsComing} lastUpdatedate={this.lastUpdatedate} Griddata={this.state.Griddata}
                    isComing={this.state.isComing} name={this.state.name} input={this.state.input} columns={this.state.columns}
                    aggregates={this.state.aggregates} chart={this.state.chartData} chartData={this.chartData} fromdate={this.state.fromdate} todate={this.state.todate} /></div>


        )

        return (

            this.state.callchart === false && this.state.isDrill === false && this.state.FullDetail === false ?


                <div className='move-grid-container' id='grid-container'>
                    <div className="Multiselect">
                    <div className="inn">Apply filter : 
                        <LocalizationProvider language={this.locale.language}>
                            <IntlProvider locale={this.locale.locale}>
                                <label className="k-form-field">
                                    <span className="CCToDate">From Date : </span>
                                    <DatePicker
                                                    title="From Date"
                                                    value={this.state.fromdate}
                                                    min={frommin}
                                                    max={todate}
                                                    onChange={
                                                        (e) => {
                                                            let value = e.target.value
                                                            this.changeFromStuff(value)
                                                        }
                                                    }
                                                    format="yyyy/MM/dd"

                                                />
                                                    

                                </label>                             </IntlProvider>
                        </LocalizationProvider>



                        <LocalizationProvider language={this.locale.language}>
                            <IntlProvider locale={this.locale.locale}>
                                <label className="k-form-field">
                                    <span className="CCToDate">To Date : </span>


                                    <DatePicker
                                                    title="To Date"
                                                    value={this.state.todate}
                                                    min={frommin}
                                                    max={todate}
                                                    onChange={
                                                        (e) => {
                                                            let value = e.target.value
                                                            this.changeToStuff(value)
                                                        }
                                                    }
                                                    format="yyyy/MM/dd"

                                                />
                                </label>                             </IntlProvider>
                        </LocalizationProvider>
                        <button className="Go_button" title="Go" onClick={() => {
                            debugger
                                // let todatecheck = moment(this.state.todate).format('YYYY-MM-DD')
                                // let fromdatecheck = moment(this.state.fromdate).format('YYYY-MM-DD')
                                // let from = moment(frommin).format('YYYY-MM-DD')
                                // let to = moment(tomax).format('YYYY-MM-DD')
                                // if (!moment(todatecheck).isBetween(from, to, undefined, '[]')) {
                                //     alert("Please select valid date range")
                                // }
                                // else if (!moment(fromdatecheck).isBetween(from, to, undefined, '[]')) {
                                //     alert("Please select valid date range")
                                // }


                                // else {
                                    if (this.state.todatecheckyear < this.state.fromdatecheckyear) {
                                        alert("To Date should greater than From Date")
                                    }
                                    else if (this.state.todatecheckyear === this.state.fromdatecheckyear) {
                                        if (this.state.fromdatecheckmonth > this.state.todatecheckmonth) {
                                            alert("To Date should greater than From Date")
                                        }
                                        else if (this.state.fromdatecheckmonth === this.state.todatecheckmonth) {
                                            if (this.state.fromdatecheckdate > this.state.todatecheckdate) {
                                                alert("To Date should greater than From Date")
                                            }
                                            else {
                                                debugger
                                             
                                                    this.setState({ changefilter: this.state.Filtername, callGrid: !this.state.callGrid, callAgain: !this.state.callAgain })
                                                
                                            }
                                        }
                                        else {
                                            debugger
                                           
                                                this.setState({ changefilter: this.state.Filtername, callGrid: !this.state.callGrid, callAgain: !this.state.callAgain })
                                            
                                        }
                                    }
                                    else {
                                        debugger
                                         this.setState({ changefilter: this.state.Filtername, callGrid: !this.state.callGrid, callAgain: !this.state.callAgain })
                                      
                                    }
                                // }


                            

                        }}>GO</button>
                        </div>
                    </div>
                    {this.state.callGrid && (grid)}
                    {this.state.callAgain && (grid)}
                </div>


                : null
        );


    }
}

export default OUPMaster;