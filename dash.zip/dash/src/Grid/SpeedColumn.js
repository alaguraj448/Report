export const Speed_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "Descriptions",
        title: "Article mean speed this month",
        minWidnt: 315,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "SPMOnly",
        title: "SPM Only",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "SPMArticles",
        title: "#articles",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "AllArticles",
        title: "All",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    },  {
        field: "Articles",
        title: "#articles",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    }
]