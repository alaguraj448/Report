export const InflowDetail_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "CategoryName",
        title: "Category Name",
        minWidnt: 325,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "RType",
        title: "Report Type",
        minWidnt: 225,
        filter: "text",
        show: true,
        format: ""
    }
    
]