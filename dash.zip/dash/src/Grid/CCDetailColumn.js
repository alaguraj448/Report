export const CCDetail_column = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 175,
        filter: "text",
        show: false,
        format: ""
    },
    {
        field: "JournalName",
        title: "Journal Name",
        minWidnt: 175,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "ArticleJobCardName",
        title: "Jobcard Name",
        minWidnt: 180,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "Track",
        title: "Track",
        minWidnt: 165,
        filter: "text",
        show: true,
        format: ""
    },
    
 
    
    {
        field: "ReceivedDate",
        title: "Received Date",
        minWidnt: 205,
        filter: "date",
        show: true,
        format: "{0:d}"
    },
   
    {
        field: "DespatchDate",
        title: "Despatch Date",
        minWidnt: 205,
        filter: "date",
        show: true,
        format: "{0:d}"
    },

    {
        field: "ProdDespatchDate",
        title: "Product DispatchDate",
        minWidnt: 250,
        filter: "date",
        show: true,
        format: "{0:d}"
    },
   
    {
        field: "score",
        title: "Score",
        minWidnt: 165,
        filter: "text",
        show: true,
        format: ""
    },
    
   
    {
        field:"COPYEDITOR",
        title: "Copy Editor",
        minWidnt: 165,
        filter: "text",
        show: true,
        format: ""
    },
    {
        field: "TatHours",
        title: "CC TAT Hours",
        minWidnt: 195,
        filter: "text",
        show: true,
        format: ""
    }
]