export const Journal_columns = [
    {
        field: "ID",
        title: "SI.No.",
        minWidnt: 185,
        filter: "text",
        show: false,
        format: "",
        date:"no"
    },
    
    {
        field: "Descriptions",
        title: "Descriptions",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    },
    {
        field: "Speed",
        title: "Speed",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
    ,
    {
        field: "Articles",
        title: "Articles",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
    ,
    {
        field: "SocietySpeed",
        title: "Society Speed",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
    ,
    {
        field: "SocietyArticles",
        title: "Society Articles",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }    ,
    {
        field: "OpenAccessSpeed",
        title: "Open Access Speed",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }    ,
    {
        field: "OpenAccessArticles",
        title: "Open Access Articles",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }    ,
    {
        field: "CriticalSpeed",
        title: "Critical Speed",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }    ,
    {
        field: "CriticalArticles",
        title: "Critical Articles",
        minWidnt: 285,
        filter: "text",
        show: true,
        format: "",
        date:"no"
    }
]