import React from "react";
import '../App.css';

import { ComboBox } from '@progress/kendo-react-dropdowns'
import {
    Chart,
    ChartLegendItem,
    ChartArea,
    ChartTitle,
    ChartSeries,
    ChartSeriesItem,
    ChartSeriesLabels,
    ChartCategoryAxis,
    ChartCategoryAxisTitle,
    ChartCategoryAxisItem,
    ChartValueAxis,
    ChartValueAxisItem,
    ChartValueAxisTitle,
    ChartLegend,
    exportVisual
} from '@progress/kendo-react-charts';
import { GridService } from '../services/grid.services'

import 'hammerjs';
import { exportPDF } from '@progress/kendo-drawing';
import { Button } from '@progress/kendo-react-buttons';
import { exportImage } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { DropDownList } from '@progress/kendo-react-dropdowns';
import { Path, Text, Group, geometry, Element, Rect as RectShape } from '@progress/kendo-drawing';

const { Point, Rect, Size } = geometry;

const customVisual = (props) => {
    // Create rectangular shape on top of which the label will be drawn
    const rectOptions = { stroke: { width: 2, color: '#fff' }, fill: { color: '#fff' } };
    const rectGeometry = new Rect(new Point(0, 3), new Size(60, 10));
    const rect = new RectShape(rectGeometry, rectOptions);

    // Create the lines used to represent the custom legend item
    const pathColor = props.options.markers.border.color;
    const path1 = new Path({
        stroke: {
            color: pathColor,
            width: 17,

        }
    });



    // The paths are constructed by using a chain of commands
    path1.moveTo(0, 40).lineTo(40, 40).close();
    // path2.moveTo(15, 7).lineTo(25, 7).close();

    // Create the text associated with the legend item
    const labelText = props.series.name;
    const labelFont = props.options.labels.font;
    const fontColor = props.options.labels.color;
    const textOptions = { font: "400 18px system-ui, -apple-system, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, Liberation Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji", fontSize: "26px", fill: { color: fontColor } };
    const text = new Text(labelText, new Point(50, 28), textOptions);

    // Place all the shapes in a group
    const group = new Group();

    group.append(rect, path1, text);
    // set opacity if the legend item is disabled
    if (!props.active) {
        group.opacity(0.5);
    }

    return group;
}


const chartBootstrapV4Colors = ['#5cb85c', '#FF0000', '#FFFFA7'];
let prevyear = new Date();
prevyear = prevyear.getFullYear() - 1;
let currentyear = new Date()
currentyear = currentyear.getFullYear()
export default class ViewChart extends React.Component {

    constructor(props) {
        super(props);
        // this.getData = this.props.getData()
        this.state =
        {
            // data: [...data],
            chartType: "column",
            viewGrid: false,
            jsonData: [],
            title: "",
            categories: [],
            navopen: this.props.navopen,
            chartDatavalue: [],
            json: [],
            json2: [],

            sort: [],
            input: [this.props.detailinput],
            callchart: true,
            categoryField: "",
            fieldname: "",
            categorykey: "",
            categorykey2: "",
            charts: [], /*["area","bar","boxPlot","bubble","bullet","donut","funnel","line","pie","polar","radar","rangeArea","rangeBar","scatter","waterfall"] this are the available chart type need to transfer data accordingly */
            sortingOrder: "Sort Descending by Alphabet",
            Sort: true,
            drillChartToGrid: [],
            IsDrillChart: false,
            isLoading: false,
            fieldName: [],
            refreshChart: false
            //sample data for donut chart
        }

    }
    componentDidMount = () => {
        //while component mounting itself data are set to state
        debugger
        // let legends=Object.keys(this.props.chartData[0])
        // console.log(legends)
        //   console.log("plese",this.props.chartData)
        if (this.props.navopen) {
            document.getElementById('chart-container').style.marginLeft = "150px";

            document.getElementById('chart-bordy').style.left = "120px";

        }

        this.setState({ charts: ["column", "bar"], isLoading: true })

        GridService.IssueChart(this.props.chartGridInput).then(response => {
            let d = response
            let dat = JSON.parse(d.response);

            this.setState({
                Prevtarget: dat.Table[0].PrevTarget,
                PrevActual: dat.Table[0].PrevActual,
                PrevPlan: dat.Table[0].PrevPlan,
                PrevPub: dat.Table[0].PrevPub,
                YTDPlan: dat.Table[0].YTDPlan,
                YTDPub: dat.Table[0].YTDPub,
                MTDPlan: dat.Table[0].MTDPlan,
                MTDPub: dat.Table[0].MTDPub,
                currentTarget: dat.Table[0].CurrentTarget,
                CurrentActual: dat.Table[0].CurrentActual,
                MTDActual: dat.Table[0].MTDActual,
                MTDTarget: dat.Table[0].MTDTarget,

            })
            setTimeout(() => {
                this.setState({
                    Prevtarget: this.state.Prevtarget.toFixed(Math.max(((this.state.Prevtarget + '').split(".")[1] || "").length, 2)),
                    PrevActual: this.state.PrevActual.toFixed(Math.max(((this.state.PrevActual + '').split(".")[1] || "").length, 2)),
                    currentTarget: this.state.currentTarget.toFixed(Math.max(((this.state.currentTarget + '').split(".")[1] || "").length, 2)),
                    CurrentActual: this.state.CurrentActual.toFixed(Math.max(((this.state.CurrentActual + '').split(".")[1] || "").length, 2)),
                    MTDActual: this.state.MTDActual.toFixed(Math.max(((this.state.MTDActual + '').split(".")[1] || "").length, 2)),
                    MTDTarget: this.state.MTDTarget.toFixed(Math.max(((this.state.MTDTarget + '').split(".")[1] || "").length, 2)),
                })
            }, 100);
            GridService.IssueChart(this.props.input).then(response => {
                let d = response
                let dat = JSON.parse(d.response);
                let data = dat.Table
                this.setState({ jsonData: data, isLoading: false, refreshChart: true })
                //Here we had just separated data and value for drawing charts, so the fields which need to be compare are separated as name and data
                setTimeout(() => {
                    let Ontime = this.state.jsonData.map(item => item.Ontime)
                    let Late = this.state.jsonData.map(item => item.Late)
                    let StillToPublish = this.state.jsonData.map(item => item.StillToPublish)
                    let Ontimeno = this.state.jsonData.map(item => item.OntimeNos)
                    let Lateno = this.state.jsonData.map(item => item.LateNos)
                    let StillToPublishno = this.state.jsonData.map(item => item.StillToPublishNos)
                    if (this.props.title === "Issue Publication - Month Wise") {
                        let lastUpdate = this.state.jsonData[0].LastUpdatedOn
                        this.props.lastUpdatedate(lastUpdate)
                    }


                    this.setState({
                        json: [{
                            name: "Ontime",
                            data: Ontimeno,
                            seriesVisible: true
                        }, {
                            name: "Late",
                            data: Lateno,
                            seriesVisible: true
                        }, {
                            name: "Still To Publish",
                            data: StillToPublishno,
                            seriesVisible: true
                        }
                        ]
                    })
                    // this.setState({
                    //     json: [{
                    //         name: "Ontime",
                    //         data: Ontimeno
                    //     },{
                    //         name: "Late",
                    //         data: Late
                    //     }, {
                    //         name: "Still To Publish",
                    //         data: StillToPublish
                    //     }
                    //     ]
                    // })
                    this.categories();
                    // console.log(this.state.json)
                }, 100);
                setTimeout(() => {
                    this.setState({ refreshChart: false })
                }, 200);
                this.setState({ yaxisname: "", xaxisname: "" })

            }).catch(err => {
                console.log("error", err)
                this.setState({ isLoading: false })

            });
        }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false })

        });




    }

    onPDFExportClick = () => {
        //export the chart as PDF
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportPDF(chartVisual, {
                paperSize: "A2",
                landscape: true
            }).then(dataURI => saveAs(dataURI, this.props.fileName));
        }
    }

    onImageExportClick = () => {
        //export the chart as image
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportImage(chartVisual).then(dataURI => saveAs(dataURI, this.props.fileName));
        }
    }

    categories = () => {
        //this method used to set, on what basics the chart to be view (to set category)
        debugger

        var categories = []



        this.state.jsonData.map((item, i) => {

            return (categories.push(item['Mon']))

        })


        this.setState({ categories: categories })


    }
    labelContent = (e) => {
        //for label for chart
        if (e.value !== 0) {
            return (e.value);
        }
        else {
            return ("")
        }

    }



    changeChart = (value) => {
        //used to set the chart type
        this.setState({ chartType: value, refreshChart: true })
        setTimeout(() => {
            this.setState({ refreshChart: false })
        }, 200);
    }

    viewGrid = () => {
        debugger
        if (document.getElementById('chart-bordy').style.left === "120px") {
            this.setState({ chartnavopen: true })
        }

        setTimeout(() => {
            this.props.chartDatafunc(this.state.chartnavopen, this.props.fromdate, this.props.todate)
        }, 100);


    }
    rotateChart = () => {
        //rotate the column and bar chart
        if (this.state.chartType === "column") {
            this.setState({ chartType: "bar", refreshChart: true })
        }
        else if (this.state.chartType === "bar") {
            this.setState({ chartType: "column", refreshChart: true })
        }
        setTimeout(() => {
            this.setState({ refreshChart: false })
        }, 200);
    }

    //loader for chart
    loadingPanel = (
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );


    handleChartRefresh = (chartOptions, themeOptions, chartInstance) => {
        if (this.state.refreshChart) {
            chartInstance.setOptions(chartOptions, themeOptions);
        }
    };
    func = (e) => {
        this.setState({ refreshChart: true })
        let newjson = this.state.json
        newjson.map((i) => {

            if (i.name === e.text) {
                if (i.seriesVisible === true) {
                    // console.log(i.name,e.text)
                    i.seriesVisible = false
                }

                else {
                    i.seriesVisible = true
                }
            }
        })
        this.setState({ json: newjson })

        setTimeout(() => {
            this.setState({ refreshChart: false })
        }, 200);
    }
    render() {
        return (
            <div>
                <table className="table1 mqtable4">
                    <tbody><tr>
                        <th colspan="5">Target {this.state.MTDTarget}% issues to be published by year end</th>
                    </tr>
                        <tr>
                            <td></td>
                            <td>Plan</td>
                            <td>Published</td>
                            <td>Target</td>
                            <td>Actual</td>

                        </tr>
                        <tr>
                            <td>Percentage of {prevyear} issues published</td>
                            <td>{this.state.PrevPlan} </td>
                            <td>{this.state.PrevPub} </td>
                            <td>{this.state.Prevtarget}% </td>
                            <td>{this.state.PrevActual}% </td>

                        </tr>
                        <tr>
                            <td>Percentage of {currentyear} issues published</td>
                            <td>{this.state.YTDPlan} </td>
                            <td>{this.state.YTDPub} </td>
                            <td>{this.state.currentTarget}% </td>
                            <td>{this.state.CurrentActual}% </td>

                        </tr>
                        <tr>
                            <td>Percentage of {currentyear} issue scheduled to-date published</td>
                            <td>{this.state.MTDPlan} </td>
                            <td>{this.state.MTDPub} </td>
                            <td>{this.state.MTDTarget}% </td>
                            <td>{this.state.MTDActual}% </td>

                        </tr>

                    </tbody></table>
                <div className='chart-bordy' id="chart-bordy">
                    {(this.state.isLoading) && (this.loadingPanel)}


                    <div className="ChartBorder">
                    <div className="chartheader">  
                    <h5>{this.props.title}</h5> 
                    <div className="Chartinnerheader"> <DropDownList data={this.state.charts} defaultValue="column" value={this.state.chartType} onChange={(event) => { this.changeChart(event.target.value) }} />
                        {this.state.chartType === "column" || this.state.chartType === "bar" ? <Button title="Rotate" primary={true} onClick={this.rotateChart}>Rotate</Button> : null}
                        <Button primary={true} title="Export as image" onClick={this.onImageExportClick}>Export as Image</Button>
                        <Button primary={true} title="Export as PDF" onClick={this.onPDFExportClick}>Export as PDF</Button>
                        {
                            this.state.IsDrillChart ? null : <Button primary={true} title="View as grid" onClick={() => this.viewGrid()}>View as Grid</Button>
                        }

                   </div> </div>



                    <Chart style={{ height:275,border:"1px solid #DEDEDE",margin:"10px" }}  pannable={true} zoomable={{
                        mousewheel: {
                            lock: "y",
                        },
                        selection: {
                            lock: "y",
                        },
                    }} ref={(cmp) => this._chart = cmp} seriesColors={chartBootstrapV4Colors} onRefresh={this.handleChartRefresh} onLegendItemClick={(e) => { this.func(e) }}  >
                        <ChartArea margin={20} width={'1110'} />
                        {/* <ChartTitle text={this.props.title} /> */}
                        <ChartLegend position="bottom" orientation={'horizontal'}>
                            <ChartLegendItem visual={customVisual} />
                        </ChartLegend>
                        <ChartCategoryAxis>

                            <ChartCategoryAxisItem labels={{
                                rotation: 'auto'
                            }} categories={this.state.categories}>
                                <ChartCategoryAxisTitle text={this.state.yaxisname} font='bold 14px Arial, sans-serif' />
                            </ChartCategoryAxisItem>

                        </ChartCategoryAxis>
                        <ChartValueAxis>
                            <ChartValueAxisItem >
                                <ChartValueAxisTitle text={this.state.xaxisname} font='bold 14px Arial, sans-serif' />
                            </ChartValueAxisItem>
                        </ChartValueAxis>

                        <ChartSeries>
                            {
                                this.state.json.map((item, i) => {

                                    return (<ChartSeriesItem key={i} stack={{
                                        type: "100%",
                                    }} type={this.state.chartType} data=
                                        {item.data} name={item.name} visible={item.seriesVisible} tooltip={{ visible: true }}   >
                                        <ChartSeriesLabels content={this.labelContent} position="center" background="transparent" />
                                    </ChartSeriesItem>)


                                })
                            }



                        </ChartSeries>
                    </Chart>



                </div>
</div>
            </div>


        );
    }
}

