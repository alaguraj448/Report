import React from "react";
import '../App.css';
import { GridService } from '../services/grid.services'

import { ComboBox } from '@progress/kendo-react-dropdowns'
import {
    Chart,
    ChartLegendItem,
    ChartTitle,
    ChartSeries,
    ChartArea,
    ChartSeriesItem,
    ChartSeriesLabels,
    ChartCategoryAxis,
    ChartCategoryAxisTitle,
    ChartCategoryAxisItem,
    ChartValueAxis,
    ChartValueAxisItem,
    ChartValueAxisTitle,
    ChartLegend,
    ChartTooltip,
    exportVisual
} from '@progress/kendo-react-charts';

import 'hammerjs';
import { exportPDF } from '@progress/kendo-drawing';
import { Button } from '@progress/kendo-react-buttons';
import { exportImage } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { DropDownList } from '@progress/kendo-react-dropdowns';
import pptxgen from "pptxgenjs";
import { Path, Text, Group, geometry, Element, Rect as RectShape } from '@progress/kendo-drawing';

const { Point, Rect, Size } = geometry;

const customVisual = (props) => {
            // Create rectangular shape on top of which the label will be drawn
            const rectOptions = { stroke: { width: 2, color: '#fff' }, fill: { color: '#fff' } };
            const rectGeometry = new Rect(new Point(0, 3), new Size(60, 10));
            const rect = new RectShape(rectGeometry, rectOptions);

            // Create the lines used to represent the custom legend item
            const pathColor = props.options.markers.border.color;
            const path1 = new Path({
                stroke: {
                    color: pathColor,
                    width: 17,
                    
                }
            });

           

            // The paths are constructed by using a chain of commands
            path1.moveTo(0, 40).lineTo(40, 40).close();
            // path2.moveTo(15, 7).lineTo(25, 7).close();

            // Create the text associated with the legend item
            const labelText = props.series.name;
            const labelFont = props.options.labels.font;
            const fontColor = props.options.labels.color;
            const textOptions = { font: "400 18px system-ui, -apple-system, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, Liberation Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji",fontSize:"26px", fill: { color: fontColor } };
            const text = new Text(labelText, new Point(50, 28), textOptions);

            // Place all the shapes in a group
            const group = new Group();

            group.append(rect, path1, text);
            // set opacity if the legend item is disabled
            if (!props.active) {
                group.opacity(0.5);
            }

            return group;
}
export default class ViewChart extends React.Component {

    constructor(props) {
        super(props);
        // this.getData = this.props.getData()
        this.state =
        {
            // data: [...data],
            chartType: "column",
            viewGrid: false,
            jsonData: [],
            title: "",
            categories: [],
            chartDatavalue: [],
            json: [],
            sort: [],
            categoryField: "",
            fieldname: "",
            categorykey: "",
            categorykey2: "",
            charts: [], /*["area","bar","boxPlot","bubble","bullet","donut","funnel","line","pie","polar","radar","rangeArea","rangeBar","scatter","waterfall"] this are the available chart type need to transfer data accordingly */
            sortingOrder: "Sort Descending by Alphabet",
            Sort: true,
            drillChartToGrid: [],
            IsDrillChart: false,
            isLoading: false,
            refreshChart:false,
            
            //sample data for donut chart
        }
    }
    componentDidMount = () => {
        //while component mounting itself data are set to state
        debugger
        if (this.props.navopen) {
            document.getElementById('chart-container').style.marginLeft = "150px";

            document.getElementById('chart-bordy').style.left = "120px";
            //document.getElementById('chart-bordy').style.marginLeft = "83px"
        }

        this.setState({ charts: ["column", "area", "line", "bar"], isLoading: true })
        GridService.Ageing(this.props.input).then(response => {
            let d = response
            let dat = JSON.parse(d.response)
            //   console.log(dat)
            this.setState({ jsonData: dat.Table, isLoading: false,refreshChart:true })
            //Here we had just separated data and value for drawing charts, so the fields which need to be compare are separated as name and data

            setTimeout(() => {

                // let FirstProof = this.state.jsonData.map(item => item["First Proof"]===undefined?0:item["First Proof"])
                // let PreEditing = this.state.jsonData.map(item => item["Pre-Editing"]===undefined?0:item["Pre-Editing"])
                // let Preview = this.state.jsonData.map(item => item["Preview"]===undefined?0:item["Preview"])
                //  let TypesetterManuscript=this.state.jsonData.map(item => item["Typesetter Manuscript"]===undefined?0:item["Typesetter Manuscript"])
                let Nos = this.state.jsonData.map(item => item["Nos"])
                let hold = this.state.jsonData.map(item => item["hold"])
                let unhold = this.state.jsonData.map(item => item["unhold"])

                this.setState({
                    json: [
                      
                        {
                            name: "No. of articles on Hold",
                            data: hold,
                            seriesVisible: true
                        }, {
                            name: "No. of articles on Unhold",
                            data: unhold,
                            seriesVisible: true
                        },
                        {
                            name: "Total",
                            data: Nos,
                            seriesVisible: true
                        }

                    ]
                })
                this.categories();
                // console.log(this.state.json)
            }, 100);
            setTimeout(() => {
                this.setState({refreshChart:false}) 
             }, 200);

            this.setState({ yaxisname: "", xaxisname: "" })
        }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false })

        });


    }


    onPDFExportClick = () => {
        //export the chart as PDF
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportPDF(chartVisual, {
                paperSize: "A2",
                landscape: true
            }).then(dataURI => saveAs(dataURI, this.props.title));
        }
    }

    onImageExportClick = () => {
        //export the chart as image
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportImage(chartVisual).then(dataURI => saveAs(dataURI, this.props.title));
        }
    }

    categories = () => {
        //this method used to set, on what basics the chart to be view (to set category)
        debugger

        var categories = []
        debugger
        this.state.jsonData.map((item, i) => {

            return (categories.push(item['last_step']))

        })
        // console.log(categories)



        this.setState({ categories: categories })


    }
    labelContent = (e) => {
        //for label for chart
        if (e.value !== 0) {
            return (e.value );
        }
        else {
            return ("")
        }

    }


    // tooltipRender = (props) => {
    //     //tooltips for chart
    //     if (props.point) {
    //         return props.point.dataItem.stat;
    //     }
    // };

    changeChart = (value) => {
        //used to set the chart type
        this.setState({ chartType: value,refreshChart:true })
        setTimeout(() => {
            this.setState({refreshChart:false}) 
         }, 200);
    }

    viewGrid = () => {
        debugger
        if (document.getElementById('chart-bordy').style.left === "120px") {
            this.setState({ chartnavopen: true })
        }

        setTimeout(() => {
            this.props.chartDatafunc(this.state.chartnavopen, this.props.fromdate, this.props.todate)
        }, 100);
        // }

    }
    rotateChart = () => {
        //rotate the column and bar chart
        if (this.state.chartType === "column") {
            this.setState({ chartType: "bar",refreshChart:true })
        }
        else if (this.state.chartType === "bar") {
            this.setState({ chartType: "column",refreshChart:true })
        }
        setTimeout(() => {
            this.setState({refreshChart:false}) 
         }, 200);
    }

    //loader for chart
    loadingPanel = (
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );
    handleChartRefresh = (chartOptions, themeOptions, chartInstance) => {
        if (this.state.refreshChart) {
          chartInstance.setOptions(chartOptions, themeOptions);
        }
      };
      func = (e) => {
        this.setState({ refreshChart: true })
        let newjson = this.state.json
        newjson.map((i) => {
           
            if (i.name === e.text) {
                if (i.seriesVisible === true) {
                    // console.log(i.name,e.text)
                    i.seriesVisible = false
                }

                else {
                    i.seriesVisible = true
                }
            }
        })
        this.setState({ json: newjson })
       
        setTimeout(() => {
            this.setState({ refreshChart: false })
        }, 200);
    }

    render() {
        return (


            <div className='chart-bordy' id="chart-bordy">
                {(this.state.isLoading) && (this.loadingPanel)}
                <div className="ChartBorder">
                    <div className="chartheader">  
                    <h5>{this.props.title}</h5> 
                    <div className="Chartinnerheader"><DropDownList data={this.state.charts} defaultValue="column" value={this.state.chartType} onChange={(event) => { this.changeChart(event.target.value) }} />
                        {this.state.chartType === "column" || this.state.chartType === "bar" ? <Button title="Rotate" primary={true} onClick={this.rotateChart}>Rotate</Button> : null}
                        <Button primary={true} title="Export as image" onClick={this.onImageExportClick}>Export as Image</Button>
                        <Button primary={true} title="Export as PDF" onClick={this.onPDFExportClick}>Export as PDF</Button>

                        <Button primary={true} title="View as grid" onClick={() => this.viewGrid()}>View as Grid</Button>


                   </div> </div>
                    <div className="chartSectio">

                        <Chart  style={{ height:350,border:"1px solid #DEDEDE",margin:"10px" }}  pannable={true} zoomable={{
                            mousewheel: {
                                lock: "y",
                            },
                            selection: {
                                lock: "y",
                            },
                        }} ref={(cmp) => this._chart = cmp} onRefresh={this.handleChartRefresh} onLegendItemClick={(e) => { this.func(e) }} >
                            <ChartArea  margin={20} width={'1110'}/>
                            <ChartTitle text={this.props.title} />
                            <ChartLegend position="bottom" orientation={'horizontal'}>
          <ChartLegendItem visual={customVisual}/>
        </ChartLegend>
                            <ChartCategoryAxis>

                                <ChartCategoryAxisItem categories={this.state.categories} labels={{
                                    rotation: 'auto'
                                }}>
                                    <ChartCategoryAxisTitle text={this.state.yaxisname} font='bold 14px Arial, sans-serif' />
                                </ChartCategoryAxisItem>

                            </ChartCategoryAxis>
                            <ChartValueAxis>
                                <ChartValueAxisItem >
                                    <ChartValueAxisTitle text={this.state.xaxisname} font='bold 14px Arial, sans-serif' />
                                </ChartValueAxisItem>
                            </ChartValueAxis>

                            <ChartSeries>
                                {
                                    this.state.json.map((item, i) => {
                                    
                                            return (<ChartSeriesItem key={i} type={this.state.chartType} data=
                                                {item.data} name={item.name}visible={item.seriesVisible} tooltip={{ visible: true }}   >
                                                <ChartSeriesLabels content={this.labelContent} />
                                            </ChartSeriesItem>)
                                        

                                    })
                                }


                            </ChartSeries>
                        </Chart>
                    </div>



                </div>

            </div>

        );
    }
}

