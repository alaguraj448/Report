import React from "react";
import '../App.css';
import { GridService } from '../services/grid.services'

import { ComboBox } from '@progress/kendo-react-dropdowns'
import {
    Chart,
    ChartTitle,
    ChartSeries,
    ChartSeriesItem,
    ChartSeriesLabels,
    ChartCategoryAxis,
    ChartCategoryAxisTitle,
    ChartCategoryAxisItem,
    ChartValueAxis,
    ChartValueAxisItem,
    ChartValueAxisTitle,
    ChartLegend,
    ChartTooltip,
    exportVisual
} from '@progress/kendo-react-charts';

import 'hammerjs';
import { exportPDF } from '@progress/kendo-drawing';
import { Button } from '@progress/kendo-react-buttons';
import { exportImage } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { DropDownList } from '@progress/kendo-react-dropdowns';
import pptxgen from "pptxgenjs";

let products1 = [], products2 = [], products3 = [], products4 = [], products5 = []
const ValueTitle = {
    format: "C0",
};

const pieContent = (props) => {
    //label content for pie chart
    let formatedNumber = Number(props.dataItem.value).toLocaleString(undefined, {
        style: "percent",
        minimumFractionDigits: 2,
    });
    return `${props.dataItem.category} years old: ${formatedNumber}`;
};
export default class ViewChart extends React.Component {

    constructor(props) {
        super(props);
        // this.getData = this.props.getData()
        this.state =
        {
            // data: [...data],
            chartType: "column",
            viewGrid: false,
            jsonData: [],
            title: "",
            categories: [],
            chartDatavalue: [],
            json: [],
            sort: [],
            categoryField: "",
            fieldname: "",
            categorykey: "",
            categorykey2: "",
            charts: [], /*["area","bar","boxPlot","bubble","bullet","donut","funnel","line","pie","polar","radar","rangeArea","rangeBar","scatter","waterfall"] this are the available chart type need to transfer data accordingly */
            sortingOrder: "Sort Descending by Alphabet",
            Sort: true,
            drillChartToGrid: [],
            IsDrillChart: false,
            isLoading: false,
            exportALL: {
                "FromDate": "2021/04/01 00:00:00",
                "ToDate": "2022/04/01 00:00:00",
                "GroupID": "4",
                "DivisionId": "",
                "KAMHeadID": "",
                "DUHeadID": "",
                "CountryID": "",
                "CustomerID": "",
                "ReportType": "All",
                "RadioValue": "Target"
            },
            data1: [],
            data2: [],
            data3: [],
            data4: [],
            data5: [],
            chartData1: [],
            chartData2: [],
            chartData3: [],
            chartData4: [],
            chartData5: [],
            columns1: [...this.props.columns1],
            columns2: [...this.props.columns2],
            columns3: [...this.props.columns3],
            columns4: [...this.props.columns4],
            columns5: [...this.props.columns5],
            fieldName: ["MTD Plan", "MTD Actual", "QTD Plan", "QTD Actual", "YTD Plan", "YTD Actual"],
            //sample data for donut chart
            donut: [{
                "kind": "Hydroelectric", "share": 0.175
            }, {
                "kind": "Nuclear", "share": 0.238
            }, {
                "kind": "Coal", "share": 0.118
            }, {
                "kind": "Solar", "share": 0.052
            }, {
                "kind": "Wind", "share": 0.225
            }, {
                "kind": "Other", "share": 0.192
            }],
            //sample data for funnel chart
            funnel: [{
                "stat": "Impressions ",
                "count": 434823,
                "color": "#0e5a7e"
            }, {
                "stat": "Clicks",
                "count": 356854,
                "color": "#166f99"
            }, {
                "stat": "Unique Visitors",
                "count": 280022,
                "color": "#2185b4"
            }, {
                "stat": "Downloads",
                "count": 190374,
                "color": "#319fd2"
            }, {
                "stat": "Purchases",
                "count": 120392,
                "color": "#3eaee2"
            }],
            //sample data for pie chart
            pie: [
                {
                    category: "0-14",
                    value: 0.2545,
                },
                {
                    category: "15-24",
                    value: 0.1552,
                },
                {
                    category: "25-54",
                    value: 0.4059,
                },
                {
                    category: "55-64",
                    value: 0.0911,
                },
                {
                    category: "65+",
                    value: 0.0933,
                },
            ],
            //sample data for waterfall chart
            waterfall: [{
                "period": "Beginning\\nBalance",
                "amount": 50000
            }, {
                "period": "Jan",
                "amount": 17000
            }, {
                "period": "Feb",
                "amount": 14000
            }, {
                "period": "Mar",
                "amount": -12000
            }, {
                "period": "Q1",
                "summary": "runningTotal"
            }, {
                "period": "Apr",
                "amount": -22000
            }, {
                "period": "May",
                "amount": -18000
            }, {
                "period": "Jun",
                "amount": 10000
            }, {
                "period": "Q2",
                "summary": "runningTotal"
            }, {
                "period": "Ending\\nBalance",
                "summary": "total"
            }]



        }

    }
    componentDidMount = () => {
        //while component mounting itself data are set to state
        debugger
        let name = [], single = [], whole = [], obj = [], legends = [], dataChartAreaLine = [], dataChart = [];
        if (this.props.navopen) {
            document.getElementById('chart-bordy').style.left = "120px";
            document.getElementById('chart-bordy').style.marginLeft = "83px"
        }
        if (this.state.IsDrillChart === true && this.props.chartData) {
            this.setState({ charts: ["column", "area", "line", "bar"] })
            this.setState({ jsonData: this.state.drillChartToGrid })
            //Here we had just separated data and value for drawing charts, so the fields which need to be compare are separated as name and data

            setTimeout(() => {
                let MTDPlan = this.state.jsonData.map(item => item.MTDPlan)
                let MTDActual = this.state.jsonData.map(item => item.MTDActual)
                let QTDPlan = this.state.jsonData.map(item => item.QTDPlan)
                let QTDActual = this.state.jsonData.map(item => item.QTDActual)
                let YTDPlan = this.state.jsonData.map(item => item.YTDPlan)
                let YTDActual = this.state.jsonData.map(item => item.YTDActual)
                this.setState({
                    json: [{
                        name: "MTD Plan",
                        data: MTDPlan
                    }, {
                        name: "MTD Actual",
                        data: MTDActual
                    },
                    {
                        name: "QTD Plan",
                        data: QTDPlan
                    },
                    {
                        name: "QTD Actual",
                        data: QTDActual
                    },
                    {
                        name: "YTD Plan",
                        data: YTDPlan
                    },
                    {
                        name: "YTD Actual",
                        data: YTDActual
                    },
                    ]
                })
                this.categories();
                // console.log(this.state.json)
            }, 200);

            this.setState({ yaxisname: "", xaxisname: "" })

        }
        else if (this.props.chartData && this.state.IsDrillChart === false) {
            this.setState({ charts: ["column", "area", "line", "bar"] })
            this.setState({ jsonData: this.props.chartData })
            //Here we had just separated data and value for drawing charts, so the fields which need to be compare are separated as name and data
            setTimeout(() => {
                let MTDPlan = this.state.jsonData.map(item => item.MTDPlan)
                let MTDActual = this.state.jsonData.map(item => item.MTDActual)
                let QTDPlan = this.state.jsonData.map(item => item.QTDPlan)
                let QTDActual = this.state.jsonData.map(item => item.QTDActual)
                let YTDPlan = this.state.jsonData.map(item => item.YTDPlan)
                let YTDActual = this.state.jsonData.map(item => item.YTDActual)
                this.setState({
                    json: [{
                        name: "MTD Plan",
                        data: MTDPlan
                    }, {
                        name: "MTD Actual",
                        data: MTDActual
                    },
                    {
                        name: "QTD Plan",
                        data: QTDPlan
                    },
                    {
                        name: "QTD Actual",
                        data: QTDActual
                    },
                    {
                        name: "YTD Plan",
                        data: YTDPlan
                    },
                    {
                        name: "YTD Actual",
                        data: YTDActual
                    },
                    ]
                })
                this.categories();
                // console.log(this.state.json)
            }, 100);

            this.setState({ yaxisname: "", xaxisname: "" })


        }


        setTimeout(() => {
            legends = this.state.jsonData.map(value => value.Process)
            obj = Object.keys(this.state.jsonData[0]);
            name = obj.filter(word => word === "MTDPlan" || word === "QTDPlan" || word === "YTDPlan" || word === "MTDActual" || word === "QTDActual" || word === "YTDActual");
            let MTDPlan = this.state.jsonData.map(item => item.MTDPlan)
            let MTDActual = this.state.jsonData.map(item => item.MTDActual)
            let QTDPlan = this.state.jsonData.map(item => item.QTDPlan)
            let QTDActual = this.state.jsonData.map(item => item.QTDActual)
            let YTDPlan = this.state.jsonData.map(item => item.YTDPlan)
            let YTDActual = this.state.jsonData.map(item => item.YTDActual)
            whole.push(MTDPlan);
            whole.push(MTDActual)
            whole.push(QTDPlan)
            whole.push(QTDActual)
            whole.push(YTDPlan)
            whole.push(YTDActual)
            // legends.map((j,k)=>{
            //     single=[]
            //     this.state.jsonData.map((d,i)=>{if(d.Process===legends[k]){

            //                     single.push(d.MTDPlan)
            //                     }
            //                     })
            //                    whole.push(single)
            //                 })
            name.map((d, i) => {
                dataChart =

                {

                    name: name[i],

                    labels: legends,

                    values: whole[i],

                }



                dataChartAreaLine.push(dataChart)
            })

        }, 300);
        setTimeout(() => {
          
            this.setState({ pptdata: dataChartAreaLine })
        }, 1000);
    }

    sorting = () => {
        //sorting the chart data alphabetically
        debugger
        this.setState({ ascValue: '', descValue: '' })
        this.setState({ Sort: !this.state.Sort })

        setTimeout(() => {
            if (this.state.Sort === true) {
                this.setState({ sortingOrder: "Sort Descending by Alphabet" })
                if (this.state.categorykey === "ID") {
                    this.state.jsonData.sort((a, b) => {

                        let fa = a[this.state.categorykey2].toLowerCase(),
                            fb = b[this.state.categorykey2].toLowerCase();
                        if (fa < fb) {
                            return -1;
                        }
                        if (fa > fb) {
                            return 1;
                        }
                        return 0;
                    })
                }
                else {
                    this.state.jsonData.sort((a, b) => {

                        let fa = a[this.state.categorykey].toLowerCase(),
                            fb = b[this.state.categorykey].toLowerCase();
                        if (fa < fb) {
                            return -1;
                        }
                        if (fa > fb) {
                            return 1;
                        }
                        return 0;
                    })
                }

            }

            else {
                this.setState({ sortingOrder: "Sort Ascending by Alphabet" })
                if (this.state.categorykey === "ID") {
                    this.state.jsonData.sort((a, b) => {
                        let fa = a[this.state.categorykey2].toLowerCase(),
                            fb = b[this.state.categorykey2].toLowerCase();
                        if (fa > fb) {
                            return -1;
                        }
                        if (fa < fb) {
                            return 1;
                        }
                        return 0;
                    });
                }
                else {
                    this.state.jsonData.sort((a, b) => {
                        let fa = a[this.state.categorykey].toLowerCase(),
                            fb = b[this.state.categorykey].toLowerCase();
                        if (fa > fb) {
                            return -1;
                        }
                        if (fa < fb) {
                            return 1;
                        }
                        return 0;
                    });
                }
            }
        }, 100);

        setTimeout(() => {
            // console.log(this.state.jsonData)
            let MTDPlan = this.state.jsonData.map(item => item.MTDPlan)
            let MTDActual = this.state.jsonData.map(item => item.MTDActual)
            let QTDPlan = this.state.jsonData.map(item => item.QTDPlan)
            let QTDActual = this.state.jsonData.map(item => item.QTDActual)
            let YTDPlan = this.state.jsonData.map(item => item.YTDPlan)
            let YTDActual = this.state.jsonData.map(item => item.YTDActual)
            this.setState({
                json: [{
                    name: "MTD Plan",
                    data: MTDPlan
                }, {
                    name: "MTD Actual",
                    data: MTDActual
                },
                {
                    name: "QTD Plan",
                    data: QTDPlan
                },
                {
                    name: "QTD Actual",
                    data: QTDActual
                },
                {
                    name: "YTD Plan",
                    data: YTDPlan
                },
                {
                    name: "YTD Actual",
                    data: YTDActual
                },
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

        this.setState({ yaxisname: "", xaxisname: "" })
    }

    onPDFExportClick = () => {
        //export the chart as PDF
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportPDF(chartVisual, {
                paperSize: "A2",
                landscape: true
            }).then(dataURI => saveAs(dataURI, "OIReport"));
        }
    }

    onImageExportClick = () => {
        //export the chart as image
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportImage(chartVisual).then(dataURI => saveAs(dataURI, this.state.title));
        }
    }

    categories = () => {
        //this method used to set, on what basics the chart to be view (to set category)
        debugger

        var categories = []
        let key = Object.keys(this.state.jsonData[0]);
        this.setState({ categorykey: key[0] })
        this.setState({ categorykey2: key[1] })
        // console.log(this.state.categorykey);
        if (this.state.categorykey === 'Process') {
            this.state.jsonData.map((item, i) => {

                return (categories.push(item[this.state.categorykey]))

            })
        }
        else {
            this.state.jsonData.map((item, i) => {
                if (this.state.categorykey === 'ID') {
                    return (categories.push(item[this.state.categorykey2]))
                }
                return (categories.push(item[this.state.categorykey]))

            })
        }

        this.setState({ categories: categories })


    }
    labelContent = (e) => {
        //for label for chart
        if (e.value !== 0) {
            return (e.value);
        }
        else {
            return ("")
        }

    }
    pointColor = (point) => {
        //used in waterfall chart type
        let summary = point.dataItem.summary;

        if (summary) {
            return summary === "total" ? "#555" : "gray";
        }

        if (point.value > 0) {
            return "green";
        } else {
            return "red";
        }
    };

    tooltipRender = (props) => {
        //tooltips for chart
        if (props.point) {
            return props.point.dataItem.stat;
        }
    };

    changeChart = (value) => {
        //used to set the chart type
        this.setState({ chartType: value })
    }

    viewGrid = () => {
        debugger
        if (document.getElementById('chart-bordy').style.left === "120px") {
            this.setState({ chartnavopen: true })
        }
        // if (this.state.IsDrillChart) {
        //     setTimeout(() => {
        //         this.props.toGridfromdrillchart(this.state.chartnavopen, true, this.state.drillChartToGrid)
        //     }, 100);
        // }
        // else {
        setTimeout(() => {
            this.props.chartDatafunc(this.state.chartnavopen)
        }, 100);
        // }

    }
    rotateChart = () => {
        //rotate the column and bar chart
        if (this.state.chartType === "column") {
            this.setState({ chartType: "bar" })
        }
        else if (this.state.chartType === "bar") {
            this.setState({ chartType: "column" })
        }
    }
    sortAscending = (e) => {
        this.setState({ ascValue: e.target.value })
        this.setState({ descValue: "" });
        if (e.target.value === "MTD Plan") {
            this.state.jsonData.sort((a, b) => {
                return a.MTDPlan - b.MTDPlan;
            });
        }
        else if (e.target.value === "MTD Actual") {
            this.state.jsonData.sort((a, b) => {
                return a.MTDActual - b.MTDActual;
            });
        }
        else if (e.target.value === "QTD Plan") {
            this.state.jsonData.sort((a, b) => {
                return a.QTDPlan - b.QTDPlan;
            });
        }
        else if (e.target.value === "QTD Actual") {
            this.state.jsonData.sort((a, b) => {
                return a.QTDActual - b.QTDActual;
            });
        }
        else if (e.target.value === "YTD Plan") {
            this.state.jsonData.sort((a, b) => {
                return a.YTDPlan - b.YTDPlan;
            });
        }
        else if (e.target.value === "YTD Actual") {
            this.state.jsonData.sort((a, b) => {
                return a.YTDActual - b.YTDActual;
            });
        }
        setTimeout(() => {
            // console.log(this.state.jsonData)
            let MTDPlan = this.state.jsonData.map(item => item.MTDPlan)
            let MTDActual = this.state.jsonData.map(item => item.MTDActual)
            let QTDPlan = this.state.jsonData.map(item => item.QTDPlan)
            let QTDActual = this.state.jsonData.map(item => item.QTDActual)
            let YTDPlan = this.state.jsonData.map(item => item.YTDPlan)
            let YTDActual = this.state.jsonData.map(item => item.YTDActual)
            this.setState({
                json: [{
                    name: "MTD Plan",
                    data: MTDPlan
                }, {
                    name: "MTD Actual",
                    data: MTDActual
                },
                {
                    name: "QTD Plan",
                    data: QTDPlan
                },
                {
                    name: "QTD Actual",
                    data: QTDActual
                },
                {
                    name: "YTD Plan",
                    data: YTDPlan
                },
                {
                    name: "YTD Actual",
                    data: YTDActual
                },
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

    }
    onPPTExportClick = () => {

        debugger
        let pres = new pptxgen();
        let slide = pres.addSlide();

        slide.addChart(pres.ChartType.bar, this.state.pptdata, { x: 0, y: 0, w: 10, h: 6, showLegend: true, chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });

        pres.writeFile({ fileName: "PptxGenJS-test" });
    }
    onALLPPTExportClick = () => {
        this.setState({ isLoading: true })
        let name = [], whole1 = [], whole2 = [], whole3 = [], whole4 = [], whole5 = [], obj = [], legends1 = [], legends2 = [], legends3 = [], legends4 = [], legends5 = [], dataChartAreaLine = []
            , dataChart1 = [], dataChart2 = [], dataChart3 = [], dataChart4 = [], dataChart5 = [], dataChartAreaLine1 = [], dataChartAreaLine2 = [], dataChartAreaLine3 = [], dataChartAreaLine4 = [], dataChartAreaLine5 = [];
        let setCol = this.state.columns1.find(c => c.field === 'Process')
        GridService.AllGridData(this.state.exportALL).then(response => {
            let d = response
            let data = JSON.parse(d.response)
           
            debugger
            let data1 = data.Table1, data2 = data.Table2, data3 = data.Table3, data4 = data.Table4, data5 = data.Table5;
            let newcol1, newcol2, newcol3, newcol4, newcol5

            if (data1.length > 0) {
                if (data1[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol1 = this.state.columns1.map(c => {

                        if (c.field === 'Process') {
                            c.title = data1[0]['Alias']
                            return c
                        }


                        return c
                    })
                    this.setState({ columns1: newcol1 })
                }
                products1 = data1.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data1: products1, columns1: this.state.columns1
                })
            }
            if (data2.length > 0) {
                if (data2[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol2 = this.state.columns2.map(c => {

                        if (c.field === 'Process') {
                            c.title = data2[0]['Alias']
                            return c
                        }


                        return c
                    })
                    this.setState({ columns2: newcol2 })
                }
                products2 = data2.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data2: products2, columns2: this.state.columns2
                })
            }
            if (data3.length > 0) {
                if (data3[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol3 = this.state.columns3.map(c => {

                        if (c.field === 'Process') {
                            c.title = data3[0]['Alias']
                            return c
                        }


                        return c
                    })
                    this.setState({ columns3: newcol3 })
                }
                products3 = data3.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data3: products3, columns3: this.state.columns3
                })
            }
            if (data4.length > 0) {
                if (data4[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol4 = this.state.columns4.map(c => {

                        if (c.field === 'Process') {
                            c.title = data4[0]['Alias']
                            return c
                        }


                        return c
                    })
                    this.setState({ columns4: newcol4 })
                }
                products4 = data4.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data4: products4, columns4: this.state.columns4
                })
            }
            if (data5.length > 0) {
                if (data5[0]['Alias'] !== undefined && setCol !== undefined) {
                    newcol5 = this.state.columns5.map(c => {

                        if (c.field === 'Process') {
                            c.title = data5[0]['Alias']
                            return c
                        }


                        return c
                    })
                    this.setState({ columns5: newcol5 })
                }
                products5 = data5.map((dataItem, idx) => Object.assign({ ID: idx + 1, selected: false }, dataItem))
                this.setState({
                    data5: products5, columns5: this.state.columns5
                })
            }
            let columnName1 = this.state.columns1,
                columnName2 = this.state.columns2,
                columnName3 = this.state.columns3,
                columnName4 = this.state.columns4,
                columnName5 = this.state.columns5,
                mapData1 = products1, mapData2 = products2, mapData3 = products3, mapData4 = products4, mapData5 = products5
            let sendData1 = mapData1.map(data => {
                let newObject = {}
                columnName1.map(col => newObject[col.field] = data[col.field])
                return newObject
            })
            let sendData2 = mapData2.map(data => {
                let newObject = {}
                columnName2.map(col => newObject[col.field] = data[col.field])
                return newObject
            })
            let sendData3 = mapData3.map(data => {
                let newObject = {}
                columnName3.map(col => newObject[col.field] = data[col.field])
                return newObject
            })
            let sendData4 = mapData4.map(data => {
                let newObject = {}
                columnName4.map(col => newObject[col.field] = data[col.field])
                return newObject
            })
            let sendData5 = mapData5.map(data => {
                let newObject = {}
                columnName5.map(col => newObject[col.field] = data[col.field])
                return newObject
            })

            obj = Object.keys(this.state.jsonData[0]);
            name = obj.filter(word => word === "MTDPlan" || word === "QTDPlan" || word === "YTDPlan" || word === "MTDActual" || word === "QTDActual" || word === "YTDActual");
            legends1 = sendData1.map(value => value.Process)
            let MTDPlan1 = sendData1.map(item => item.MTDPlan)
            let MTDActual1 = sendData1.map(item => item.MTDActual)
            let QTDPlan1 = sendData1.map(item => item.QTDPlan)
            let QTDActual1 = sendData1.map(item => item.QTDActual)
            let YTDPlan1 = sendData1.map(item => item.YTDPlan)
            let YTDActual1 = sendData1.map(item => item.YTDActual)
            whole1.push(MTDPlan1);
            whole1.push(MTDActual1)
            whole1.push(QTDPlan1)
            whole1.push(QTDActual1)
            whole1.push(YTDPlan1)
            whole1.push(YTDActual1)
            name.map((d, i) => {
                dataChart1 =

                {

                    name: name[i],

                    labels: legends1,

                    values: whole1[i],

                }
                dataChartAreaLine1.push(dataChart1)
            })
            legends2 = sendData2.map(value => value.Process)
            let MTDPlan2 = sendData2.map(item => item.MTDPlan)
            let MTDActual2 = sendData2.map(item => item.MTDActual)
            let QTDPlan2 = sendData2.map(item => item.QTDPlan)
            let QTDActual2 = sendData2.map(item => item.QTDActual)
            let YTDPlan2 = sendData2.map(item => item.YTDPlan)
            let YTDActual2 = sendData2.map(item => item.YTDActual)
            whole2.push(MTDPlan2);
            whole2.push(MTDActual2)
            whole2.push(QTDPlan2)
            whole2.push(QTDActual2)
            whole2.push(YTDPlan2)
            whole2.push(YTDActual2)
            name.map((d, i) => {
                dataChart2 =

                {

                    name: name[i],

                    labels: legends2,

                    values: whole2[i],

                }
                dataChartAreaLine2.push(dataChart2)
            })
            legends3 = sendData3.map(value => value.Process)
            let MTDPlan3 = sendData3.map(item => item.MTDPlan)
            let MTDActual3 = sendData3.map(item => item.MTDActual)
            let QTDPlan3 = sendData3.map(item => item.QTDPlan)
            let QTDActual3 = sendData3.map(item => item.QTDActual)
            let YTDPlan3 = sendData3.map(item => item.YTDPlan)
            let YTDActual3 = sendData3.map(item => item.YTDActual)
            whole3.push(MTDPlan3);
            whole3.push(MTDActual3)
            whole3.push(QTDPlan3)
            whole3.push(QTDActual3)
            whole3.push(YTDPlan3)
            whole3.push(YTDActual3)
            name.map((d, i) => {
                dataChart3 =

                {

                    name: name[i],

                    labels: legends3,

                    values: whole3[i],

                }

                dataChartAreaLine3.push(dataChart3)

            })
            legends4 = sendData4.map(value => value.Process)
            let MTDPlan4 = sendData4.map(item => item.MTDPlan)
            let MTDActual4 = sendData4.map(item => item.MTDActual)
            let QTDPlan4 = sendData4.map(item => item.QTDPlan)
            let QTDActual4 = sendData4.map(item => item.QTDActual)
            let YTDPlan4 = sendData4.map(item => item.YTDPlan)
            let YTDActual4 = sendData4.map(item => item.YTDActual)
            whole4.push(MTDPlan4);
            whole4.push(MTDActual4)
            whole4.push(QTDPlan4)
            whole4.push(QTDActual4)
            whole4.push(YTDPlan4)
            whole4.push(YTDActual4)
            name.map((d, i) => {
                dataChart4 =

                {

                    name: name[i],

                    labels: legends4,

                    values: whole4[i],

                }

                dataChartAreaLine4.push(dataChart4)

            })
            legends5 = sendData5.map(value => value.Process)
            let MTDPlan5 = sendData5.map(item => item.MTDPlan)
            let MTDActual5 = sendData5.map(item => item.MTDActual)
            let QTDPlan5 = sendData5.map(item => item.QTDPlan)
            let QTDActual5 = sendData5.map(item => item.QTDActual)
            let YTDPlan5 = sendData5.map(item => item.YTDPlan)
            let YTDActual5 = sendData5.map(item => item.YTDActual)
            whole5.push(MTDPlan5);
            whole5.push(MTDActual5)
            whole5.push(QTDPlan5)
            whole5.push(QTDActual5)
            whole5.push(YTDPlan5)
            whole5.push(YTDActual5)
            name.map((d, i) => {
                dataChart5 =

                {

                    name: name[i],

                    labels: legends5,

                    values: whole5[i],

                }

                dataChartAreaLine5.push(dataChart5)


            })
            dataChartAreaLine.push(dataChartAreaLine1)
            dataChartAreaLine.push(dataChartAreaLine2)
            dataChartAreaLine.push(dataChartAreaLine3)
            dataChartAreaLine.push(dataChartAreaLine4)
            dataChartAreaLine.push(dataChartAreaLine5)



          
            this.setState({ pptdata: dataChartAreaLine })
            let pres = new pptxgen();
            let slide0 = pres.addSlide();
            let slide1 = pres.addSlide();
            let slide2 = pres.addSlide();
            let slide3 = pres.addSlide();
            let slide4 = pres.addSlide();
            let slide5 = pres.addSlide();
            let slide6 = pres.addSlide();
            let slide7 = pres.addSlide();
            let slide8 = pres.addSlide();
            let slide9 = pres.addSlide();
          
            slide0.addChart(pres.ChartType.bar, this.state.pptdata[0], { x: 0, y: 0, w: 10, h: 4, showLegend: true, showTitle: true, title: "By Entity", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });
            slide1.addChart(pres.ChartType.bar, this.state.pptdata[0], { x: 0, y: 0, w: 10, h: 4, showLegend: true, showValue: true, showTitle: true, title: "By Entity", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });
            slide2.addChart(pres.ChartType.bar, this.state.pptdata[1], { x: 0, y: 0, w: 10, h: 4, showLegend: true, showTitle: true, title: "By Function", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });

            slide3.addChart(pres.ChartType.bar, this.state.pptdata[1], { x: 0, y: 0, w: 10, h: 4, showLegend: true, showValue: true, showTitle: true, title: "By Function", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });
            slide4.addChart(pres.ChartType.bar, this.state.pptdata[2], { x: 0, y: 0, w: 10, h: 4, showLegend: true, showTitle: true, title: "By KAM", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });

            slide5.addChart(pres.ChartType.bar, this.state.pptdata[2], { x: 0, y: 0, w: 10, h: 4, showLegend: true, showValue: true, showTitle: true, title: "By KAM", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });
            slide6.addChart(pres.ChartType.bar, this.state.pptdata[3], { x: 0, y: 0, w: 10, h: 4, showLegend: true,  showTitle: true, title: "By DU", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });


            slide7.addChart(pres.ChartType.bar, this.state.pptdata[3], { x: 0, y: 0, w: 10, h: 4, showLegend: true, showValue: true, showTitle: true, title: "By DU", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });
            slide8.addChart(pres.ChartType.bar, this.state.pptdata[4], { x: 0, y: 0, w: 10, h: 4, showLegend: true,  showTitle: true, title: "Top 15 Customers", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });

            slide9.addChart(pres.ChartType.bar, this.state.pptdata[4], { x: 0, y: 0, w: 10, h: 4, showLegend: true, showValue: true, showTitle: true, title: "Top 15 Customers", chartColors: ['0275D8', '5BC0DE', '5CB85C', 'F0AD4E', 'E67D4A', 'D9534F'] });

            pres.writeFile({ fileName: "AllReportPPT" });
            this.setState({ isLoading: false })

            // this.setState({ chartData1: sendData1, chartData2: sendData2,chartData3: sendData3,chartData4: sendData4,chartData5: sendData5 })
        }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false })

        });
    }
    sortDescending = (e) => {
        this.setState({ descValue: e.target.value });
        this.setState({ ascValue: "" })
        if (e.target.value === "MTD Plan") {
            this.state.jsonData.sort((a, b) => {
                return b.MTDPlan - a.MTDPlan;
            });
        }
        else if (e.target.value === "MTD Actual") {
            this.state.jsonData.sort((a, b) => {
                return b.MTDActual - a.MTDActual;
            });
        }
        else if (e.target.value === "QTD Plan") {
            this.state.jsonData.sort((a, b) => {
                return b.QTDPlan - a.QTDPlan;
            });
        }
        else if (e.target.value === "QTD Actual") {
            this.state.jsonData.sort((a, b) => {
                return b.QTDActual - a.QTDActual;
            });
        }
        else if (e.target.value === "YTD Plan") {
            this.state.jsonData.sort((a, b) => {
                return b.YTDPlan - a.YTDPlan;
            });
        }
        else if (e.target.value === "YTD Actual") {
            this.state.jsonData.sort((a, b) => {
                return b.YTDActual - a.YTDActual;
            });
        }
        setTimeout(() => {
            // console.log(this.state.jsonData)
            let MTDPlan = this.state.jsonData.map(item => item.MTDPlan)
            let MTDActual = this.state.jsonData.map(item => item.MTDActual)
            let QTDPlan = this.state.jsonData.map(item => item.QTDPlan)
            let QTDActual = this.state.jsonData.map(item => item.QTDActual)
            let YTDPlan = this.state.jsonData.map(item => item.YTDPlan)
            let YTDActual = this.state.jsonData.map(item => item.YTDActual)
            this.setState({
                json: [{
                    name: "MTD Plan",
                    data: MTDPlan
                }, {
                    name: "MTD Actual",
                    data: MTDActual
                },
                {
                    name: "QTD Plan",
                    data: QTDPlan
                },
                {
                    name: "QTD Actual",
                    data: QTDActual
                },
                {
                    name: "YTD Plan",
                    data: YTDPlan
                },
                {
                    name: "YTD Actual",
                    data: YTDActual
                },
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

    }
    //loader for chart
    loadingPanel = (
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );
    backToMainChart = () => {
        debugger
        this.setState({ IsDrillChart: false });
        setTimeout(() => {
            this.componentDidMount()
        }, 200);
    }
    drilldownChart = (e) => {

        debugger
        if (this.props.input["ReportType"] === "Top 15 Customers" && e.category !== "Others") {
            // console.log(e.dataItem)
            this.setState({ isLoading: true })
            this.props.CustomerFilterData.map((data) => {

                if (data.Descriptions === e.category) {
                    let input = JSON.parse(JSON.stringify(this.props.input))
                    input["CustomerID"] = `${data.ID}`
                    input["ReportType"] = "Division"
                    setTimeout(() => {
                        GridService.GridData(input).then(response => {
                            let d = response
                            let data = JSON.parse(d.response)
                            this.setState({ drillChartToGrid: data })
                            this.setState({ IsDrillChart: true })
                            setTimeout(() => {
                                this.componentDidMount()
                                this.setState({ isLoading: false })
                            }, 200);
                        }).catch(err => {
                            this.setState({ isLoading: false })
                            console.log("error", err)
                            // this.setState({ isLoading: false })

                        });
                    }, 100);
                }


            })
        }
        else if (this.props.input["ReportType"] === "Top 15 Customers" && e.category === "Others") {
            // console.log(e.dataItem)
            let input = JSON.parse(JSON.stringify(this.props.input)), index, CustomerID = [], Id;
            this.setState({ isLoading: true })
            this.props.CustomerFilterData.map((data) => {
                if (data.Descriptions !== "Pearson" && data.Descriptions !== "Taylor and Francis" && data.Descriptions !== "Cambridge University Press" && data.Descriptions !== "	Bloomsbury PLC" && data.Descriptions !== "John Wiley and Sons" && data.Descriptions !== "De Gruyter" && data.Descriptions !== "Infinitas Learning" && data.Descriptions !== "OUP" && data.Descriptions !== "IOP Publishing" && data.Descriptions !== "Wolters Kluwer" && data.Descriptions !== "Cengage Learning" && data.Descriptions !== "Hodder Education" && data.Descriptions !== "ICL - Institute for Community Living" && data.Descriptions !== "ASQ" && data.Descriptions !== "SAGE publishing") {
                    index = this.props.Customer['Descriptions'].indexOf(data.Descriptions)
                    Id = this.props.Customer['ID'][index]
                    CustomerID.push(Id)


                    // console.log(data.ID,"please")

                }
            })
            input["CustomerID"] = `(${CustomerID})`
            input["ReportType"] = "Division"



            setTimeout(() => {
                GridService.GridData(input).then(response => {
                    let d = response
                    let data = JSON.parse(d.response)
                    this.setState({ drillChartToGrid: data })
                    this.setState({ IsDrillChart: true })
                    setTimeout(() => {
                        this.componentDidMount()
                        this.setState({ isLoading: false })
                    }, 200);
                }).catch(err => {
                    this.setState({ isLoading: false })
                    console.log("error", err)
                    // this.setState({ isLoading: false })

                });
            }, 100);




        }
        else if (this.props.input["ReportType"] === "By Function") {
            this.setState({ isLoading: true })
            GridService.getGridData(

                {
                    "MasterType": "Function",

                },
                'Function'
            ).then(response => {
                let d = response
                let data = JSON.parse(d.response);
                data.map((dataitem, id) => {
                    if (dataitem.Process === e.category) {
                        let input = JSON.parse(JSON.stringify(this.props.input))
                        input["DivisionId"] = `(${dataitem.Condition})`
                        input["ReportType"] = "Division"
                        setTimeout(() => {
                            GridService.GridData(input).then(response => {
                                let d = response
                                let data = JSON.parse(d.response)
                                this.setState({ drillChartToGrid: data })
                                this.setState({ IsDrillChart: true })
                                setTimeout(() => {
                                    this.componentDidMount()
                                    this.setState({ isLoading: false })
                                }, 200);
                            }).catch(err => {
                                this.setState({ isLoading: false })
                                console.log("error", err)
                                // this.setState({ isLoading: false })

                            });
                        }, 100);
                    }
                    return null

                })
            }).catch(err => {
                console.log("error", err)
            });
        }
    }

    render() {
        return (


            <div className='chart-bordy' id="chart-bordy">
                {(this.state.isLoading) && (this.loadingPanel)}
                <div>
                    <div className="chartheader">  <p className="Charttype" data-toggle="tooltip" title="Chart Type">Chart Type</p>

                        <DropDownList data={this.state.charts} defaultValue="column" value={this.state.chartType} onChange={(event) => { this.changeChart(event.target.value) }} />
                        {this.state.chartType === "column" || this.state.chartType === "bar" ? <Button title="Rotate" primary={true} onClick={this.rotateChart}>Rotate</Button> : null}
                        <Button primary={true} title="Export as image" onClick={this.onImageExportClick}>Export as Image</Button>
                        <Button primary={true} title="Export as PPT" onClick={this.onPPTExportClick}>Export as PPT</Button>
                        <Button primary={true} title="Export all as PPT" onClick={this.onALLPPTExportClick}>Export all as PPT</Button>
                        {
                            this.state.IsDrillChart ? null : <Button primary={true} title="View as grid" onClick={() => this.viewGrid()}>View as Grid</Button>
                        }
                        <Button primary={true} title={this.state.sortingOrder} onClick={() => this.sorting()}>{this.state.sortingOrder}</Button>
                        <div title="Sort ascending by value"><ComboBox
                            style={{ paddingLeft: "5px", width: "177px", height: "52px" }}
                            data={this.state.fieldName}
                            value={this.state.ascValue}
                            onChange={this.sortAscending}
                            placeholder="Sort ascending by value" /></div>
                        <div title="Sort descending by value"><ComboBox
                            style={{ paddingLeft: "5px", width: "185px", height: "52px" }}
                            data={this.state.fieldName}
                            value={this.state.descValue}
                            onChange={this.sortDescending}
                            placeholder="Sort descending by value" /></div>
                    </div>
                    {
                        this.state.IsDrillChart ? <Button style={{ marginLeft: '60px', marginTop: '7px' }} onClick={() => this.backToMainChart()}>Go Back</Button> : null
                    }

                    {this.state.chartType === "donut" ?
                        //Sample chart for donut with telerik data
                        <Chart>
                            <ChartSeries>
                                <ChartSeriesItem
                                    type="donut"
                                    data={this.state.donut}
                                    categoryField="kind"
                                    field="share"
                                >
                                    <ChartSeriesLabels
                                        color="#fff"
                                        background="none"
                                        content={this.labelContent}
                                    />
                                </ChartSeriesItem>
                            </ChartSeries>
                            <ChartLegend visible={false} />
                        </Chart> :
                        this.state.chartType === "funnel" ?
                            //Sample chart for funnel with telerik data
                            <Chart
                                style={{
                                    margin: "0 auto",
                                    width: 300,
                                }}
                            >
                                <ChartTitle text="Sales funnel" />
                                <ChartSeries>
                                    <ChartSeriesItem
                                        type="funnel"
                                        data={this.state.funnel}
                                        categoryField="stat"
                                        field="count"
                                        colorField="color"
                                    >
                                        <ChartSeriesLabels color="white" background="none" format="N0" />
                                    </ChartSeriesItem>
                                </ChartSeries>
                                <ChartTooltip render={this.tooltipRender} />
                                <ChartLegend visible={false} />
                            </Chart> :
                            this.state.chartType === "pie" ?
                                //Sample chart for pie with telerik data
                                <Chart>
                                    <ChartTitle text="World Population by Broad Age Groups" />
                                    <ChartLegend position="bottom" />
                                    <ChartSeries>
                                        <ChartSeriesItem
                                            type="pie"
                                            data={this.state.pie}
                                            field="value"
                                            categoryField="category"
                                            labels={{
                                                visible: true,
                                                content: pieContent,
                                            }}
                                        />
                                    </ChartSeries>
                                </Chart> :
                                this.state.chartType === "waterfall" ?
                                    //Sample chart for waterfall with telerik data
                                    <Chart>
                                        <ChartTitle text="Cash flow" />
                                        <ChartSeries>
                                            <ChartSeriesItem
                                                type="waterfall"
                                                data={this.state.waterfall}
                                                color={this.pointColor}
                                                field="amount"
                                                categoryField="period"
                                                summaryField="summary"
                                            >
                                                <ChartSeriesLabels format="C0" position="insideEnd" />
                                            </ChartSeriesItem>
                                        </ChartSeries>
                                        <ChartValueAxis>
                                            <ChartValueAxisItem title={ValueTitle} />
                                        </ChartValueAxis>
                                    </Chart> :
                                    //chart component with MKF data (order inflow) in line,area,bar,column,
                                    <Chart style={{padding: "20px" }} pannable={true} zoomable={{
                                        mousewheel: {
                                            lock: "y",
                                        },
                                        selection: {
                                            lock: "y",
                                        },
                                    }} ref={(cmp) => this._chart = cmp} onSeriesClick={(e) => { this.drilldownChart(e) }}>
                                        <ChartTitle text={this.state.title} />
                                        <ChartLegend position="bottom" />
                                        <ChartCategoryAxis>

                                            <ChartCategoryAxisItem max={3} categories={this.state.categories}>
                                                <ChartCategoryAxisTitle text={this.state.yaxisname} font='bold 14px Arial, sans-serif' />
                                            </ChartCategoryAxisItem>

                                        </ChartCategoryAxis>
                                        <ChartValueAxis>
                                            <ChartValueAxisItem >
                                                <ChartValueAxisTitle text={this.state.xaxisname} font='bold 14px Arial, sans-serif' />
                                            </ChartValueAxisItem>
                                        </ChartValueAxis>

                                        <ChartSeries>
                                            {
                                                this.state.json.map((item, i) => {
                                                    if (i / 2 === 0) {
                                                        return (<ChartSeriesItem key={i} type={this.state.chartType} data=
                                                            {item.data} name={item.name} tooltip={{ visible: true }}   >
                                                            <ChartSeriesLabels content={this.labelContent} />
                                                        </ChartSeriesItem>)
                                                    }
                                                    else {
                                                        return (<ChartSeriesItem key={i} type={this.state.chartType} data=
                                                            {item.data} name={item.name} tooltip={{ visible: true }}   >
                                                            <ChartSeriesLabels content={this.labelContent} />
                                                        </ChartSeriesItem>)
                                                    }

                                                })
                                            }


                                        </ChartSeries>
                                    </Chart>

                    }

                </div>

            </div>

        );
    }
}

