import React from "react";
import '../App.css';
import { GridService } from '../services/grid.services'

import { ComboBox } from '@progress/kendo-react-dropdowns'
import {
    Chart,
    ChartLegendItem,
    ChartArea,
    ChartTitle,
    ChartSeries,
    ChartSeriesItem,
    ChartSeriesLabels,
    ChartCategoryAxis,
    ChartCategoryAxisTitle,
    ChartCategoryAxisItem,
    ChartValueAxis,
    ChartValueAxisItem,
    ChartValueAxisTitle,
    ChartLegend,
    ChartTooltip,
    ChartSeriesItemTooltip,
    exportVisual
} from '@progress/kendo-react-charts';

import 'hammerjs';
import { exportPDF } from '@progress/kendo-drawing';
import { Button } from '@progress/kendo-react-buttons';
import { exportImage } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { DropDownList } from '@progress/kendo-react-dropdowns';
import DrillDown from '../Grid/CCDrilldownGrid'
import { setData } from "@telerik/kendo-intl";
import moment from 'moment'
import { Path, Text, Group, geometry, Element, Rect as RectShape } from '@progress/kendo-drawing';

const { Point, Rect, Size } = geometry;

const customVisual = (props) => {
            // Create rectangular shape on top of which the label will be drawn
            const rectOptions = { stroke: { width: 2, color: '#fff' }, fill: { color: '#fff' } };
            const rectGeometry = new Rect(new Point(0, 3), new Size(60, 10));
            const rect = new RectShape(rectGeometry, rectOptions);

            // Create the lines used to represent the custom legend item
            const pathColor = props.options.markers.border.color;
            const path1 = new Path({
                stroke: {
                    color: pathColor,
                    width: 17,
                    
                }
            });

           

            // The paths are constructed by using a chain of commands
            path1.moveTo(0, 40).lineTo(40, 40).close();
            // path2.moveTo(15, 7).lineTo(25, 7).close();

            // Create the text associated with the legend item
            const labelText = props.series.name;
            const labelFont = props.options.labels.font;
            const fontColor = props.options.labels.color;
            const textOptions = { font: "400 18px system-ui, -apple-system, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, Liberation Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji",fontSize:"26px", fill: { color: fontColor } };
            const text = new Text(labelText, new Point(50, 28), textOptions);

            // Place all the shapes in a group
            const group = new Group();

            group.append(rect, path1, text);
            // set opacity if the legend item is disabled
            if (!props.active) {
                group.opacity(0.5);
            }

            return group;
}

const nestedTooltipRender = ({ point }) => (
    <span>
     {point.value.toFixed(Math.max((( point.value+'').split(".")[1]||"").length, 2))+"%"}
    </span>
  );
export default class ViewChart extends React.Component {

    constructor(props) {
        super(props);
        // this.getData = this.props.getData()
        this.state =
        {
            // data: [...data],
            chartType: "column",
            viewGrid: false,
            jsonData: [],
            title: "",
            categories: [],
        navopen:this.props.navopen,
            chartDatavalue: [],
            json: [],
            sort: [],
            input:[this.props.detailinput],
            callchart: true,
            categoryField: "",
            fieldname: "",
            categorykey: "",
            categorykey2: "",
            charts: [], /*["area","bar","boxPlot","bubble","bullet","donut","funnel","line","pie","polar","radar","rangeArea","rangeBar","scatter","waterfall"] this are the available chart type need to transfer data accordingly */
            sortingOrder: "Sort Descending by Alphabet",
            Sort: true,
            drillChartToGrid: [],
            IsDrillChart: false,
            isLoading: false,
            fieldName: [],
            refreshChart:false
            //sample data for donut chart
        }

    }
    componentDidMount = () => {
        //while component mounting itself data are set to state
        debugger
        // let legends=Object.keys(this.props.chartData[0])
        // console.log(legends)
        //   console.log("plese",this.props.chartData)
        if (this.props.navopen) {
            document.getElementById('chart-container').style.marginLeft = "150px";

             document.getElementById('chart-bordy').style.left = "120px";
            // document.getElementById('chart-bordy').style.marginLeft = "83px"
        }

            this.setState({ charts: ["column", "area", "line", "bar"],isLoading:true })
            
            GridService.CCChart(this.props.input).then(response => {
                let d = response
                let data = JSON.parse(d.response),trackA=[],trackB=[],trackC=[],A={},B={},C={},sendData=[];
                debugger
                if(this.props.filter==="Day Wise"){
                    this.setState({ jsonData: data.Table1,isLoading: false,refreshChart:true  })
                }
                else if(this.props.filter==="Week Wise"){
                    this.setState({ jsonData: data.Table3,isLoading: false,refreshChart:true  })
                }
                else{
                    this.setState({ jsonData: data.Table,isLoading: false,refreshChart:true  })
                }
            
            //Here we had just separated data and value for drawing charts, so the fields which need to be compare are separated as name and data
            setTimeout(() => {
      
               	
                let TrackA = this.state.jsonData.map(item => item["Track A"])	
                let TrackB  = this.state.jsonData.map(item => item["Track B"])	
                let TrackC = this.state.jsonData.map(item => item["Track C"])
                let lastUpdate =moment().format('YYYY-MM-DD hh:mm:ss a');
                this.props.lastUpdatedate(lastUpdate)
this.setState({

                    json: [{
                        name: "Track A",
                        data: TrackA,
                        seriesVisible: true
                    }, {
                        name: "Track B",
                        data: TrackB,
                        seriesVisible: true
                    }, {
                        name: "Track C",
                        data: TrackC,
                        seriesVisible: true
                    }
                    ]
                })
                this.categories();
                // console.log(this.state.json)
            }, 100);
            setTimeout(() => {
                this.setState({refreshChart:false}) 
             }, 200);
            this.setState({ yaxisname: "", xaxisname: "" })

        }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false })

        });
        


    }
    drilldownChart = (e) => {
        debugger
        let month = "", track = "";
        if (e.category === "Track A") {
            track = "A"
        }
        else if (e.category === "Track B") {
            track = "B"
        }
        else if (e.category === "Track C") {
            track = "C"
        }


        let input = this.props.detailinput;
        input["Month"] = e.series.name
        input["Track"] = track
        if (document.getElementById('chart-bordy').style.left === "120px") {
            this.setState({ navopen: true })
        }
        else{
            this.setState({ navopen: false })
        }
setTimeout(() => {
   
    this.setState({input:input,callchart:false})
}, 200);
    }
    sorting = () => {
        //sorting the chart data alphabetically
        debugger
        this.setState({ ascValue: '', descValue: '' })
        this.setState({ Sort: !this.state.Sort })

        setTimeout(() => {
            if (this.state.Sort === true) {
                this.setState({ sortingOrder: "Sort Descending by Alphabet" })
                if (this.state.categorykey === "ID") {
                    this.state.jsonData.sort((a, b) => {

                        let fa = a[this.state.categorykey2].toLowerCase(),
                            fb = b[this.state.categorykey2].toLowerCase();
                        if (fa < fb) {
                            return -1;
                        }
                        if (fa > fb) {
                            return 1;
                        }
                        return 0;
                    })
                }
                else {
                    this.state.jsonData.sort((a, b) => {

                        let fa = a[this.state.categorykey].toLowerCase(),
                            fb = b[this.state.categorykey].toLowerCase();
                        if (fa < fb) {
                            return -1;
                        }
                        if (fa > fb) {
                            return 1;
                        }
                        return 0;
                    })
                }

            }

            else {
                this.setState({ sortingOrder: "Sort Ascending by Alphabet" })
                if (this.state.categorykey === "ID") {
                    this.state.jsonData.sort((a, b) => {
                        let fa = a[this.state.categorykey2].toLowerCase(),
                            fb = b[this.state.categorykey2].toLowerCase();
                        if (fa > fb) {
                            return -1;
                        }
                        if (fa < fb) {
                            return 1;
                        }
                        return 0;
                    });
                }
                else {
                    this.state.jsonData.sort((a, b) => {
                        let fa = a[this.state.categorykey].toLowerCase(),
                            fb = b[this.state.categorykey].toLowerCase();
                        if (fa > fb) {
                            return -1;
                        }
                        if (fa < fb) {
                            return 1;
                        }
                        return 0;
                    });
                }
            }
        }, 100);

        setTimeout(() => {
            let Hours = this.state.jsonData.map(item => item.hours)
            let Days = this.state.jsonData.map(item => item.days)


            this.setState({
                json: [{
                    name: "Hours",
                    data: Hours
                }, {
                    name: "Days",
                    data: Days
                }
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

        this.setState({ yaxisname: "", xaxisname: "" })
    }

    onPDFExportClick = () => {
        //export the chart as PDF
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportPDF(chartVisual, {
                paperSize: "A2",
                landscape: true
            }).then(dataURI => saveAs(dataURI, this.props.fileName));
        }
    }

    onImageExportClick = () => {
        //export the chart as image
        const chartVisual = exportVisual(this._chart);

        if (chartVisual) {
            exportImage(chartVisual).then(dataURI => saveAs(dataURI, this.props.fileName));
        }
    }

    categories = () => {
        //this method used to set, on what basics the chart to be view (to set category)
        debugger

        var categories = []
    
        // console.log(this.state.categorykey);


        this.state.jsonData.map((item, i) => {
            
            return (categories.push(item["Mon"]))

        })


        this.setState({ categories: categories })


    }
    labelContent = (e) => {
        //for label for chart
        if (e.value !== 0) {
            return (e.value.toFixed(Math.max((( e.value+'').split(".")[1]||"").length, 2))+"%");
        }
        else {
            return ("")
        }

    }



    changeChart = (value) => {
        //used to set the chart type
        this.setState({ chartType: value ,refreshChart:true})
        setTimeout(() => {
            this.setState({refreshChart:false}) 
         }, 200);
    }

    viewGrid = () => {
        debugger
        if (document.getElementById('chart-bordy').style.left === "120px") {
            this.setState({ chartnavopen: true })
        }

        setTimeout(() => {
            this.props.chartDatafunc(this.state.chartnavopen, this.props.fromdate, this.props.todate)
        }, 100);


    }
    rotateChart = () => {
        //rotate the column and bar chart
        if (this.state.chartType === "column") {
            this.setState({ chartType: "bar"  ,refreshChart:true})
        }
        else if (this.state.chartType === "bar") {
            this.setState({ chartType: "column" ,refreshChart:true })
        }
        setTimeout(() => {
            this.setState({refreshChart:false}) 
         }, 200);
    }
    sortAscending = (e) => {
        this.setState({ ascValue: e.target.value })
        this.setState({ descValue: "" });
        if (e.target.value === "Hours") {
            this.state.jsonData.sort((a, b) => {
                return a.hours - b.hours;
            });
        }
        else if (e.target.value === "Days") {
            this.state.jsonData.sort((a, b) => {
                return a.days - b.days;
            });


        }
        setTimeout(() => {
            let Hours = this.state.jsonData.map(item => item.hours)
            let Days = this.state.jsonData.map(item => item.days)


            this.setState({
                json: [{
                    name: "Hours",
                    data: Hours
                }, {
                    name: "Days",
                    data: Days
                }
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

    }
    sortDescending = (e) => {
        this.setState({ descValue: e.target.value });
        this.setState({ ascValue: "" })
        if (e.target.value === "Hours") {
            this.state.jsonData.sort((a, b) => {
                return b.hours - a.hours;
            });
        }
        else if (e.target.value === "Days") {
            this.state.jsonData.sort((a, b) => {
                return b.days - a.days;
            });
        }



        setTimeout(() => {
            let Hours = this.state.jsonData.map(item => item.hours)
            let Days = this.state.jsonData.map(item => item.days)


            this.setState({
                json: [{
                    name: "Hours",
                    data: Hours
                }, {
                    name: "Days",
                    data: Days
                }
                ]
            })
            this.categories();
            // console.log(this.state.json)
        }, 120);

    }
    //loader for chart
    loadingPanel = (
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );

    backdrill=()=>{
        debugger
        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
            else{
                this.setState({navopen:false})
            }
        }
  setTimeout(() => {
    this.setState({callchart:true})
  }, 100);
        setTimeout(() => {
            if (this.state.navopen) {
                document.getElementById('chart-container').style.marginLeft = "150px";

                document.getElementById('chart-bordy').style.left = "120px";
                // document.getElementById('chart-bordy').style.marginLeft = "83px"
            }
            else{
                document.getElementById('chart-container').style.marginLeft = "15px";

                document.getElementById('chart-bordy').style.left = "60px";
        // document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }, 200);
    }
    handleChartRefresh = (chartOptions, themeOptions, chartInstance) => {
        if (this.state.refreshChart) {
          chartInstance.setOptions(chartOptions, themeOptions);
        }
      }; 
      func = (e) => {
        this.setState({ refreshChart: true })
        let newjson = this.state.json
        newjson.map((i) => {
           
            if (i.name === e.text) {
                if (i.seriesVisible === true) {
                    // console.log(i.name,e.text)
                    i.seriesVisible = false
                }

                else {
                    i.seriesVisible = true
                }
            }
        })
        this.setState({ json: newjson })
       
        setTimeout(() => {
            this.setState({ refreshChart: false })
        }, 200);
    }
    render() {
        return (

            this.state.callchart === true ?
                <div className='chart-bordy' id="chart-bordy">
                    {(this.state.isLoading) && (this.loadingPanel)}
                    <div className="ChartBorder">
                        <div className="chartheader"> 
                        <h5>{this.props.title}</h5> 
                        <div className="Chartinnerheader"><DropDownList data={this.state.charts} defaultValue="column" value={this.state.chartType} onChange={(event) => { this.changeChart(event.target.value) }} />
                            {this.state.chartType === "column" || this.state.chartType === "bar" ? <Button title="Rotate" primary={true} onClick={this.rotateChart}>Rotate</Button> : null}
                            <Button primary={true} title="Export as image" onClick={this.onImageExportClick}>Export as Image</Button>
                            <Button primary={true} title="Export as PDF" onClick={this.onPDFExportClick}>Export as PDF</Button>
                            {
                                this.state.IsDrillChart ? null : <Button primary={true} title="View as grid" onClick={() => this.viewGrid()}>View as Grid</Button>
                            }
                            {/* <Button primary={true} title={this.state.sortingOrder} onClick={() => this.sorting()}>{this.state.sortingOrder}</Button>
                            <div title="Sort ascending by value"><ComboBox
                                style={{ paddingLeft: "5px", width: "177px", height: "52px" }}
                                data={this.state.fieldName}
                                value={this.state.ascValue}
                                onChange={this.sortAscending}
                                placeholder="Sort ascending by value" /></div>
                            <div title="Sort descending by value"><ComboBox
                                style={{ paddingLeft: "5px", width: "185px", height: "52px" }}
                                data={this.state.fieldName}
                                value={this.state.descValue}
                                onChange={this.sortDescending}
                                placeholder="Sort descending by value" /></div> */}
                      </div>  </div>



                        <Chart style={{ height:350,border:"1px solid #DEDEDE",margin:"10px" }} pannable={true} zoomable={{
                            mousewheel: {
                                lock: "y",
                            },
                            selection: {
                                lock: "y",
                            },
                        }} ref={(cmp) => this._chart = cmp}onRefresh={this.handleChartRefresh} onLegendItemClick={(e) => { this.func(e) }}  >
                            <ChartArea  margin={20} width={'1110'}/>
                             <ChartTooltip render={nestedTooltipRender} />
                            <ChartLegend position="bottom" orientation={'horizontal'}>
          <ChartLegendItem visual={customVisual}/>
        </ChartLegend>
                            <ChartCategoryAxis>

                                <ChartCategoryAxisItem labels={{
                                    rotation: 'auto'
                                }} max={30} categories={this.state.categories}>
                                    <ChartCategoryAxisTitle text={this.state.yaxisname} font='bold 14px Arial, sans-serif' />
                                </ChartCategoryAxisItem>

                            </ChartCategoryAxis>
                            <ChartValueAxis>
                                <ChartValueAxisItem >
                                    <ChartValueAxisTitle text={this.state.xaxisname} font='bold 14px Arial, sans-serif' />
                                </ChartValueAxisItem>
                            </ChartValueAxis>

                            <ChartSeries>
                                {
                                    this.state.json.map((item, i) => {
                                       
                                            return (<ChartSeriesItem key={i} stack={{
                                                type: "100%",
                                            }} type={this.state.chartType} data=
                                                {item.data} name={item.name} visible={item.seriesVisible} >
                                                <ChartSeriesLabels content={this.labelContent} format="{0:0.00}"
                                                 position={this.state.chartType==="line" || this.state.chartType==="area"?"right":"top"}
                                                 background="transparent"  />
                                            </ChartSeriesItem>)
                                        

                                    })
                                }


                            </ChartSeries>
                        </Chart>



                    </div>

                </div> :
                 <div className='move-grid-container' id='grid-container'><Button style={{ marginLeft: '60px', marginTop: '7px'}} onClick={this.backdrill}>Go Back</Button>
                             <DrillDown navopen={this.state.navopen} input={this.state.input} DetailedColumn={this.props.CCDetailColumn} Detailedaggregates={this.props.detailaggre}/></div>


        );
    }
}

