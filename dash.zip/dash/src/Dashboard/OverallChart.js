import React from "react";
import '../App.css';
import {
    Chart,
    ChartTitle,
    ChartSeries,
    ChartSeriesItem,
    ChartSeriesLabels,
    ChartCategoryAxis,
    ChartCategoryAxisTitle,
    ChartCategoryAxisItem,
    ChartValueAxis,
    ChartValueAxisItem,
    ChartValueAxisTitle,
    ChartLegend,
    exportVisual
} from '@progress/kendo-react-charts';
import 'hammerjs';




export default class ViewChart extends React.Component {

    constructor(props) {
        super(props);
        // this.getData = this.props.getData()
        this.state =
        {
            // data: [...data],
            chartType: "column",
            viewGrid: false,
            jsonData: [],
            jsonData2: [],
            title: "",
            categories: [],
            categories2: [],
            navopen: this.props.navopen,
            chartDatavalue: [],
            json: [],
            json2: [],
            sort: [],
            selectedValue: "Month Wise",
            input: [this.props.detailinput],
            callchart: true,
            categoryField: "",
            fieldname: "",
            categorykey: "",
            categorykey2: "",
            charts: [], /*["area","bar","boxPlot","bubble","bullet","donut","funnel","line","pie","polar","radar","rangeArea","rangeBar","scatter","waterfall"] this are the available chart type need to transfer data accordingly */
            sortingOrder: "Sort Descending by Alphabet",
            Sort: true,
            drillChartToGrid: [],
            IsDrillChart: false,
            isLoading: false,
            fieldName: [],
            //sample data for donut chart
        }

    }
    componentDidMount = () => {
        debugger

            this.setState({ jsonData: this.props.data, isLoading: false })
            setTimeout(() => {
                let Actuals =this.state.jsonData.map(item => item.Actuals)
                let Plan =this.state.jsonData.map(item => item.Plan)

                this.setState({

                    json: [{
                        name: "Actuals",
                        data: Actuals,

                    },
                    {
                        name: "Plan",
                        data: Plan,

                    }
                    ]
                })
                this.categories();
                // console.log(this.state.json)
            }, 100);

            this.setState({ yaxisname: "", xaxisname: "" })









    }

 
    categories = () => {
        //this method used to set, on what basics the chart to be view (to set category)
        debugger

        var categories = [];
        this.state.jsonData.map((item, i) => {
               
            return (categories.push(item["Descriptions"]))

        })
        
 this.setState({ categories: [] })
// console.log(this.state.categories)

    }




    labelContent = (e) => {
        //for label for chart
        if (e.value !== 0) {
            return (e.value);
        }
        else {
            return ("")
        }

    }

    
    render() {
        return (

        
                <div>
                
                   

                            <Chart    style={{
      width: 285,
      height: 190,
    }}pannable={true} zoomable={{
                                mousewheel: {
                                    lock: "y",
                                },
                                selection: {
                                    lock: "y",
                                },
                            }} ref={(cmp) => this._chart = cmp} >
                                <ChartTitle  />
                                <ChartLegend position="bottom" />
                                <ChartCategoryAxis>

                                    <ChartCategoryAxisItem categories={this.state.categories} >
                                        <ChartCategoryAxisTitle text="" font='bold 14px Arial, sans-serif' />
                                    </ChartCategoryAxisItem>

                                </ChartCategoryAxis>
                                <ChartValueAxis>
                                    <ChartValueAxisItem >
                                        <ChartValueAxisTitle text={this.state.xaxisname} font='bold 14px Arial, sans-serif' />
                                    </ChartValueAxisItem>
                                </ChartValueAxis>

                                <ChartSeries>
                                    {
                                        this.state.json.map((item, i) => {

                                            return (<ChartSeriesItem key={i} type={this.state.chartType} data=
                                                {item.data} name={item.name} tooltip={{ visible: true }}   >
                                                <ChartSeriesLabels content={this.labelContent} />
                                            </ChartSeriesItem>)


                                        })
                                    }


                                </ChartSeries>
                            </Chart> 
                </div>

       


        );
    }
}


