import * as React from "react";
import { TileLayout } from "@progress/kendo-react-layout";
import OverallChart from './OverallChart';
import OverallOTD from "./OverallOTD";
import OverallRFT from './OverallRFT';
import OverallDefects from './OverallDefects';
import OverallTAT from './OverallTAT'
import OverallCCA from './OverallCCA';
import moment from 'moment';

import { NavLink } from 'react-router-dom';
import {GridService} from '../services/grid.services'
let fromdate = new Date();
let todate = new Date();
let toDateCol = new Date();
//todate.setDate(todate.getDate() - 1)
if (fromdate.getDate() === 1) {
    fromdate.setDate(2);
    fromdate.setMonth(fromdate.getMonth() - 1)
    //todate=fromdate
}
else {

    fromdate.setDate(1);
    // todate=fromdate

}
class Overall extends React.Component {
    state = {
        data: [{
            col: 1,
            colSpan: 2,
            rowSpan: 1
        }, {
            col: 3,
            colSpan: 2,
            rowSpan: 1
        }, {
            col: 1,
            colSpan: 1,
            rowSpan: 1
        }, {
            col: 2,
            colSpan: 1,
            rowSpan: 1
        }, {
            col: 3,
            colSpan: 1,
            rowSpan: 1
        }, {
            col: 4,
            colSpan: 1,
            rowSpan: 1
        }],
        isLoading:false,
        input:{
            "FromDate": moment(fromdate).format('YYYY-MM-DD'),
            "ToDate": moment(todate).format('YYYY-MM-DD'),
           
        }
    };
    componentWillMount = () => {
        debugger

        if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
            if (document.getElementById('grid-container').style.marginLeft === "150px") {
                this.setState({ navopen: true });
            }
        }
        else if (document.getElementById('chart-bordy')) {
            if (document.getElementById('chart-bordy').style.left === "120px") {
                this.setState({ navopen: true });
 
            }
        }
        else {
            this.setState({ navopen: false });
            if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
                document.getElementById('grid-container').style.marginLeft = "15px";
                document.getElementById('grid-body').style.marginLeft = "50px";
            }
            else if (document.getElementById('chart-bordy')) {
                document.getElementById('chart-bordy').style.left = "60px";
                document.getElementById('chart-bordy').style.marginLeft = "10px"
            }
        }
    }
    componentDidMount = () => {
        if (this.state.navopen) {
            document.getElementById('chart-container').style.marginLeft = "150px";

            document.getElementById('chart-bordy').style.left = "120px";

        }
        this.setState({isLoading:true})

        GridService.Overallreport(this.state.input).then(response => {
            let d = response
            let dat = JSON.parse(d.response)
      
            this.setState({ jsonData: dat })
            setTimeout(() => {
                this.setState({isLoading:false})
            }, 300);
            this.setState({
                tiles: [{
                    header: "Ontime Delivery",
                    body: <div className="OTD-overall"><NavLink to={'/OTDReport'} activeClassName="active_item">
                        {/* <h2>OTD</h2> */}
                        <OverallOTD data={
                            this.state.jsonData.Table
                        }
                        />
                    </NavLink>
                    <div className="OTD_legends"><ul><li className="OTDactual">Actual { this.state.jsonData.Table[0].Actuals}%</li><li className="OTDPlan">Plan { this.state.jsonData.Table[0].Plan}%</li></ul></div></div>,
    
                }, {
                    header: "Right First Time",
                    body: <NavLink to={'/RightFirstTime'} activeClassName="active_item">
                        {/* <h2>RFT</h2> */}
                        <OverallRFT data={   this.state.jsonData.Table1} type={"line"}/>
    
                    </NavLink>
                }, {
                    header: "Turn Around Time",
                    body: <div>
                        {/* <h2>TAT</h2> */}
                        <OverallTAT data={this.state.jsonData.Table2} />
                    </div>
                }, {
                    header: "Defects",
                    body: <NavLink to={'/DefectManagement'} activeClassName="active_item">
                        {/* <h2>DEFECTS</h2> */}
                        <OverallDefects data={this.state.jsonData.Table3} type={"column"}/>
                    </NavLink>
                }, {
                    header: "Chargeback",
                    body: <div>
                        {/* <h2 style={{
                  marginBottom: "-1px",
                  marginTop: "-10px"
                }}>Chargeback</h2> */}
                        <OverallChart data={this.state.jsonData.Table4} />
    
                    </div>
                }, {
                    header: "Closure of CCA",
                    body: <div>
                        {/* <h2>CCA</h2> */}
    
                        <OverallCCA data={this.state.jsonData.Table5} />
                    </div>
                }]
            })      
      }).catch(err => {
            console.log("error", err)
            this.setState({ isLoading: false,jsonData:[] })
      
        });
       
    }

    handleReposition = e => {
        this.setState({
            data: e.value
        });
    };
    loadingPanel = (
        <div className="k-loading-mask">
            <span className="k-loading-text">Loading</span>
            <div className="k-loading-image"></div>
            <div className="k-loading-color"></div>
        </div>
    );
    render() {
        return (<div className='move-chart-container' id='chart-container'>
                            {(this.state.isLoading) && (this.loadingPanel)}
                            <div className="SpeedNotes"  style={{marginTop:'0px'}}><span style={{color:"red"}}>Note : </span> Report is on under pilot mode{this.state.lastupdate}</div>
            <div className='chart-bordy' id="chart-bordy"><div className="Tile_div"><TileLayout columns={4} rowHeight={255} positions={this.state.data} gap={{
                rows: 10,
                columns: 10
            }} items={this.state.tiles} onReposition={this.handleReposition} /></div></div></div>)
    }

}

export default Overall;
