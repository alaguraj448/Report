import * as React from 'react';
import { RadialGauge } from '@progress/kendo-react-gauges';

class OverallOTD extends React.Component {
  state = {
    value: 0
  };

  componentDidMount() {
    // console.log(this.props.data)
  }

  render() {
    const radialOptions = {
      scale: {
        minorUnit: 5,
        majorUnit: 20,
        max: 200,
        
      },
        pointer: [{
         value:this.props.data[0].Actuals,
          color: '#0275D8',
          
        }]
      
    };
    return (<div><RadialGauge {...radialOptions} style={{width: "326px", height: "160px",marginLeft:"70px" }}/>
    </div>)
  }

}

export default OverallOTD;