import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { CircularGauge } from '@progress/kendo-react-gauges';

class OverallCCA extends React.Component {
  state = {
    value: 0
  };
componentDidMount=()=>{
  let value=this.props.data[0].Actuals/this.props.data[0].Plan
  value=value*100
this.setState({value:value})
}


  render() {
    const colors = [{
      to: 25,
      color: '#0058e9'
    }, {
      from: 25,
      to: 50,
      color: '#37b400'
    }, {
      from: 50,
      to: 75,
      color: '#ffc000'
    }, {
      from: 75,
      color: '#f31700'
    }];
    const arcOptions = {
      value: this.state.value,
      colors
    };
    

    const centerRenderer = (value, color) => {
      return <p style={{
        color: "#0058e9",
        fontSize:"16px",
        fontWeight:"700"
      }}>Actual: {this.props.data[0].Actuals}%<br></br>Plan: {this.props.data[0].Plan}%
      </p>
    };
  
    return (<div><CircularGauge {...arcOptions} centerRender={centerRenderer}style={{bottom:"5px",height:"160px"}} />
    </div>)






        
  }

}

export default OverallCCA