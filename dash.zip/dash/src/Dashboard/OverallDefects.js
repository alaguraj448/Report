import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Chart, ChartCategoryAxis,ChartSeriesLabels, ChartCategoryAxisItem, ChartValueAxis, ChartValueAxisItem, ChartSeries, ChartSeriesItem, ChartLegend } from '@progress/kendo-react-charts';
import { Path, Group, Text } from '@progress/kendo-drawing';
import 'hammerjs';
const categories = [];
let series = [];
let plotValue = [];
const name = ["Actual"]
const chartColor = ['#0275D8'];
const chartColorExceed = ['#D9534F'];

class OverallDefects extends React.Component {
  state = {
    value: 0,
    exceed: false,
  };
  componentWillMount=()=>{
    series = [this.props.data[0].Actuals];
    plotValue = [this.props.data[0].Plan];
  }
  componentDidMount = () => {
    
    // console.log(this.props.data)
    if (plotValue[0] < series[0]) {
      this.setState({ exceed: true })
    }
  }
  onRender = args => {
    const chart = args.target.chartInstance;

    if (!chart) {
      return;
    } // get the axes


    const valueAxis = chart.findAxisByName("valueAxis");
    const categoryAxis = chart.findAxisByName("categoryAxis"); // get the coordinates of the value at which the plot band will be rendered

    const valueSlot = valueAxis.slot(plotValue); // get the coordinates of the entire category axis range

    const range = categoryAxis.range();
    const categorySlot = categoryAxis.slot(range.min, range.max); // draw the plot band based on the found coordinates

    const line = new Path({
      stroke: {
        color: "yellow",
        width: 6
      }
    }).moveTo(valueSlot.origin.x, valueSlot.origin.y).lineTo(categorySlot.topRight().x, valueSlot.origin.y);
    const label = new Text(`${plotValue} Plan`, [0, 0], {
      fill: {
        color: "black"
      },
      font: "14px sans bold"
    });
    const bbox = label.bbox();//
    label.position([categorySlot.topRight().x - bbox.size.width, valueSlot.origin.y - bbox.size.height]);
    const group = new Group();
    group.append(line, label); // draw on the surface

    chart.surface.draw(group);
  };
  render() {
    return <Chart style={{
      width: 285,
      height: 190,
    }} onRender={this.onRender} seriesColors={this.state.exceed === true ? chartColorExceed : chartColor}>
      <ChartLegend position="bottom" />
      <ChartCategoryAxis>
        <ChartCategoryAxisItem categories={categories} name="categoryAxis" />
      </ChartCategoryAxis>
      <ChartValueAxis>
        <ChartValueAxisItem name="valueAxis" />
      </ChartValueAxis>
      <ChartSeries>
        <ChartSeriesItem data={series} name={name} tooltip={{ visible: true }}   >
        <ChartSeriesLabels content={this.labelContent} />
        </ChartSeriesItem>
      </ChartSeries>
    </Chart>;
  }
}

export default OverallDefects