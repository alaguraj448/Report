
import React from "react";
import { appConfig } from './url/config';
import { invokeGetService, invokePostService } from './base/service';
import { GridService } from './services/grid.services'

// export default function Authentication(props) {

class Authentication extends React.Component {
    state = {
        isLoggedIn: false
    }
    // const [isLoggedIn, setisLoggedIn] = useState(false);
    componentDidMount = () => {
        this.checkAuthenticationStatus();
    }
    componentDidUpdate = () => {
        if (this.props.signout) {
            this.signOut();
        }
    }

    //   loadingPanel = ( /* Code for showing loading symbol */

    // );

    checkAuthenticationStatus = () => {
        debugger
        // console.log("please")
        const url = "/status";
        this.setState({ isLoading: false })
        invokeGetService(url).then((response) => {//checkauthstatus in server
            // console.log(response,"pl")
            // const { isLoggedIn, profile, given_name } = response;

            const { isLoggedIn, sub, given_name } = response;
            if (isLoggedIn) {
                let empcode = sub.toUpperCase()
                // let empcode = profile.toUpperCase()

                    GridService.checkrole(
                        {

                            "EmpCode": empcode
                        },

                        'Division'
                    ).then(response => {
                        let d = response
                        let data = JSON.parse(d.response)
                        
                              
                         if(data.length===0){
                            this.setState({ isLoading: false })
                            alert("You are not Authorized to view this page")
                           
                            this.signOut();
                        }
                        else{
                        if (data[0].rolename === "Super Admin") {
                            this.props.sendKAM("", "", false, false, "0", data[0].username, data[0].usercode, data[0].rolename, JSON.parse(data[0].menuname));
                            this.setState({ isLoggedIn: true })
                            this.setState({ isLoading: false })
                        }
                        else if (data[0].rolename === "MKF Admin") {
                            this.props.sendKAM("", "", false, false, "0", data[0].username, data[0].usercode, data[0].rolename, JSON.parse(data[0].menuname));
                            this.setState({ isLoggedIn: true })
                            this.setState({ isLoading: false })
                        }
                        else if (data[0].rolename === "TandF Admin") {
                            this.props.sendKAM("", "", false, false, "0", data[0].username, data[0].usercode, data[0].rolename, JSON.parse(data[0].menuname));
                            this.setState({ isLoggedIn: true })
                            this.setState({ isLoading: false })
                        }
                        else if (data[0].rolename === "OUP Admin") {
                            this.props.sendKAM("", "", false, false, "0", data[0].username, data[0].usercode, data[0].rolename, JSON.parse(data[0].menuname));
                            this.setState({ isLoggedIn: true })
                            this.setState({ isLoading: false })
                        }
                        else if (data[0].rolename === "TandF PM") {
                            this.props.sendKAM("", "", false, false, "0", data[0].username, data[0].usercode, data[0].rolename, JSON.parse(data[0].menuname));
                            this.setState({ isLoggedIn: true })
                            this.setState({ isLoading: false })
                        }
                        else if (data[0].rolename === "KAM") {

                            GridService.getGridData({
                                "MasterType": "CheckRole",
                                "ToDate": "2022/04/01 00:00:00",
                                "FromDate": "2021/04/01 00:00:00",
                                "EmpCode": empcode
                            }).then(response => {
                                let d = response
                                let id = JSON.parse(d.response)
                                let empId = id[0].ID
                           
                            this.props.sendKAM(empId, "", true, false,  data[0].usercode, data[0].username, data[0].usercode, data[0].rolename, JSON.parse(data[0].menuname));
                            this.setState({ isLoggedIn: true })
                            this.setState({ isLoading: false })

                        }).catch(err => {
                            console.log("error", err)
                        });

                        }

                        else if (data[0].Descriptions === "KAMHead") {
                            GridService.getGridData({
                                "MasterType": "CheckRole",
                                "ToDate": "2022/04/01 00:00:00",
                                "FromDate": "2021/04/01 00:00:00",
                                "EmpCode": empcode
                            }).then(response => {
                                let d = response
                                let id = JSON.parse(d.response)
                                let empId = id[0].ID
                            this.props.sendKAM("", empId, false, true, data[0].usercode, data[0].username, data[0].usercode, data[0].rolename, JSON.parse(data[0].menuname));
                            this.setState({ isLoggedIn: true })
                            this.setState({ isLoading: false })
                        }).catch(err => {
                            console.log("error", err)
                        });

                        }
                    }
                
                 
                }).catch(err => {
                    console.log("error", err)
                });

            }
        
            else {
                // console.log("navigatetosuccess")
                this.navigateToLogin();//localhost:5000/auth/redirect-authneticated
            }
        }).catch((error) => {
            console.log(error);
            setTimeout(this.signOut, 2000);
        });
    };

    navigateToLogin = () => {
        debugger
        let { base_url, uri, client_id } = appConfig.auth;
        const params = {
            response_type: 'code',
            redirect_uri: `${appConfig.server.getUrl()}${uri.redirect_uri}`,
            client_id,
            scope: 'openid',
            state: window.location.href
        };
        let query = '';
        Object.entries(params).forEach(param => { query += `&${param[0]}=${param[1]}` });
        window.location.assign(`${base_url}${uri.authorize}?${query}`);
    };

    signOut = () => {
        const url = appConfig.auth.uri.signout;//signout
        invokePostService(url, {}).then((res) => {
            window.location.assign(`${appConfig.auth.base_url}${res}`);
        });
    };
    render() {
        return (

            this.state.isLoggedIn ? <div>{this.props.children}</div> : <div className="k-loading-mask">
                <span className="k-loading-text">Loading</span>
                <div className="k-loading-image"></div>
                <div className="k-loading-color"></div>
            </div>
        );
    }
}

export default Authentication;





