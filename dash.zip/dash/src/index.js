// import 'babel-polyfill';
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import { AppContainer } from 'react-hot-loader';
import App from './App';



ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

