import React from "react";
import {
  BrowserRouter,
  Route,
  Switch,
  Redirect
} from 'react-router-dom';
import "@progress/kendo-theme-bootstrap/dist/all.scss";
import "bootstrap/scss/bootstrap.scss";
import './App.css';
import Footer from './Layout/Footer/Footer'
import Navbar from './Layout/Navbar/Navbar'
import MultiSelectDropdown from './Grid/MultiSelectDropdown';
import GroupSummary from './Grid/GroupsummaryDate';
import CCReport from './Grid/CCReport';
import LagReport from "./Grid/LagReport";
import OUPMaster from './Grid/OUPMasterReport'
import OTDReport from './Grid/OTDReport'
import AgeingReport from './Grid/AgeingReport';
import InflowReport from './Grid/InflowReport';
import OTDPMReport from './Grid/OTDPMReport'
import AuthorReport from './Grid/AuthorQueryReport';
import SpeedReport from './Grid/SpeedReport';
import Authentication from './authentication';
import RoleMapping from './Grid/RoleMapping';
import QualityReport from './Grid/QualityReport';
import RFTReport from "./Grid/RFTReport";
import SocietyJournal from "./Grid/SocietyJournalReport";
import DespatchReport from './Grid/DespatchReport'
import IssueReport from './Grid/IssueDate'
import SPMReport from './Grid/SPMReport'
import  Overall from './Dashboard/Overall'
import ImportReport from "./Grid/ImportReport";
import WeeklyDefects from "./Grid/DefectPMReport"
import LongPending from "./Grid/LongPendingreport";
import DrawerContainer from './DrawerContainer';
import { HashRouter} from 'react-router-dom';


class App extends React.Component {
  state = {
    signout: false,
    Kam: "",
    Kamhead: "",
    name: "",
    IsKAM: false,
    IsKAMHead: false,
    EmpCode: "",
    Name: "",
    ISNo: "",
    navopen: false,
    Role: "",
    sidemenu: [],
    issidemeuChange: false,
    LoadTemplate: [],
    isTemplateLoad: false,
    sidemenuname: [],
    menu:[],
    cusid:""

  }
  signout = () => {
    this.setState({ signout: true })
  }
  sidemenuname = (menu) => {
    this.setState({ sidemenuname: menu })
  }

  falseSidemeu=()=>{
    this.setState({issidemeuChange:false})
  }
  sendKAM = (id, headid, iskam, iskamhead, empcode, name, ISNo, Role,menu,cusid) => {
    let newarr=[]
    this.setState({ Kam: id });
    this.setState({ Kamhead: headid });
    this.setState({ Name: name });
    this.setState({ IsKAM: iskam });
    this.setState({ IsKAMHead: iskamhead });
    this.setState({ EmpCode: empcode });
    this.setState({ ISNo: ISNo })
    this.setState({ Role: Role })
    this.setState({menu:menu})
    this.setState({cusid:cusid})
   
  
         for (const obj of this.state.menu) {
      if (obj.parentid === 0 || obj.route === "undefined") {
        obj.parentid = undefined;
        obj.route = undefined;

      }
       if(obj['data-expanded'] == "undefined")
        obj['data-expanded']= undefined;

      if(obj['selected']===0){
        obj['selected']=false
      }
      if(obj['selected']===1){
        obj['selected']=true
      }
      if (obj['data-expanded']=="false" )
        
          obj['data-expanded'] = false;
          
      if (obj['data-expanded']=="true" )
        
          obj['data-expanded'] = true;
      
   
    }
 

this.setState({menu:this.state.menu})
if(Role==="TandF Admin"){ 
this.state.menu.map((menu,i)=>{
  if(menu.id===23){
    newarr.push(menu)
    
  }
})

this.state.menu.map((menu,i)=>{
  if(menu.parentid===23){
    newarr.push(menu)
    
  }
})
newarr.push({
  separator: true,
},)
this.state.menu.map((menu,i)=>{
  if(menu.id===20){
    newarr.push(menu)
    
  }
})
this.state.menu.map((menu,i)=>{
  if(menu.parentid===20){
    newarr.push(menu)
    
  }
})
newarr.push({
  separator: true,
},)
this.state.menu.map((menu,i)=>{
 
  if(menu.id===19){
    newarr.push(menu)
    
  }
})
this.state.menu.map((menu,i)=>{
  if(menu.parentid===19){
    newarr.push(menu)
    
  }
})
newarr.push({
  separator: true,
},)
this.state.menu.map((menu,i)=>{
  if(menu.id===21){
    newarr.push(menu)
    
  }
})
this.state.menu.map((menu,i)=>{
  if(menu.parentid===21){
    newarr.push(menu)
    
  }
})
newarr.push({
  separator: true,
},)
this.state.menu.map((menu,i)=>{
  if(menu.id===24){
    newarr.push(menu)
    
  }
})
this.state.menu.map((menu,i)=>{
  if(menu.parentid===24){
    newarr.push(menu)
    
  }
})
// console.log(newarr)
this.setState({menu:newarr})
    }
  }
  LoadTemplate = (data) => {
    debugger
    this.setState({ LoadTemplate: data ,isTemplateLoad: true})




  }
  DeleteTemplate = () => {
    debugger
    this.setState({ isTemplateLoad: false  })
    
  }
  
  LoadDefaultTemplate = () => {

    this.setState({ isTemplateLoad: false })
  }
chart=()=>{
  this.setState({chart:true})
  setTimeout(() => {
    this.setState({chart:false})

  }, 300);
}
  render() {
    return (
      
    
      <Authentication signout={this.state.signout} sendKAM={this.sendKAM}>
        <BrowserRouter >
        
          <div>
          
      {/* <DrawerContainer> */}
            <Navbar primary={true} signout={this.signout} sidemenuname={this.sidemenuname}
              EmpCode={this.state.ISNo} LoadTemplate={this.LoadTemplate} menu={this.state.menu} cusid={this.state.cusid} isTemplateLoad={this.state.isTemplateLoad} LoadDefaultTemplate={this.LoadDefaultTemplate} Name={this.state.Name} Role={this.state.Role}  />
            <Switch>
            <Route  path='/Rolemapping'component={() => 
            <RoleMapping navopen={this.state.navopen}/>}/>
             <Route  path='/OverallStatus'component={() => 
            <Overall jsonData={this.state.jsonData} navopen={this.state.navopen}/>}/>
            <Route  path='/SpeedReport'component={() => 
            <SpeedReport  Kam={this.state.Kam} 
            Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
             IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode}navopen={this.state.navopen}/>}/>
               <Route  path='/CCReport'component={() => 
            <CCReport  Kam={this.state.Kam} 
            Kamhead={this.state.Kamhead} Name={this.state.Name} role={this.state.Role}IsKAM={this.state.IsKAM}
             IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen}/>}/>
              <Route path='/GroupSummary' component={() =>
                <GroupSummary Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                  <Route path='/RightFirstTime' component={() =>
                <RFTReport Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                 
                   <Route path='/DefectManagement' component={() =>
                <QualityReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                   <Route path='/DispatchTrend' component={() =>
                <DespatchReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                   <Route path='/SPMWorkload' component={() =>
                <SPMReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
               <Route path='/LongTailedArticles' component={() =>
                <AgeingReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                 <Route path='/LongPending' component={() =>
                <LongPending
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                  <Route path='/DefectReportPM' component={() =>
                <WeeklyDefects
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                  <Route path='/DefectsImport' component={() =>
                <ImportReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                  <Route path='/SpeedReportPM' component={() =>
                <SocietyJournal
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                   <Route path='/LagReport' component={() =>
                <LagReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                <Route path='/OUPMasterReport' component={() =>
                <OUPMaster
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                   <Route path='/AuthorQueries' component={() =>
                <AuthorReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                       <Route path='/OTDReportPM' component={() =>
                <OTDPMReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                      <Route path='/InflowvsDespatch' component={() =>
                <InflowReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                   <Route path='/IssuePublicationReport' component={() =>
                <IssueReport
                Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
                              <Route path='/OTDReport' component={() =>
                <OTDReport Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead} Name={this.state.Name} IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead} EmpCode={this.state.EmpCode} navopen={this.state.navopen} />} />
              <Route path='/OIReport' component={() =>
                <MultiSelectDropdown
                  Kam={this.state.Kam}
                  Kamhead={this.state.Kamhead}
                  Name={this.state.Name}
                  IsKAM={this.state.IsKAM}
                  IsKAMHead={this.state.IsKAMHead}
                  isTemplateLoad={this.state.isTemplateLoad}
                  LoadDefaultTemplate={this.DeleteTemplate}
                  ISNo={this.state.ISNo}
                  sidemenuname={this.state.sidemenuname}
                  EmpCode={this.state.EmpCode}
                  LoadTemplate={this.state.LoadTemplate}
                  navopen={this.state.navopen} />} />
             {
               this.state.Role==="TandF Admin"?
               <Route exact path="/" ><Redirect to="/OverallStatus" component={Overall} /></Route>
               :this.state.Role==="TandF PM"?
               <Route exact path="/" ><Redirect to="/LongTailedArticles" component={MultiSelectDropdown} /></Route>
               :this.state.Role==="OUP Admin"?
               <Route exact path="/" ><Redirect to="/OUPMasterReport" component={OUPMaster} /></Route>
               :<Route exact path="/" ><Redirect to="/OIReport" component={MultiSelectDropdown} /></Route>
             } 
             

            </Switch>
            {/* </DrawerContainer> */}
    
            <Footer />
          </div>
        </BrowserRouter>
      </Authentication>
     
      // <button onClick={this.call}>Get session</button>
    );
  }
}

export default App;
