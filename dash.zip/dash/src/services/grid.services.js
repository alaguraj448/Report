import { API  } from '../url/api.service';

import { CONFIG } from '../url/config';

export const GridService = {
    getGridData,
    get,
    getAuthData,
    getAuthenData,
    GridData,
    getDemoUser,
    GroupSummaryGrid,
    GroupSummaryQTRGrid,
    getToken,
    CCReport,
    SpeedReport,
    Savetemplate,
    GetAllTemplate,
    DeleteTemplate,
    checkrole,
    Rolemapping,
    GetAllRole,
    EditRole,
    addNewEmp,
    setExchangeRate,
    CCChart,
    AllGridData,
    CCDetailedReport,
    OTDReport,
    SpeedDetailedReport,
    SpeedReportChart,
    DefectReport,
    DefectChart,
    RFTChart,
    RFTReport,
    IssueReport,
    IssueChart,
    SPMReport,
    Despatchreport,
    OTDChart,
    Ageing,
    AuthorQuery,
    OTDPMReport,
    InflowReport,
    Overallreport,
    SocietyJournal,
    importDefectsReport,
    getWeekRange,
    getWeeklyDefectsTrend,
    logImportedDefectReport,
    getRecentUploadDetail,
    LongPending,
    GetLagReport,
    GetOUPReport


};

    function getGridData(input,name) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.getmaster,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function AllGridData(input,name) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.AllGridData,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function checkrole(input,name) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.checkrole,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function Rolemapping(input,name) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.Rolemapping,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function addNewEmp(input,name) {
        debugger
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.addNewEmp,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function setExchangeRate(input,name) {
        debugger
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.setExchangeRate,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function GetAllRole(input,name) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.GetAllRole,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function EditRole(input,name) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.EditRole,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
   function CCDetailedReport (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.CCDetailedReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function SpeedDetailedReport (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.SpeedDetailedReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function SpeedReportChart(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.SpeedReportChart,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function OTDReport (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.OTDReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function OTDChart (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.OTDChart,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function Ageing (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.Ageing,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function AuthorQuery (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.AuthorQuery,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function OTDPMReport (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.OTDPMReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }    
    function Overallreport (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.Overallreport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
   function SocietyJournal(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.SocietyJournal,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    
    function InflowReport (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.InflowReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function DefectReport (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.DefectReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function DefectChart (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.DefectChart,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function RFTChart (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.RFTChart,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
   function RFTReport(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.RFTReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
   function IssueReport(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.IssueReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function IssueChart(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.IssueChart,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
   function SPMReport (input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.SPMReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function Despatchreport(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.Despatchreport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function Savetemplate(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.Savetemplate,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function GetAllTemplate(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.GetAllTemplate,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function DeleteTemplate(input) {
        return new Promise(function (resolve, reject) {
            debugger
            API.postAPI(CONFIG.DeleteTemplate,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
function GridData(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.overall,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function GroupSummaryGrid(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.GroupSummary,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function GroupSummaryQTRGrid(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.GroupSummaryQTR,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function CCChart(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.CCChart,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function CCReport(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.CCReport,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function SpeedReport(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.SpeedReport,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function getAuthData(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.ldapauthorization,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function getAuthenData(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.authentication,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function getDemoUser(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.getDemoUser,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function getToken(input) {
    return new Promise(function (resolve, reject) {
        debugger
        API.postAPI(CONFIG.getToken,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}

function get(path) {
    return new Promise(function (resolve, reject) {
        debugger
        API.getAPI(path)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function getWeekRange(input) {
    return new Promise(function (resolve, reject) {
         
        API.postAPI(CONFIG.getWeekRange,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
function importDefectsReport(input) {
    return new Promise(function (resolve, reject) {
         
        API.postAPI(CONFIG.importDefectsReport,input)
            .then(response => {
                let res = JSON.parse(response);
                if (res) {
                    resolve(res);
                } else {
                    reject(res.message);
                }
            }).catch(error => {
                reject(error.message);
            });
    });
}
  function getWeeklyDefectsTrend(input,name) {
        return new Promise(function (resolve, reject) {
             
            API.postAPI(CONFIG.getWeeklyDefectsTrend,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function logImportedDefectReport(input) {
        return new Promise(function (resolve, reject) {
             
            API.postAPI(CONFIG.logImportedDefectReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function getRecentUploadDetail(input) {
        return new Promise(function (resolve, reject) {
             
            API.postAPI(CONFIG.getRecentUploadDetail,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    
    function LongPending(input,name) {
        return new Promise(function (resolve, reject) {
             
            API.postAPI(CONFIG.LongPending,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function GetLagReport(input,name) {
        return new Promise(function (resolve, reject) {
             
            API.postAPI(CONFIG.GetLagReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }
    function GetOUPReport(input,name) {
        return new Promise(function (resolve, reject) {
             
            API.postAPI(CONFIG.GetOUPReport,input)
                .then(response => {
                    let res = JSON.parse(response);
                    if (res) {
                        resolve(res);
                    } else {
                        reject(res.message);
                    }
                }).catch(error => {
                    reject(error.message);
                });
        });
    }