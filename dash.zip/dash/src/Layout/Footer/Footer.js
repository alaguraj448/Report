import React from "react";
import './Footer.css'
class Footer extends React.Component {
  render() {
    return (
        <div className='footer'> 
        <p>V 2022.06.07.23 © Copyright 2022 Integra Software Services Pvt. Ltd    </p>
        </div>
    );
  }
}

export default Footer;