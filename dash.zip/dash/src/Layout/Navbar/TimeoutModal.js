import React from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

const TimeoutModal = ({ showModal, togglePopup, handleStayLoggedIn }) => {
  return <Modal isOpen={showModal} toggle={togglePopup} keyboard={false} backdrop="static">
    <ModalHeader>You Have Been Idle!</ModalHeader>
    <ModalBody>
    You session is about to expire due to inactivity. To keep working, select Continue Session.
    </ModalBody>
    <div className="col-12 text-center mt-3">
                        <button className="btn btn-app-primary mr-3 cursor-pointer" title='Logout' onClick={() => { this.props.signOut() }}>Logout</button>
                        <button className="btn btn-app-primary cusort-pointer" title='Continue Session' onClick={() => { handleStayLoggedIn() }}>Continue Session</button>
                    </div>
    {/* <ModalFooter>
      <Button color="primary" onClick={handleStayLoggedIn}>Stay Logged In</Button>
    </ModalFooter> */}
  </Modal>
}

export default TimeoutModal;