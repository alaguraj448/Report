import React from 'react';
import { GridService } from '../../services/grid.services'
import { NavLink } from 'react-router-dom';
import './Navbar.css';
import DrawerContainer from '../../DrawerContainer';

import AddForm from '../../Grid/ExchangeRate'
import * as FaIcons from 'react-icons/fa';
import { IconContext } from 'react-icons';
import * as BsIcons from 'react-icons/bs';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import IdleTimer from 'react-idle-timer';
import TimeoutModal from './TimeoutModal';
const value = new Date();
let Currentyear, fromyear, toyear;
if (value.getMonth() + 1 >= 4) {

  Currentyear = value.getFullYear();
  fromyear = Currentyear;
  toyear = Currentyear + 1
}
else {
  Currentyear = value.getFullYear();
  toyear = Currentyear;
  fromyear = Currentyear - 1;
}
class Navbar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      sidebar: false,
      handleClick:false,
      gridSubmenu: false,
      chartSubmenu: false,
      sidemenu: [],
      sidemenuname: [],
      GroupIDData: [],
      opensetting: false
    }
    this.idleTimer = null;
    this.logoutTimer = null;
  }
componentDidMount=()=>{
  // console.log(this.props.menu)

}

  showSidebar = (a) => {
    debugger
    if (a === "fromrole") {
      this.setState({ sidebar: true });
    }
    else {
      this.setState({ sidebar: !this.state.sidebar });
      this.setState({handleClick:!this.state.handleClick})
      setTimeout(() => {
        localStorage.setItem("navbar", this.state.sidebar)
      }, 100);
    }

    setTimeout(() => {
    if (this.state.sidebar) {
      if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
        document.getElementById('grid-container').style.marginLeft = "150px";
        document.getElementById('grid-body').style.marginLeft = "50px";
      }
      else if (document.getElementById('chart-bordy')) {
        document.getElementById('chart-container').style.marginLeft = "150px";  
        document.getElementById('chart-bordy').style.left = "120px";
        // document.getElementById('chart-bordy').style.marginLeft = "83px"

      }

    }
    else {
      if (document.getElementById('grid-container') && document.getElementById('grid-body')) {
        document.getElementById('grid-container').style.marginLeft = "15px";
        document.getElementById('grid-body').style.marginLeft = "50px";
      }
      else if (document.getElementById('chart-bordy')) {
        document.getElementById('chart-container').style.marginLeft = "15px";
        document.getElementById('chart-bordy').style.left = "60px";
        // document.getElementById('chart-bordy').style.marginLeft = "10px"
      }

    }
  }, 100);
  }
  loadSubmenu = () => {
    setTimeout(() => {
      this.setState({ gridSubmenu: !this.state.gridSubmenu })
    }, 100);
    this.setState({ sidemenuname: JSON.parse(localStorage.getItem("templatename")) })


  }
  componentWillReceiveProps = () => {

    if (this.props.isTemplateLoad) {
      this.setState({ gridSubmenu: !this.state.gridSubmenu, selected: "Default Report" })
    }



  }

  componentDidMount = () => {
    debugger
    this.setState({ mainmenu: this.props.menu })
    if (this.props.menu.MKF === []) {
      this.setState({ MKFmenu: this.props.menu.MKF })
    }
    if (this.props.menu.TandF === []) {
      this.setState({ TandFmenu: this.props.menu.TandF })
    }
    if (this.props.Role === "Super Admin") {
      GridService.getGridData(
        {
          "MasterType": 'ExchangeRate',
          "ToDate": `${toyear}/03/31 00:00:00`,
          "FromDate": `${fromyear}/04/01 00:00:00`,
          "EmpCode": this.props.EmpCode
        },
        'GroupID'
      ).then(response => {
        let d = response
        let data = JSON.parse(d.response)
        this.setState({ GroupIDData: data })
      }).catch(err => {
        console.log("error", err)
      });

    }
    let sidemenu = [], sidemenuname = []
    GridService.GetAllTemplate({
      "EmpCode": this.props.EmpCode,
      "CustomerID": "1"
    }).then(response => {
      let d = response
      let data = JSON.parse(d.response);

      // console.log(data)
      data.map((dat, id) => {
        sidemenu.push(dat)
        sidemenuname.push(dat.templatename)

      })
      this.setState({ sidemenu: sidemenu })
      // console.log(sidemenuname)
      localStorage.setItem("templatename", JSON.stringify(sidemenuname))

    }).catch(err => {
      console.log("error", err)
    });
  }
  itemClicked = (dat, index) => {
    debugger
    this.setState({ selected: index })
    let data = this.state.sidemenu.map((d) => {
      if (d.templatename === dat) {

        this.setState({ currentdata: d })
        setTimeout(() => {
          this.props.LoadTemplate(this.state.currentdata)
        }, 100);

      }
    })

  }
  DefaultitemClicked = (item) => {
    this.setState({ selected: item })
    this.props.LoadDefaultTemplate()
  }
  opensetting = () => {
    this.setState({ opensetting: true })
  }
  handleCancelEdit = () => {
    this.setState({
      opensetting: false,
    });
  };
  add = (event) => {
    debugger
    // console.log(event)
    GridService.setExchangeRate({ "ExchangeRate": event.Exchange.Descriptions }).then(response => {
      let d = response
      if (d.response === "Updated Successfully") {
        this.setState({
          opensetting: false,
        });
        setTimeout(() => {
          alert("Updated Successfully")
        }, 100);
      }

    }).catch(err => {
      console.log("error", err)
      this.setState({
        opensetting: false,
      });
    });
  }
  onIdle = () => {
    this.togglePopup();
    this.logoutTimer = setTimeout(() => {
      this.handleLogout();
    }, 1000 * 60 * 5); // 10 min
  };

  togglePopup = () => {
    this.setState((prevState) => ({ showModal: !prevState.showModal }));
  };

  handleStayLoggedIn = () => {
    if (this.logoutTimer) {
      clearTimeout(this.logoutTimer);
      this.logoutTimer = null;
    }
    this.idleTimer.reset();
    this.togglePopup();
  };

  handleLogout = () => {
    this.props.signout()
  };
  render() {
    const { showModal } = this.state;

    return (
      <div>

        <IdleTimer
          ref={(ref) => {
            this.idleTimer = ref;
          }}
          element={document}
          stopOnIdle={true}
          onIdle={this.onIdle}
          timeout={1000 * 60 * 15}
        />
        <Modal isOpen={this.state.showModal} centered={true} backdrop="static">
          <ModalHeader>You Have Been Idle!</ModalHeader>
          <ModalBody>
            You session is about to expire due to inactivity. To keep working, select Continue Session.
          </ModalBody>
          {/* <div className="col-12 text-center mt-3">
                        <button className="btn btn-app-primary mr-3 cursor-pointer" title='Logout' onClick={() => { this.handleLogout() }}>Logout</button>
                        <button className="btn btn-app-primary cusort-pointer" title='Continue Session' onClick={() => {this.handleStayLoggedIn() }}>Continue Session</button>
                    </div> */}
          <ModalFooter>
            <Button color="primary" onClick={this.handleStayLoggedIn}>Continue Session</Button>
            <Button onClick={this.handleLogout}>Logout</Button>

          </ModalFooter>
        </Modal>
        <IconContext.Provider value={{ color: '#fff' }}>
          <div className='navbar'>
            <NavLink to='#' className='menu-bars'>
              <FaIcons.FaBars color="#f5f5f5" onClick={this.showSidebar} />
            </NavLink>
            <div className="idash_logo_sec">
              <NavLink to="/OverallStatus" > <h3>iDashboard</h3> </NavLink>
            </div>
            {/* <div className="idash_logo_sec"> */}
            {/* <Button icon="menu" fillMode="flat" onClick={this.handleClick} /> */}
{/* 
              <h3>iDashboard</h3>
            </div> */}
            <div className="idash_top_menu">
              <ul >

                <li className="username">
                  <div className="userli">Signed in as : {this.props.Role}</div>
                  <ul ><li className="userlist">{this.props.EmpCode}</li><li className="userlist" >{this.props.Name}</li></ul>
                </li>
                {this.props.Role === "Super Admin" && (<li title="Role Mapping">
                  <NavLink to="/Rolemapping" >
                    <BsIcons.BsFillPeopleFill className="Rolemapping" onClick={() => { this.showSidebar("fromrole") }} />
                  </NavLink>
                </li>)}
                {this.props.Role === "Super Admin" || this.props.Role === "MKF Admin" ?
                  <li title="Setting">
                    <span>
                      <BsIcons.BsFillGearFill className="Rolemapping" onClick={this.opensetting} /></span>

                  </li> : null}
                <li>
                  <a className="top_menu_item" href="# " title="Logout" >
                    <svg xmlns="http://www.w3.org/2000/svg" onClick={this.props.signout} viewBox="0 0 32 13" fill="white" width="38px" height="33px"><path d="M0 0h24v24H0V0z" fill="none" /><path d="M10.79 16.29c.39.39 1.02.39 1.41 0l3.59-3.59c.39-.39.39-1.02 0-1.41L12.2 7.7c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L12.67 11H4c-.55 0-1 .45-1 1s.45 1 1 1h8.67l-1.88 1.88c-.39.39-.38 1.03 0 1.41zM19 3H5c-1.11 0-2 .9-2 2v3c0 .55.45 1 1 1s1-.45 1-1V6c0-.55.45-1 1-1h12c.55 0 1 .45 1 1v12c0 .55-.45 1-1 1H6c-.55 0-1-.45-1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1v3c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z" /></svg>
                  </a>
                </li>

              </ul>
            </div>
          </div>

          {this.state.opensetting && (
            <AddForm
              cancelEdit={this.handleCancelEdit}
              onSubmit={this.add}
              data={this.state.GroupIDData}
            />
          )}


          {
            this.state.sidebar === true ?
<nav className='nav-menu active'>
              <div className='expand'>
                <DrawerContainer menu={this.props.menu} handleClick={this.state.handleClick}></DrawerContainer>
                           </div>
                           </nav>
               
              : 
              <nav className='nav-menu active'>
              <div className='mini'>
                <DrawerContainer menu={this.props.menu} handleClick={this.state.handleClick}></DrawerContainer>
                           </div>
                           </nav>
          }


        </IconContext.Provider>
      </div>
    );
  }
}

export default Navbar;