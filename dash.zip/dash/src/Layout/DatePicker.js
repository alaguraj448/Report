import * as React from "react";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { IntlProvider, load, loadMessages, LocalizationProvider } from "@progress/kendo-react-intl";
import likelySubtags from "cldr-core/supplemental/likelySubtags.json";
import currencyData from "cldr-core/supplemental/currencyData.json";
import weekData from "cldr-core/supplemental/weekData.json";
import numbers from "cldr-numbers-full/main/es/numbers.json";
import caGregorian from "cldr-dates-full/main/es/ca-gregorian.json";
import dateFields from "cldr-dates-full/main/es/dateFields.json";
import timeZoneNames from "cldr-dates-full/main/es/timeZoneNames.json";
import { render } from "@testing-library/react";
load(likelySubtags, currencyData, weekData, numbers, caGregorian, dateFields, timeZoneNames);
// import esMessages from "./es.json";
// loadMessages(esMessages, "es-ES");

const value = new Date();
const Tovalue = new Date();
Tovalue.setDate(Tovalue.getDate()-1)

export default class DatePick extends React.Component {
  locale = {
    language: "en-US",
    locale: "en"
  }
  render(){
  return <LocalizationProvider language={this.locale.language}>
      <IntlProvider locale={this.locale.locale}>
          
            {/*  marginTop: '-90px' */}
            
            <DatePicker 
    
            defaultValue={value} 
            onChange={
              (e)=>{
                let value = e.target.value
        this.props.changeStuff(value)
            }            
            } 
            format="yyyy/MM/dd"
      
            />

          
          
      </IntlProvider>
    </LocalizationProvider>;
  }
}
    //  style={{ width: "220px", marginLeft: '4px', marginTop: '3px' }}