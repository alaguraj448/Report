import axios from "axios";
import {appConfig} from  "../url/config";
export function invokeGetService(path) {
    return new Promise(function (resolve, reject) {
      const apiEndPoint =  appConfig.server.getUrl() ;
   
      const config = {
        method: 'GET'
      };
      axios.create({
        baseURL: apiEndPoint + path,
        withCredentials: true
      })(config)
        .then((response) => {
          resolve(response.data);
        })
        .catch((err) => {
          if (err.response) {
            reject(err.response.data);
          }
        });
    });
  };
  export function invokePostService(path, reqObj) {
    return new Promise((resolve, reject) => {
      let headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        "Access-Control-Allow-Origin": true
      };
      const apiEndPoint =  appConfig.server.getUrl() ;
      const config = {
        method: 'POST',
        data: reqObj,
        headers
      };
      axios.create({
        baseURL: apiEndPoint + path,
        withCredentials: true
      })(config)
        .then((response) => {
          resolve(response.data);
        })
        .catch((err) => {
          if (err.response) {
            reject(err.response.data);
          };
        });
    });
  };