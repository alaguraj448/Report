import { CONFIG } from './config';
let baseURL = CONFIG.API_BASE_URL;

export const API = {
  getAPI,
  postAPI
};


function getAPI(url, params = {}, contentType = "") {
  url = baseURL + url;
  if (params) {
    var queryString = Object.keys(params).map(key => key + '=' + params[key]).join('&');
    url += "?" + queryString;
  }
  return new Promise((resolve, reject) => {
    try {
      let xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState === 4) {
          if (this.status >= 500) {
            reject(new Error("Application not able to connect to the server. Please check your internet connection."));
          }
          else if (this.status === 422) {
            resolve(this.responseText);
          }
          else if (this.status === 404) {
            reject(new Error("You are not authorize to access the page. Please contact administrator."));
          }
          else if (this.status === 401) {
            localStorage.clear();
            sessionStorage.clear();
     
          }
          else if (this.status === 200) {
            resolve(this.responseText);
          }
        }
      };
    // const proxyurl = "https://cors-anywhere.herokuapp.com/";
      xhttp.open("GET", url, true);
      contentType = contentType ? contentType : "application/json";
      xhttp.setRequestHeader("Content-Type", contentType);
      params ? contentType === "application/json" ? xhttp.send(JSON.stringify(params)) : xhttp.send(params) : xhttp.send();
    }
    catch (error) {
      reject(error);
    }
  });
}

function postAPI(url, params = {}, contentType = "", headers = "") {

  url = baseURL + url;

  return new Promise((resolve, reject) => {
    try {
      let xhttp = new XMLHttpRequest();
      //xhttp.timeout=2400000
      //xhttp.withCredentials = true;
      xhttp.onreadystatechange = function () {
        if (this.readyState === 4) {
          if (this.status >= 500) {
            reject(new Error("Application not able to connect to the server. Please check your internet connection."));
          }
          else if (this.status === 422) {
            resolve(this.responseText);
          }
          else if (this.status === 404) {
            reject(new Error("You are not authorize to access the page. Please contact administrator."));
          }
          else if (this.status === 401) {
            localStorage.clear();
            sessionStorage.clear();
          
          }
          else if (this.status === 200) {
            resolve(this.responseText);
          }
        }
      };
      xhttp.open("POST", url, true);
      contentType = contentType ? contentType : "application/json";
      xhttp.setRequestHeader('Access-Control-Allow-Origin', '*');
      xhttp.setRequestHeader("Content-Type", contentType);
      xhttp.setRequestHeader("Cache-Control","no-cache");
      xhttp.setRequestHeader("Postman-Token","d2466336-b2b3-4000-88dd-bbcc4a94b936");
      //xhttp.setRequestHeader("cache-control", "no-cache");
      params ? contentType === "application/json" ? xhttp.send(JSON.stringify(params)) : xhttp.send(params) : xhttp.send();
    } catch (error) {
      reject(error);
      
    }
  });
}


