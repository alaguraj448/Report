const API_config = require('./api_config.json')
const PACKAGE = require('../../package.json');
const REACT_APP_SERVER_HOST="localhost"
const REACT_APP_SERVER_PORT=4000
const REACT_APP_SERVER_PROTOCOL="http";
// const REACT_APP_SERVER_WS_PROTOCOL="ws";
const REACT_APP_WSO2_BASEURL="https://172.16.200.197:9443";
const REACT_APP_OAUTH_CLIENT_ID="lHVC9RJyKlIv9m4luC1xQSiqHjEa"
export const CONFIG = {

    API_BASE_URL: API_config[PACKAGE.environment]["API_BASE_URL"],
    topcustomer:"/topCustomer",
    budgetVSactualinmonth:"/budgetVSactualinmonth",
    budgetVSactualbyentity:"/budgetVSactualbyentity",
    budgetVSactualbyfunction:"/budgetVSactualbyfunction",
    orderinflowBySalesPersonnel:"/orderinflowBySalesPersonnel",
    BudgetvsActuals_FY:"/BudgetvsActualsFY",
    orderinflow:"/orderinflow",
    Sagayaraj:"/Sagayaraj",
    Daisy:"/Daisy",
    Us:"/Us",
    Uk:"/Uk",
    existingpublishing:"/existingpublishing",
    publishingproduct:"/publishingproduct",
    Ses:"/Ses",
    wip:"/wip",
    wip_column: "/wip_column",
    saga_column: "/saga_column",
    daisy_column: "/daisy_column",
    daisy_data: "/daisy_data",
    hierrachy_table:"/hierrachy_table",
    categories1:"/Categories1",
    categories2:"/Categories2",
    categories3:"/Categories3",
    categories4:"/Categories4",
    categories5:"/Categories5",
    categories6:"/Categories6",
    categories7:"/Categories7",
    categories8:"/Categories8",
    printDU_column:"/printDU_column",
    DigitalandImmersiveDU_column:"/DigitalandImmersiveDU_column",
    ByCustomer_column:"/ByCustomer_column",
    ByCustomerNature_column:"/ByCustomerNature_column",
    status:"/status",
    redirect:"/redirect",
    signout:"/signout",
    ldapauthorization:"/ldapauthorization",
    authentication:"/authentication",
    overall:"/overall",
    GroupSummary:"/GroupSummary",
    GroupSummaryQTR:"/GroupSummaryQTR",
    CCReport:"/CCReport",
    SpeedReport:"/SpeedReport",
    getmaster:"/getmaster",
    getData:"/getData",
    getDemoUser:"/getDemoUser",
    getToken:"/getToken",
    Savetemplate:"/SaveTemplate",
    GetAllTemplate:"/GetAllTemplate",
    DeleteTemplate:"/DeleteTemplate",
    checkrole:"/checkrole",
    Rolemapping:"/Rolemapping",
    GetAllRole:"/GetAllRole",
    EditRole:"/EditRole",
    addNewEmp:"/addNewEmp",
    setExchangeRate:"/setExchangeRate",
    CCChart:"/CCChart",
    AllGridData:"/AllGridData",
    CCDetailedReport:"/CCDetailedReport",
    OTDReport:"/OTDReport",
    SpeedDetailedReport:"/SpeedDetailedReport",
    SpeedReportChart:"/SpeedReportChart",
    DefectReport:"/DefectReport",
    DefectChart:"/DefectChart",
    RFTChart:"/RFTChart",
    RFTReport:"/RFTReport",
    IssueReport:"/IssueReport",
    IssueChart:"/IssueChart",
    SPMReport:"/SPMReport",
    Despatchreport:"/Despatchreport",
    OTDChart:"/OTDChart",
    Ageing:"/Ageing",
    AuthorQuery:"/AuthorQuery",
    OTDPMReport:"/OTDPMReport",
    InflowReport:"/InflowReport",
    Overallreport:"/Overallreport",
    SocietyJournal:"/SocietyJournal",
    importDefectsReport:"/importDefectsReport",      // Alaguraj_code started this line for defect management done on 01-Mar-22 //
    getWeekRange:"/getWeekRange",
    getWeeklyDefectsTrend:"/getWeeklyDefectsTrend",  // Alaguraj_code ended this line for defect management done on 01-Mar-22 //
    logImportedDefectReport:"/logImportedDefectReport",
    getRecentUploadDetail:"/getRecentUploadDetail",
    LongPending:"/LongPending",
    GetLagReport:"/GetLagReport",
    GetOUPReport:"/GetOUPReport"
}
export const appConfig = {
    server: {
        host: REACT_APP_SERVER_HOST,
        port: REACT_APP_SERVER_PORT,
        protocol: REACT_APP_SERVER_PROTOCOL,
        // getUrl: () =>  `${REACT_APP_SERVER_PROTOCOL}://${REACT_APP_SERVER_HOST}:${REACT_APP_SERVER_PORT}`,
        // getUrl: () =>  "http://integra-net4/iDashboardWSO2API",
        getUrl: () => API_config[PACKAGE.environment]["API_BASE_URL"]
        // getSocketUrl: () => `${REACT_APP_SERVER_WS_PROTOCOL}://${REACT_APP_SERVER_HOST}:${REACT_APP_SERVER_PORT}`
    },
    auth: {
        base_url:  API_config[PACKAGE.environment]["REACT_APP_WSO2_BASEURL"],
        client_id:  API_config[PACKAGE.environment]["REACT_APP_OAUTH_CLIENT_ID"],
        uri: {
            status: "/status",
            redirect_uri: "/redirect",
            signout: "/signout",
            authorize: "/oauth2/authorize",
        
        }
    }
}