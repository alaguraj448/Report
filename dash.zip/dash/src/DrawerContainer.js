import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { Drawer, DrawerContent, DrawerItem } from '@progress/kendo-react-layout';
import { Button } from '@progress/kendo-react-buttons';



class DrawerContainer extends React.Component {
  state = {
    drawerExpanded: false,
    items: this.props.menu,
    FirstTime: true


  };
  componentWillMount = () => {
    // console.log(this.props.menu)
  }
  componentDidMount = () => {
    this.setState({
      drawerExpanded: this.props.handleClick
    });
  };
  CustomItem = props => {
    const {
      visible,
      ...others
    } = props;
    // console.log(props)
    const arrowDir = props['data-expanded'] ? 'k-i-arrow-chevron-down' : 'k-i-arrow-chevron-right';
    return <React.Fragment>
      {props.visible === false ? null : this.props.handleClick ? <DrawerItem {...others} className={arrowDir==='k-i-arrow-chevron-down'?"background":null}> 
        <span> <i className="material-icons custom" style={{ fontSize: "24px", verticalAlign: 'middle', paddingRight: '10px' }}>
          {props.icon}
        </i></span>            <span className={'k-item-text '} title={props.text}>{props.text}</span>
        {props['data-expanded'] !== undefined && <span className={"k-icon " + arrowDir} style={{
          position: 'absolute', right: "16px", top: "10px"
        }} />}
      </DrawerItem> : <DrawerItem {...others} className={arrowDir==='k-i-arrow-chevron-down'?"background":null}>
        <span> <i className="material-icons custom" title={props.text} style={{ verticalAlign: 'middle' }}>
          {props.icon}
        </i></span>       {/* <span className={'k-item-text'}>{props.text}</span> */}
        {props['data-expanded'] !== undefined && <span className={"k-icon " + arrowDir} style={{
          position: 'absolute', right: this.props.handleClick ? "80%" : "10%"

        }} />}
      </DrawerItem>}
    </React.Fragment>;
  };
  onSelect = ev => {
          this.setState({ FirstTime: false })
    const currentItem = ev.itemTarget.props;

    // localStorage.setItem('currentID', ev.itemTarget.props.route)
    const isParent = currentItem['data-expanded'] !== undefined;
    const nextExpanded = !currentItem['data-expanded'];
    if (!isParent) {
      const newData = this.state.items.map(item => {
        const {
          selected,
          ['data-expanded']: currentExpanded,
          id,
          ...others
        } = item;
        const isCurrentItem = currentItem.id === id;
        if (isParent) {
          return {
            // selected: isCurrentItem,
            ['data-expanded']: isCurrentItem && isParent ? nextExpanded : currentExpanded === undefined ? currentExpanded : false,
            id,
            ...others
          };
        }
        else {
          return {
            selected: isCurrentItem,
            ['data-expanded']: isCurrentItem && isParent ? nextExpanded : currentExpanded,
            id,
            ...others
          };
        }

      });
      this.setState({
        items: newData
      });
      this.props.history.push(ev.itemTarget.props.route);
    }
    else {

      const newData = this.state.items.map(item => {
        const {

          ['data-expanded']: currentExpanded,
          id,
          ...others
        } = item;
        const isCurrentItem = currentItem.id === id;
        if (isParent) {
          return {
            // selected: isCurrentItem,
            ['data-expanded']: isCurrentItem && isParent ? nextExpanded : currentExpanded === undefined ? currentExpanded : false,
            id,
            ...others
          };
        }
        else {
          return {
            // selected: isCurrentItem,
            ['data-expanded']: isCurrentItem && isParent ? nextExpanded : currentExpanded,
            id,
            ...others
          };
        }

      });
      this.setState({
        items: newData
      });
      this.props.history.push(ev.itemTarget.props.route);
    }
  };
  setSelectedItem = pathName => {



    let currentPath = this.state.items.find(item => item.route === pathName);
    if (currentPath !== undefined) {
      if (currentPath.text) {
        return currentPath.text;
      }
    }
    else {
      return ''
    }

  };
  setExpanded = pathName => {
    // if (this.state.FirstTime === true) {
      let a;
      let currentPath = this.state.items.find(item => item.route === pathName);
      if (currentPath !== undefined) {
        if (currentPath.text) {
          this.state.items.map((i) => {
            if (i.text === currentPath.text) {

              a = currentPath.parentid

            }

          })
          return (a)
        }
      }
    // }




  };
  render() {

    const selected =
      this.setSelectedItem(this.props.location.pathname)
   const id = this.setExpanded(this.props.location.pathname) 

    const data = this.state.items.map(item => {
      const {

        parentid,
        ...others
      } = item;
      if (this.state.FirstTime === true) {
        if (item['data-expanded'] !== undefined) {

          if (item.id === id) {
            item['data-expanded'] = true

          }
          else {
            item['data-expanded'] = false
          }

        }
      }

      if (parentid !== undefined) {
        // console.log(id,"jhifh")
        const parent = this.state.items.find(parent => parent.id === parentid);
        return {
          ...others,

          visible: parent['data-expanded'],
          selected: item.text === selected,
          // 'data-expanded':item.id===21
          // 'data-expanded':parent['data-expanded']
        };
      }

      return item;
    });
    return <div>

      <Drawer expanded={this.props.handleClick} position={"start"} mode='push' mini={true} items={data} item={this.CustomItem} onSelect={this.onSelect}>
        <DrawerContent>
          {this.props.children}
        </DrawerContent>



      </Drawer>
    </div>;
  }

}

export default withRouter(DrawerContainer);