var path = require('path');
var webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

const outputDirectory = 'dist';

module.exports = {
    entry: path.join(__dirname, './src', 'index.js'),
    output: {
        path: path.join(__dirname, outputDirectory),
        filename: '[name].[hash].js'
    },
    resolve: {
        modules: [path.resolve(__dirname, 'src'),
            'node_modules']
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                use: [{
                    loader: "babel-loader"
                }]
            },
            {
                test: /\.scss|.css$/,
                use: [
                    "style-loader", // creates style nodes from JS strings
                    "css-loader", // translates CSS into CommonJS
                    "sass-loader" // compiles Sass to CSS, using Node Sass by default
                ]
            },
            {
                test: /\.mp4$/,
                use: 'file-loader?name=videos/[name].[ext]',
            },
            {
                test: /\.(gif|png|jpe?g|woff|woff2|eot|ttf|svg)$/i,
                use: [
                    'file-loader',
                    {
                        loader: 'image-webpack-loader',
                        options: {
                            bypassOnDebug: true, // webpack@1.x
                            disable: true, // webpack@2.x and newer
                        },
                    },
                ],
            }
        ]
    },
    devServer: {
        historyApiFallback: true,
        contentBase: path.join(__dirname, 'src'),
    },

    plugins: [
        new webpack.ProvidePlugin({
            "React": "react",
         }),
        new CleanWebpackPlugin([outputDirectory]),
        new HtmlWebpackPlugin({ template:  'public/index.html' }),
        new webpack.HotModuleReplacementPlugin(),
    ]
};

